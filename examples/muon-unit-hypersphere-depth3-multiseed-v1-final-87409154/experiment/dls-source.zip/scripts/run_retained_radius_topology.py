#!/usr/bin/env python3
"""Run preregistered issue #164 retained-radius topology qualification."""
from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import replace
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys
import time
from typing import Any, Mapping, Sequence

import torch

from domain_scaling_lab.log_polar_no_composition import DEFAULT_CONFIG, config_wire, digest
from domain_scaling_lab.retained_radius_topology import (
    ANCHOR,
    BOOTSTRAP_SAMPLES,
    BOOTSTRAP_SEED,
    CONTRAST_DEFINITIONS,
    DECISION_FAMILY_SIZE,
    EFFECTIVE_DEPTH,
    EQUIVALENCE_NLL,
    FAMILYWISE_ALPHA,
    GEOMETRY_EPSILON,
    INDEPENDENT_FLAT,
    MATERIAL_NLL,
    MAX_GEOMETRIC_OVERHEAD_FRACTION,
    PARAMETER_REDUCTION_FRACTION,
    RECONSTRUCTION_TOLERANCE,
    RETAINED_RADIUS,
    SHARED_GENERIC,
    STATISTICAL_CONDITIONS,
    TRAINED_CONDITIONS,
    UNIT_HYPERSPHERE,
    build_topology_predictor,
    classify,
    condition_topology_config,
    dense_forward_flops_for_depth,
    fit_topology_condition,
    geometric_operations,
    paired_document_bootstrap,
    parameter_count,
    prepare_topology_condition,
    run_synthetic_controls,
    seed_contrasts,
    topology_digest,
    topology_wire,
)
from domain_scaling_lab.spectral import (
    ByteFrontend,
    DocumentText,
    FrontendLM,
    LearnedSpectrumFrontend,
    NativeFrontendLM,
    TextBatch,
    module_state_fingerprint,
    tensor_state_fingerprint,
)


ISSUE_123_RESULT_SHA256 = "37d96b367f327cd4b2cf5ed347a9ecd62a7057e0c124d263af2a677a392a2b86"
ISSUE_163_RESULT_SHA256 = "4ca90c2e6e248362c84c80773cac117f0f058ddd07e34251231e055e96db5b97"
ISSUE_163_SCIENTIFIC_PAYLOAD_SHA256 = "893ce2bbaee069af98150dbee5c7d444c718354f19365e9b93a6e168b76135ac"
ISSUE_163_EVIDENCE_COMMIT = "8254eabd3f4fb7549eceb4fc66f11fb70138a92f"
MINIMAL_BLOCK_SHA256 = "b0f24e5c196bda116120fd085eee60f37e0eaf6f3b146f45b253f0c79a5c21ec"
SPECTRAL_CHECKPOINT_SHA256 = "7dc0cc7b2298f34678596e8a895b74fb22e91184fe11d3c1fcc7663b57934d5e"
BYTE_CHECKPOINT_SHA256 = "8cc0ecbe067ebd1d811ceb487c44fe60444c080ea7134a590fab25ca0afd070b"
SPECTRAL_FRONTEND_SHA256 = "3a5a85be45fa8495fb7b88c3728150806537b01ab899c1603a85bdb0e2bc34fe"
BYTE_FRONTEND_SHA256 = "89422306889231bd465e42f83eddcd9a2e7380e6cb8ac94341de87fd788ae074"


def _file_sha256(path: Path) -> str:
    value = sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def _read_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


def _segments_to_documents(records: Sequence[Mapping[str, Any]]) -> list[DocumentText]:
    documents = []
    for record in records:
        raw = bytes.fromhex(str(record["segment_utf8_hex"]))
        if sha256(raw).hexdigest() != record["segment_utf8_sha256"]:
            raise ValueError("#123 segment bytes differ from sealed evidence")
        if len(raw) != int(record["segment_byte_count"]) or record.get("utf8_boundary_safe") is not True:
            raise ValueError("#123 segment byte/boundary evidence drifted")
        documents.append(DocumentText(
            text=raw.decode("utf-8"), document_id=str(record["source_document_id"]),
            byte_offset=int(record["byte_offset"]), document_length=int(record["document_length"]),
        ))
    return documents


def _load_frontends(spectral_path: Path, byte_path: Path) -> tuple[LearnedSpectrumFrontend, ByteFrontend, dict[str, Any]]:
    if _file_sha256(spectral_path) != SPECTRAL_CHECKPOINT_SHA256:
        raise ValueError("frozen spectral checkpoint differs from #123/#162/#163")
    if _file_sha256(byte_path) != BYTE_CHECKPOINT_SHA256:
        raise ValueError("frozen byte checkpoint differs from #123/#162/#163")
    spectral_checkpoint = torch.load(spectral_path, map_location="cpu", weights_only=False)
    byte_checkpoint = torch.load(byte_path, map_location="cpu", weights_only=False)
    spectral_frontend = LearnedSpectrumFrontend(32, 4, "mean", "l2")
    spectral_model = FrontendLM(spectral_frontend, 32, heads=2, layers=1)
    spectral_model.load_state_dict(spectral_checkpoint["state_dict"], strict=True)
    byte_frontend = ByteFrontend(32)
    byte_model = NativeFrontendLM(byte_frontend, 32, heads=2, layers=1)
    byte_model.load_state_dict(byte_checkpoint["state_dict"], strict=True)
    spectral_frontend.eval(); byte_frontend.eval()
    for frontend in (spectral_frontend, byte_frontend):
        for parameter in frontend.parameters():
            parameter.requires_grad_(False)
    spectral_sha = module_state_fingerprint(spectral_frontend)
    byte_sha = module_state_fingerprint(byte_frontend)
    if spectral_sha != SPECTRAL_FRONTEND_SHA256 or byte_sha != BYTE_FRONTEND_SHA256:
        raise ValueError("frozen frontend module fingerprint drifted")
    if spectral_checkpoint["dataset_manifest_hash"] != byte_checkpoint["dataset_manifest_hash"]:
        raise ValueError("frozen references bind different datasets")
    return spectral_frontend, byte_frontend, {
        "spectral_checkpoint_sha256": SPECTRAL_CHECKPOINT_SHA256,
        "byte_checkpoint_sha256": BYTE_CHECKPOINT_SHA256,
        "spectral_frontend_module_sha256": spectral_sha,
        "byte_frontend_module_sha256": byte_sha,
        "dataset_manifest_sha256": spectral_checkpoint["dataset_manifest_hash"],
        "spectral_checkpoint_config_sha256": spectral_checkpoint["checkpoint_config_hash"],
        "byte_checkpoint_config_sha256": byte_checkpoint["checkpoint_config_hash"],
        "transmitter_modified_or_retuned": False,
        "receiver_loaded_or_retuned": False,
        "composition_exposed": False,
    }


def _poisoned(batch: TextBatch) -> TextBatch:
    return replace(batch, targets=(batch.targets + 113) % 256)


def _implementation_paths() -> dict[str, Path]:
    root = Path(__file__).resolve().parents[1]
    return {
        "src/domain_scaling_lab/retained_radius_topology.py": root / "src/domain_scaling_lab/retained_radius_topology.py",
        "scripts/run_retained_radius_topology.py": root / "scripts/run_retained_radius_topology.py",
        "scripts/publish_retained_radius_topology.py": root / "scripts/publish_retained_radius_topology.py",
        "tests/test_retained_radius_topology.py": root / "tests/test_retained_radius_topology.py",
    }


def _validate_preregistration(value: Mapping[str, Any]) -> None:
    expected = {
        "schema_version": "retained-radius-topology-preregistration/v1",
        "issue": 164,
        "qualifying_language_results_observed_before_freeze": False,
        "official_test_accessed": False,
        "issue_163_evidence_commit": ISSUE_163_EVIDENCE_COMMIT,
        "issue_163_result_sha256": ISSUE_163_RESULT_SHA256,
        "minimal_block_sha256": MINIMAL_BLOCK_SHA256,
        "inherited_config": config_wire(DEFAULT_CONFIG),
        "effective_depth": EFFECTIVE_DEPTH,
        "trained_conditions": list(TRAINED_CONDITIONS),
        "statistical_conditions": list(STATISTICAL_CONDITIONS),
        "topology_config": topology_wire(),
        "topology_config_sha256": topology_digest(),
    }
    for key, item in expected.items():
        if value.get(key) != item:
            raise ValueError(f"#164 preregistration drifted at {key}")
    matrix = value.get("condition_matrix")
    if not isinstance(matrix, Mapping) or any(matrix.get(condition) != condition_topology_config(condition) for condition in STATISTICAL_CONDITIONS):
        raise ValueError("#164 frozen condition matrix drifted")
    statistics = value.get("statistics")
    contrast_wire = {
        name: [{"condition": condition, "coefficient": coefficient} for condition, coefficient in terms]
        for name, terms in CONTRAST_DEFINITIONS.items()
    }
    if (
        not isinstance(statistics, Mapping)
        or int(statistics.get("decision_family_size", -1)) != DECISION_FAMILY_SIZE
        or float(statistics.get("materiality_nats_per_original_byte", -1)) != MATERIAL_NLL
        or float(statistics.get("equivalence_nats_per_original_byte", -1)) != EQUIVALENCE_NLL
        or float(statistics.get("familywise_alpha", -1)) != FAMILYWISE_ALPHA
        or int(statistics.get("bootstrap_samples", -1)) != BOOTSTRAP_SAMPLES
        or int(statistics.get("bootstrap_seed", -1)) != BOOTSTRAP_SEED
        or statistics.get("outcomes") != ["final", "aulc"]
        or statistics.get("contrasts") != contrast_wire
    ):
        raise ValueError("#164 frozen statistical policy drifted")
    resources = value.get("resource_policy")
    if (
        not isinstance(resources, Mapping)
        or float(resources.get("maximum_geometric_overhead_fraction", -1)) != MAX_GEOMETRIC_OVERHEAD_FRACTION
        or float(resources.get("parameter_efficiency_minimum_reduction_fraction", -1)) != PARAMETER_REDUCTION_FRACTION
        or resources.get("dense_flop_rule") != "exact equality across all four effective-depth-three primary arms"
        or resources.get("parameter_rule") != "shared/unit/retained exact equality; independent flat reports its required three operator copies"
    ):
        raise ValueError("#164 frozen resource policy drifted")
    stabilization = value.get("stabilization_policy")
    if (
        not isinstance(stabilization, Mapping)
        or float(stabilization.get("geometry_epsilon", -1)) != GEOMETRY_EPSILON
        or float(stabilization.get("reconstruction_tolerance", -1)) != RECONSTRUCTION_TOLERANCE
        or stabilization.get("post_freeze_changes_allowed") != "instrumentation defects only; no topology, threshold, source, capacity, budget, normalization, or projection changes"
    ):
        raise ValueError("#164 stabilization policy drifted")
    implementation = value.get("implementation_sha256")
    paths = _implementation_paths()
    if not isinstance(implementation, Mapping) or any(implementation.get(name) != _file_sha256(path) for name, path in paths.items()):
        raise ValueError("#164 preregistered implementation hash drifted")


def _remap_anchor_cell(cell: Mapping[str, Any]) -> dict[str, Any]:
    result = deepcopy(cell)
    if result.get("condition") != "spectral_phase_attention_only":
        raise ValueError("#163 anchor cell condition drifted")
    result["condition"] = ANCHOR
    result["topology_config"] = condition_topology_config(ANCHOR)
    for row in result["validation_learning_curve"]:
        row["condition"] = ANCHOR
        row["architecture"] = "exact-issue-163-depth1-anchor"
        row["stable_source_id"] = row["document_id"]
    for row in result["final_evaluation"]["documents"]:
        row["condition"] = ANCHOR
        row["architecture"] = "exact-issue-163-depth1-anchor"
        row["stable_source_id"] = row["document_id"]
    return result


def _preflight(
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    prepared: Any,
    *,
    spectral_frontend: LearnedSpectrumFrontend,
    byte_frontend: ByteFrontend,
) -> dict[str, Any]:
    synthetic = run_synthetic_controls()
    poisoned = prepare_topology_condition(
        _poisoned(calibration_batch), _poisoned(evaluation_batch),
        spectral_frontend=spectral_frontend, byte_frontend=byte_frontend,
    )
    target_poisoning = {
        "train_unchanged": prepared.canonical_train_fingerprint == poisoned.canonical_train_fingerprint,
        "evaluation_unchanged": prepared.canonical_evaluation_fingerprint == poisoned.canonical_evaluation_fingerprint,
    }
    initialization = {}
    for seed in DEFAULT_CONFIG.downstream_seeds:
        models = {condition: build_topology_predictor(condition, seed) for condition in STATISTICAL_CONDITIONS}
        component = {
            condition: {
                "first_block": module_state_fingerprint(model.blocks[0]),
                "head": module_state_fingerprint(model.head),
            }
            for condition, model in models.items()
        }
        initialization[str(seed)] = {
            "components": component,
            "all_first_blocks_equal": len({item["first_block"] for item in component.values()}) == 1,
            "all_heads_equal": len({item["head"] for item in component.values()}) == 1,
            "parameter_counts": {condition: parameter_count(model) for condition, model in models.items()},
        }
    dense = {
        condition: dense_forward_flops_for_depth(
            calibration_batch.input_ids.size(0), calibration_batch.input_ids.size(1), EFFECTIVE_DEPTH,
        )
        for condition in TRAINED_CONDITIONS
    }
    geometry = {
        condition: geometric_operations(condition, calibration_batch.input_ids.size(0), calibration_batch.input_ids.size(1))
        for condition in TRAINED_CONDITIONS
    }
    overhead = {condition: geometry[condition]["total"] / dense[condition] for condition in TRAINED_CONDITIONS}
    source = {
        "calibration_document_ids": list(calibration_batch.document_ids),
        "evaluation_document_ids": list(evaluation_batch.document_ids),
        "calibration_targets_sha256": tensor_state_fingerprint(calibration_batch.targets),
        "evaluation_targets_sha256": tensor_state_fingerprint(evaluation_batch.targets),
        "calibration_valid_sha256": tensor_state_fingerprint(calibration_batch.valid),
        "evaluation_valid_sha256": tensor_state_fingerprint(evaluation_batch.valid),
    }
    passed = (
        synthetic["passed"]
        and target_poisoning["train_unchanged"] and target_poisoning["evaluation_unchanged"]
        and all(item["all_first_blocks_equal"] and item["all_heads_equal"] for item in initialization.values())
        and len(set(dense.values())) == 1
        and max(overhead.values()) <= MAX_GEOMETRIC_OVERHEAD_FRACTION
        and bool(torch.isfinite(prepared.train_states).all() and torch.isfinite(prepared.evaluation_states).all())
    )
    return {
        "schema_version": "retained-radius-topology-real-input-controls/v1",
        "all_required_controls_passed": passed,
        "synthetic": synthetic,
        "target_poisoning": target_poisoning,
        "matched_initialization": initialization,
        "all_representative_inputs_finite": bool(torch.isfinite(prepared.train_states).all() and torch.isfinite(prepared.evaluation_states).all()),
        "dense_flops_per_calibration_batch": dense,
        "geometric_operations_per_calibration_batch": geometry,
        "geometric_overhead_fraction": overhead,
        "source_membership": source,
        "official_test_accessed": False,
    }


def _cell_without_performance(cell: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in cell.items() if key != "performance_ledger"}


def run(args: argparse.Namespace) -> dict[str, Any]:
    started = time.perf_counter()
    issue_123_path = Path(args.issue_123_results).resolve()
    issue_163_path = Path(args.issue_163_results).resolve()
    preregistration_path = Path(args.preregistration).resolve()
    if _file_sha256(issue_123_path) != ISSUE_123_RESULT_SHA256:
        raise ValueError("immutable #123 result differs from its published receipt")
    if _file_sha256(issue_163_path) != ISSUE_163_RESULT_SHA256:
        raise ValueError("immutable #163 result differs from its published receipt")
    issue_123 = _read_json(issue_123_path)
    issue_163 = _read_json(issue_163_path)
    if issue_163.get("scientific_payload_sha256") != ISSUE_163_SCIENTIFIC_PAYLOAD_SHA256 or issue_163.get("status") != "complete":
        raise ValueError("#163 scientific payload/disposition anchor drifted")
    minimal = issue_163.get("disposition", {}).get("minimal_polar_block", {})
    if minimal.get("condition") != "spectral_phase_attention_only" or minimal.get("config_sha256") != MINIMAL_BLOCK_SHA256:
        raise ValueError("#163 frozen minimal block drifted")
    preregistration = _read_json(preregistration_path)
    _validate_preregistration(preregistration)
    preregistration_sha256 = _file_sha256(preregistration_path)
    spectral_frontend, byte_frontend, upstream = _load_frontends(
        Path(args.spectral_checkpoint).resolve(), Path(args.byte_checkpoint).resolve(),
    )
    segments = issue_123["split_provenance"]["segments"]
    calibration_documents = _segments_to_documents(segments["calibration"])
    evaluation_documents = _segments_to_documents(segments["evaluation"])
    calibration_batch = spectral_frontend.batch_documents(calibration_documents)
    evaluation_batch = spectral_frontend.batch_documents(evaluation_documents)
    if calibration_batch.byte_count != DEFAULT_CONFIG.expected_calibration_bytes or evaluation_batch.byte_count != DEFAULT_CONFIG.expected_evaluation_bytes:
        raise ValueError("#164 source byte inventory drifted")
    frozen_before = {"spectral": module_state_fingerprint(spectral_frontend), "byte": module_state_fingerprint(byte_frontend)}
    prepared = prepare_topology_condition(
        calibration_batch, evaluation_batch,
        spectral_frontend=spectral_frontend, byte_frontend=byte_frontend,
    )
    controls = _preflight(
        calibration_batch, evaluation_batch, prepared,
        spectral_frontend=spectral_frontend, byte_frontend=byte_frontend,
    )
    if controls["all_required_controls_passed"] is not True:
        raise RuntimeError("#164 preflight failed; qualifying language training is blocked")
    if args.preflight_only:
        return {"status": "preflight-complete", "controls": controls, "upstream": upstream}

    cells = []
    for condition in TRAINED_CONDITIONS:
        for seed in DEFAULT_CONFIG.downstream_seeds:
            print(f"#164 fitting {condition} seed={seed}", flush=True)
            cell = fit_topology_condition(
                prepared, calibration_batch, evaluation_batch,
                condition=condition, seed=seed, device=args.device,
            )
            cells.append(cell)
            print(f"#164 complete {condition} seed={seed} NLL/byte={cell['final_evaluation']['byte_normalized_nll']:.9f}", flush=True)

    frozen_after = {"spectral": module_state_fingerprint(spectral_frontend), "byte": module_state_fingerprint(byte_frontend)}
    upstream_anchor = [
        cell for cell in issue_163["cells"]
        if cell["condition"] == "spectral_phase_attention_only"
    ]
    if sorted(int(cell["seed"]) for cell in upstream_anchor) != list(DEFAULT_CONFIG.downstream_seeds):
        raise ValueError("#163 anchor seed inventory drifted")
    anchor_cells = [_remap_anchor_cell(cell) for cell in upstream_anchor]
    representation_matched = len({cell["representation_provenance"]["canonical_train_fingerprint"] for cell in cells}) == 1
    representation_matched &= all(
        cell["representation_provenance"]["canonical_train_fingerprint"] == prepared.canonical_train_fingerprint
        and cell["representation_provenance"]["canonical_evaluation_fingerprint"] == prepared.canonical_evaluation_fingerprint
        for cell in cells
    )
    instrumentation_passed = (
        controls["all_required_controls_passed"]
        and frozen_before == frozen_after
        and representation_matched
        and all(cell["gradient_ledger"]["all_finite"] and cell["mechanism_diagnostics"]["all_finite"] for cell in cells)
    )
    trace = [row for cell in anchor_cells for row in cell["validation_learning_curve"]]
    trace.extend(row for cell in cells for row in cell["validation_learning_curve"])
    statistics = paired_document_bootstrap(trace)
    disposition = classify(statistics, cells, anchor_cells, instrumentation_passed=instrumentation_passed)
    deterministic_payload = {
        "preregistration_sha256": preregistration_sha256,
        "cells": [_cell_without_performance(cell) for cell in cells],
        "anchor": [_cell_without_performance(cell) for cell in anchor_cells],
        "statistics": statistics,
        "disposition": disposition,
        "split_membership_sha256": issue_123["split_provenance"]["selected_segment_membership_sha256"],
    }
    result = {
        "schema_version": "retained-radius-topology-results/v1",
        "issue": 164,
        "status": "complete" if instrumentation_passed else "invalid-instrumentation",
        "issue_163_evidence_commit": ISSUE_163_EVIDENCE_COMMIT,
        "issue_163_result_sha256": ISSUE_163_RESULT_SHA256,
        "issue_163_scientific_payload_sha256": ISSUE_163_SCIENTIFIC_PAYLOAD_SHA256,
        "issue_123_result_sha256": ISSUE_123_RESULT_SHA256,
        "minimal_block_sha256": MINIMAL_BLOCK_SHA256,
        "preregistration_sha256": preregistration_sha256,
        "preregistration": preregistration,
        "inherited_config": config_wire(DEFAULT_CONFIG),
        "topology_config": topology_wire(),
        "topology_config_sha256": topology_digest(),
        "condition_matrix": {condition: condition_topology_config(condition) for condition in STATISTICAL_CONDITIONS},
        "upstream_provenance": upstream,
        "split_provenance": {
            "calibration_document_ids": list(calibration_batch.document_ids),
            "evaluation_document_ids": list(evaluation_batch.document_ids),
            "calibration_byte_count": calibration_batch.byte_count,
            "evaluation_byte_count": evaluation_batch.byte_count,
            "selected_segment_membership_sha256": issue_123["split_provenance"]["selected_segment_membership_sha256"],
            "selection_segment_digest": issue_123["split_provenance"]["selection_segment_digest"],
            "source_disjoint": issue_123["split_provenance"]["source_disjoint"],
            "stable_source_ids_emitted": True,
            "test_accessed": False,
        },
        "instrumentation": {
            "controls": controls,
            "frozen_frontends_before": frozen_before,
            "frozen_frontends_after": frozen_after,
            "frozen_frontends_unchanged": frozen_before == frozen_after,
            "all_topology_inputs_bit_identical": representation_matched,
            "all_required_controls_passed": instrumentation_passed,
        },
        "cells": cells,
        "parameter_matched_depth1_anchor_cells": anchor_cells,
        "trace_count": len(trace),
        "trace_sha256": digest(trace),
        "statistics": statistics,
        "per_seed_contrasts": seed_contrasts(cells, anchor_cells),
        "disposition": disposition,
        "scientific_payload_sha256": digest(deterministic_payload),
        "deterministic_reproduction": {
            "canonical_json_sha256": digest(deterministic_payload),
            "excludes_nondeterministic_wall_time_throughput_and_process_rss": True,
            "replay_command": "python scripts/run_retained_radius_topology.py --issue-123-results <issue_123_results> --issue-163-results <issue_163_results> --spectral-checkpoint <spectral.pt> --byte-checkpoint <byte.pt> --preregistration <preregistration.json> --output <output.json>",
        },
        "runtime": {
            "python": sys.version,
            "torch": torch.__version__,
            "platform": platform.platform(),
            "device": args.device,
            "cuda_available": torch.cuda.is_available(),
            "elapsed_seconds": time.perf_counter() - started,
        },
        "test_split": {"status": "sealed-not-read", "accessed": False},
    }
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--issue-123-results", required=True)
    parser.add_argument("--issue-163-results", required=True)
    parser.add_argument("--spectral-checkpoint", required=True)
    parser.add_argument("--byte-checkpoint", required=True)
    parser.add_argument("--preregistration", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--preflight-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = run(args)
    _write_json(Path(args.output), result)
    print(json.dumps({
        "status": result["status"],
        "scientific_payload_sha256": result.get("scientific_payload_sha256"),
        "disposition": result.get("disposition"),
        "test_accessed": False,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
