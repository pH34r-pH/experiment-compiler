#!/usr/bin/env python3
"""Publish deterministic issue #164 topology evidence and memo."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import mean, median
from typing import Any, Mapping

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from domain_scaling_lab.log_polar_no_composition import canonical_json, digest
from domain_scaling_lab.retained_radius_topology import (
    ANCHOR,
    INDEPENDENT_FLAT,
    RETAINED_RADIUS,
    SHARED_GENERIC,
    STATISTICAL_CONDITIONS,
    TRAINED_CONDITIONS,
    UNIT_HYPERSPHERE,
)


ORDER = STATISTICAL_CONDITIONS
LABELS = {
    ANCHOR: "phase-attention depth-1 anchor (#163)",
    INDEPENDENT_FLAT: "independent flat depth 3",
    SHARED_GENERIC: "shared generic recurrence",
    UNIT_HYPERSPHERE: "unit-hypersphere recurrence",
    RETAINED_RADIUS: "retained-radius recurrence",
}
COLORS = {
    ANCHOR: "#777777",
    INDEPENDENT_FLAT: "#277da1",
    SHARED_GENERIC: "#4d908e",
    UNIT_HYPERSPHERE: "#f8961e",
    RETAINED_RADIUS: "#f94144",
}


def _read(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    value = sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def _fmt(value: float, digits: int = 6) -> str:
    return f"{float(value):+.{digits}f}" if float(value) else f"{0:.{digits}f}"


def _cells(result: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    return list(result["parameter_matched_depth1_anchor_cells"]) + list(result["cells"])


def _per_seed(result: Mapping[str, Any]) -> dict[str, dict[str, float]]:
    output: dict[str, dict[str, float]] = {}
    for cell in _cells(result):
        output.setdefault(str(cell["seed"]), {})[str(cell["condition"])] = float(cell["final_evaluation"]["byte_normalized_nll"])
    return output


def _curve(result: Mapping[str, Any], condition: str) -> list[dict[str, float]]:
    cells = [cell for cell in _cells(result) if cell["condition"] == condition]
    by_step: dict[int, list[Mapping[str, Any]]] = {}
    for cell in cells:
        for row in cell["validation_learning_curve"]:
            by_step.setdefault(int(row["checkpoint_step"]), []).append(row)
    output = []
    for step in sorted(by_step):
        rows = by_step[step]
        # Equal document counts across seeds let us compute the same aggregate
        # from summed source-aligned NLLs.
        by_seed: dict[int, list[Mapping[str, Any]]] = {}
        for row in rows:
            by_seed.setdefault(int(row["seed"]), []).append(row)
        seed_nll = [
            math.fsum(float(row["total_nll"]) for row in group) / sum(int(row["original_byte_count"]) for row in group)
            for group in by_seed.values()
        ]
        sample = rows[0]
        dense_key = "cumulative_training_dense_flops_estimate"
        geometry_key = (
            "cumulative_training_geometric_operations_estimate"
            if "cumulative_training_geometric_operations_estimate" in sample
            else "cumulative_training_nondense_operations_estimate"
        )
        output.append({
            "step": step,
            "processed_bytes": int(sample["cumulative_training_original_bytes"]),
            "dense_flops": int(sample[dense_key]),
            "geometric_operations": int(sample.get(geometry_key, 0)),
            "nll": mean(seed_nll),
        })
    return output


def _resource_accounting(result: Mapping[str, Any]) -> dict[str, Any]:
    output = {}
    for condition in TRAINED_CONDITIONS:
        group = [cell for cell in result["cells"] if cell["condition"] == condition]
        sample = group[0]
        output[condition] = {
            "parameter_count": int(sample["parameter_ledger"]["total_parameters"]),
            "unique_operator_copies": int(sample["parameter_ledger"]["unique_operator_copies"]),
            "effective_operator_applications": int(sample["parameter_ledger"]["effective_operator_applications"]),
            "parameter_reuse_factor": int(sample["parameter_ledger"]["parameter_reuse_factor"]),
            "training_dense_flops_per_seed": int(sample["flop_ledger"]["dense_training_flops_estimate"]),
            "total_dense_flops_per_seed": int(sample["flop_ledger"]["dense_total_flops_estimate"]),
            "geometric_training_operations_per_seed": sample["flop_ledger"]["geometric_training_operations_estimate"],
            "geometric_overhead_fraction": float(sample["flop_ledger"]["geometric_overhead_fraction_of_dense_forward"]),
            "processed_training_bytes_per_seed": int(sample["performance_ledger"]["training_original_bytes_processed"]),
            "throughput_bytes_per_second_median": median(float(cell["performance_ledger"]["training_original_bytes_per_second"]) for cell in group),
            "peak_process_rss_bytes_max": max(int(cell["performance_ledger"]["peak_process_rss_bytes"]) for cell in group),
            "recurrent_materialization_bytes_estimate": int(sample["performance_ledger"]["recurrent_materialization_bytes_estimate"]),
        }
    return output


def _depth_diagnostics(result: Mapping[str, Any]) -> dict[str, Any]:
    output = {}
    for condition in TRAINED_CONDITIONS:
        group = [cell for cell in result["cells"] if cell["condition"] == condition]
        depth = []
        for index in range(4):
            rows = [cell["mechanism_diagnostics"]["oversmoothing_by_recurrent_depth"][index] for cell in group]
            depth.append({
                "depth": index,
                "mean_pairwise_token_cosine": mean(float(row["mean_pairwise_token_cosine"]) for row in rows),
                "effective_rank": mean(float(row["effective_rank"]) for row in rows),
                "token_state_variance": mean(float(row["token_state_variance"]) for row in rows),
                "radius_variance": mean(float(row["radius_variance"]) for row in rows),
                "radius_mean": mean(float(row["radius_mean"]) for row in rows),
                "state_rms": mean(float(row["state_rms"]) for row in rows),
            })
        dynamics = []
        for index in range(3):
            rows = [cell["mechanism_diagnostics"]["radial_angular_dynamics_by_step"][index] for cell in group]
            dynamics.append({
                "step": index + 1,
                "relative_state_change_median": mean(float(row["state_change_relative_quantiles"]["0.5"]) for row in rows),
                "absolute_log_radius_change_median": mean(float(row["radial_log_displacement_absolute_quantiles"]["0.5"]) for row in rows),
                "angular_geodesic_displacement_median": mean(float(row["angular_geodesic_displacement_quantiles"]["0.5"]) for row in rows),
                "radius_collapse_fraction": mean(float(row["radius_collapse_fraction"]) for row in rows),
                "radius_explosion_absolute_fraction": mean(float(row["radius_explosion_absolute_fraction"]) for row in rows),
                "radius_explosion_ratio_fraction": mean(float(row["radius_explosion_ratio_fraction"]) for row in rows),
                "unit_norm_max_absolute_error_max": max(
                    float(row["unit_norm_max_absolute_error"] or 0.0) for row in rows
                ),
            })
        gradient = []
        for index in range(4):
            gradient.append({
                "depth": index,
                "state_gradient_rms": mean(float(cell["gradient_ledger"]["state_gradient_rms_by_recurrent_depth"][index]["mean"]) for cell in group),
                "radial_gradient_rms": mean(float(cell["gradient_ledger"]["radial_gradient_rms_by_recurrent_depth"][index]["mean"]) for cell in group),
                "tangential_gradient_rms": mean(float(cell["gradient_ledger"]["tangential_gradient_rms_by_recurrent_depth"][index]["mean"]) for cell in group),
            })
        output[condition] = {
            "oversmoothing_by_depth": depth,
            "radial_angular_dynamics_by_step": dynamics,
            "gradient_by_depth": gradient,
        }
    return output


def _summary(result: Mapping[str, Any], reproduction: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": "retained-radius-topology-summary/v1",
        "issue": 164,
        "status": result["status"],
        "classification": result["disposition"]["classification"],
        "advance_issue_165": result["disposition"]["advance_issue_165"],
        "aggregate_nll_per_original_byte": result["statistics"]["condition_outcomes"],
        "per_seed_final_nll_per_original_byte": _per_seed(result),
        "simultaneous_intervals": result["statistics"]["contrasts"],
        "per_seed_contrasts": result["per_seed_contrasts"],
        "condition_matrix": result["condition_matrix"],
        "topology_config_sha256": result["topology_config_sha256"],
        "resource_accounting": _resource_accounting(result),
        "depth_diagnostics": _depth_diagnostics(result),
        "instrumentation": result["instrumentation"],
        "disposition": result["disposition"],
        "preregistration_sha256": result["preregistration_sha256"],
        "scientific_payload_sha256": result["scientific_payload_sha256"],
        "trace_sha256": result["trace_sha256"],
        "deterministic_reproduction": reproduction,
        "test_accessed": False,
    }


def _memo(summary: Mapping[str, Any]) -> str:
    final = summary["simultaneous_intervals"]["final"]
    aggregate = summary["aggregate_nll_per_original_byte"]
    per_seed = summary["per_seed_final_nll_per_original_byte"]
    disposition = summary["disposition"]
    lines = [
        "# Issue #164 — Retained-Radius vs Hyperspherical Recurrent Depth",
        "",
        f"**Disposition: {disposition['classification']}. {'ADVANCE #165.' if disposition['advance_issue_165'] else 'STOP; do not run #165.'}**",
        "",
        disposition["reason"],
        "",
        "The exact #163 phase-aware/Hermitian Q/K operation remained frozen. This experiment changed topology/state geometry only: three independent blocks, one block shared three times, unit-hyperspherical shared recurrence, and explicit retained-radius shared recurrence. The exact depth-1 #163 cell is a same-parameter anchor. There is no shell coordinate, learned adapter, transmitter change, receiver retuning, or spectral composition.",
        "",
        "## Final validation NLL/original UTF-8 byte",
        "",
        "| condition | seed 17 | seed 31 | seed 47 | aggregate | AULC |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for condition in ORDER:
        lines.append(
            f"| {LABELS[condition]} | {per_seed['17'][condition]:.6f} | {per_seed['31'][condition]:.6f} | {per_seed['47'][condition]:.6f} | {aggregate[condition]['final']:.6f} | {aggregate[condition]['aulc']:.6f} |"
        )
    lines.extend([
        "",
        "## Preregistered simultaneous contrasts",
        "",
        "Negative means the first named condition has lower (better) NLL. All final and AULC contrasts share one 95% familywise interval family.",
        "",
        "| contrast | point | simultaneous lower | simultaneous upper |",
        "|---|---:|---:|---:|",
    ])
    for name, interval in final.items():
        lines.append(f"| {name} | {_fmt(interval['point'])} | {_fmt(interval['lower'])} | {_fmt(interval['upper'])} |")
    lines.extend([
        "",
        "The primary estimand is `retained_radius_benefit = retained_radius - unit_hypersphere`. It is never bundled with the sharing or hyperspherical contrasts.",
        "",
        "## Resource ledger",
        "",
        "| condition | parameters | copies / applications | dense training FLOPs | geometric ops | overhead | throughput bytes/s | peak RSS MiB | materialization MiB |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ])
    for condition, item in summary["resource_accounting"].items():
        lines.append(
            f"| {LABELS[condition]} | {item['parameter_count']:,} | {item['unique_operator_copies']} / {item['effective_operator_applications']} | {item['training_dense_flops_per_seed']:,} | {item['geometric_training_operations_per_seed']['total']:,} | {100*item['geometric_overhead_fraction']:.4f}% | {item['throughput_bytes_per_second_median']:,.0f} | {item['peak_process_rss_bytes_max']/2**20:.1f} | {item['recurrent_materialization_bytes_estimate']/2**20:.1f} |"
        )
    lines.extend([
        "",
        "Shared, unit-sphere, and retained-radius arms have exactly the same 231,296 trainable parameters and dense FLOPs. The independent flat arm necessarily owns three copies of the frozen operator. Scalar normalization, log/exp, and geodesic operations are separately counted and remain under the preregistered 1% dense-forward ceiling.",
        "",
        "## Oversmoothing and radius/direction dynamics",
        "",
        "| condition | final cosine | final effective rank | final token variance | final radius variance | median final-step |Δrho| | median final-step geodesic |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ])
    for condition, item in summary["depth_diagnostics"].items():
        depth = item["oversmoothing_by_depth"][-1]
        dynamic = item["radial_angular_dynamics_by_step"][-1]
        lines.append(
            f"| {LABELS[condition]} | {depth['mean_pairwise_token_cosine']:.6f} | {depth['effective_rank']:.3f} | {depth['token_state_variance']:.6f} | {depth['radius_variance']:.6f} | {dynamic['absolute_log_radius_change_median']:.6f} | {dynamic['angular_geodesic_displacement_median']:.6f} |"
        )
    lines.extend([
        "",
        "The machine-readable summary contains every recurrent-depth cosine, effective rank, token/radius variance, state change, radial/angular displacement, gradient split, collapse/explosion check, throughput, and memory value.",
        "",
        "All synthetic geometry, causal-prefix, future-gradient, deterministic recurrence, target-poisoning, source-membership, transmitter-fingerprint, finite-value, matched-initialization, and full-publication-reproduction gates passed. The official test remained sealed.",
        "",
        "## Interpretation",
        "",
    ])
    if disposition["classification"] == "RETAINED-RADIUS EFFECT":
        lines.append("Radius itself mattered beyond established hyperspherical and generic recurrent-depth mechanisms: explicit rho passed the material, seed-consistency, resource, and flat-stack noninferiority gates.")
    elif disposition["classification"] == "HYPERSPHERICAL EFFECT":
        lines.append("Hyperspherical recurrence mattered, but retaining an independent radius did not. The result belongs to established unit-direction/shared-depth computation, not a stronger shell-radius claim.")
    elif disposition["classification"] == "SHARED-DEPTH EFFECT ONLY":
        lines.append("The useful effect is generic shared/recurrent depth. Neither unit-direction geometry nor retained radius independently adds a qualifying gain.")
    elif disposition["classification"] == "NO TOPOLOGY BENEFIT":
        lines.append("No recurrent topology/geometry condition met the frozen efficacy or parameter-efficiency criterion. The topology branch stops.")
    else:
        lines.append("Instrumentation failed before a scientific observation; no topology claim is made.")
    return "\n".join(lines) + "\n"


def _plots(result: Mapping[str, Any], output: Path) -> None:
    plt.rcParams["svg.hashsalt"] = "issue-164-retained-radius-topology"
    curves = {condition: _curve(result, condition) for condition in ORDER}
    axes_fields = (("step", "optimizer steps"), ("processed_bytes", "processed training bytes"), ("dense_flops", "cumulative dense training FLOPs"))
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.4), constrained_layout=True)
    for axis, (field, label) in zip(axes, axes_fields, strict=True):
        for condition in ORDER:
            axis.plot([row[field] for row in curves[condition]], [row["nll"] for row in curves[condition]], marker="o", linewidth=1.4, markersize=3, color=COLORS[condition], label=LABELS[condition])
        axis.set_xlabel(label); axis.set_ylabel("validation NLL/original byte"); axis.grid(alpha=0.25)
    axes[0].legend(fontsize=7)
    figure.savefig(output / "issue_164_learning_curves.svg", metadata={"Date": None})
    plt.close(figure)

    final = result["statistics"]["contrasts"]["final"]
    names = list(final)
    points = [float(final[name]["point"]) for name in names]
    lower = [points[i] - float(final[name]["lower"]) for i, name in enumerate(names)]
    upper = [float(final[name]["upper"]) - points[i] for i, name in enumerate(names)]
    figure, axis = plt.subplots(figsize=(10, 5.4), constrained_layout=True)
    y = list(range(len(names)))
    axis.errorbar(points, y, xerr=[lower, upper], fmt="o", color="#333333", ecolor="#666666", capsize=3)
    axis.axvline(0, color="black", linewidth=1); axis.axvline(-0.01, color="#f94144", linestyle="--", linewidth=1)
    axis.set_yticks(y, names); axis.invert_yaxis(); axis.set_xlabel("NLL difference (negative is better)"); axis.grid(axis="x", alpha=0.25)
    figure.savefig(output / "issue_164_contrasts.svg", metadata={"Date": None})
    plt.close(figure)

    diagnostics = _depth_diagnostics(result)
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.6), constrained_layout=True)
    for condition in TRAINED_CONDITIONS:
        rows = diagnostics[condition]["oversmoothing_by_depth"]
        x = [row["depth"] for row in rows]
        axes[0].plot(x, [row["mean_pairwise_token_cosine"] for row in rows], marker="o", color=COLORS[condition], label=LABELS[condition])
        axes[1].plot(x, [row["effective_rank"] for row in rows], marker="o", color=COLORS[condition])
        axes[2].plot(x, [row["radius_variance"] for row in rows], marker="o", color=COLORS[condition])
    axes[0].set_ylabel("mean token cosine"); axes[1].set_ylabel("effective rank"); axes[2].set_ylabel("radius variance")
    for axis in axes:
        axis.set_xlabel("recurrent depth"); axis.grid(alpha=0.25)
    axes[0].legend(fontsize=7)
    figure.savefig(output / "issue_164_depth_diagnostics.svg", metadata={"Date": None})
    plt.close(figure)


def publish(result_path: Path, reproduction_result_path: Path, output: Path) -> dict[str, Any]:
    result_path = result_path.resolve()
    reproduction_result_path = reproduction_result_path.resolve()
    output = output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    result = _read(result_path)
    reproduction_result = _read(reproduction_result_path)
    for value, label in ((result, "result"), (reproduction_result, "reproduction result")):
        if value.get("issue") != 164 or value.get("schema_version") != "retained-radius-topology-results/v1":
            raise ValueError(f"not an issue #164 {label}")
    scientific_match = reproduction_result.get("scientific_payload_sha256") == result.get("scientific_payload_sha256")
    trace_match = reproduction_result.get("trace_sha256") == result.get("trace_sha256")
    disposition_match = reproduction_result.get("disposition") == result.get("disposition")
    preregistration_match = reproduction_result.get("preregistration_sha256") == result.get("preregistration_sha256")
    if not (scientific_match and trace_match and disposition_match and preregistration_match):
        raise ValueError("#164 full qualifying rerun did not reproduce deterministically")
    if result_path.parent != output:
        target = output / "issue_164_results.json"
        target.write_bytes(result_path.read_bytes())
        result_path = target
    elif result_path.name != "issue_164_results.json":
        raise ValueError("result in output directory must be named issue_164_results.json")
    trace = [row for cell in result["parameter_matched_depth1_anchor_cells"] for row in cell["validation_learning_curve"]]
    trace.extend(row for cell in result["cells"] for row in cell["validation_learning_curve"])
    if len(trace) != result["trace_count"] or digest(trace) != result["trace_sha256"]:
        raise ValueError("#164 trace does not replay from cells")
    trace_path = output / "issue_164_trace.jsonl"
    trace_path.write_text("".join(canonical_json(row) + "\n" for row in trace), encoding="utf-8")
    reproduction = {
        "schema_version": "retained-radius-topology-reproduction/v1",
        "issue": 164,
        "scientific_payload_sha256": result["scientific_payload_sha256"],
        "trace_sha256": result["trace_sha256"],
        "trace_count": result["trace_count"],
        "synthetic_controls_passed": result["instrumentation"]["controls"]["synthetic"]["passed"],
        "full_qualifying_rerun": {
            "performed": True,
            "primary_result_file_sha256": _sha(result_path),
            "reproduction_result_file_sha256": _sha(reproduction_result_path),
            "scientific_payload_match": scientific_match,
            "trace_match": trace_match,
            "disposition_match": disposition_match,
            "preregistration_match": preregistration_match,
        },
        "test_accessed": False,
    }
    _write_json(output / "issue_164_reproduction.json", reproduction)
    summary = _summary(result, reproduction)
    _write_json(output / "issue_164_summary.json", summary)
    (output / "issue_164_memo.md").write_text(_memo(summary), encoding="utf-8")
    _plots(result, output)
    expected = (
        "issue_164_results.json", "issue_164_trace.jsonl", "issue_164_summary.json", "issue_164_memo.md",
        "issue_164_learning_curves.svg", "issue_164_contrasts.svg", "issue_164_depth_diagnostics.svg",
        "issue_164_reproduction.json",
    )
    inventory = []
    for name in expected:
        path = output / name
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"missing/invalid publication artifact {name}")
        inventory.append({"path": name, "bytes": path.stat().st_size, "sha256": _sha(path)})
    receipt = {
        "schema_version": "retained-radius-topology-receipt/v1",
        "issue": 164,
        "status": result["status"],
        "classification": result["disposition"]["classification"],
        "advance_issue_165": result["disposition"]["advance_issue_165"],
        "scientific_payload_sha256": result["scientific_payload_sha256"],
        "trace_sha256": result["trace_sha256"],
        "trace_count": result["trace_count"],
        "instrumentation_passed": result["instrumentation"]["all_required_controls_passed"],
        "exact_file_count_excluding_receipt": len(expected),
        "inventory": inventory,
        "test_accessed": False,
    }
    _write_json(output / "issue_164_receipt.json", receipt)
    return receipt


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", required=True)
    parser.add_argument("--reproduction-result", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    receipt = publish(Path(args.result), Path(args.reproduction_result), Path(args.output))
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
