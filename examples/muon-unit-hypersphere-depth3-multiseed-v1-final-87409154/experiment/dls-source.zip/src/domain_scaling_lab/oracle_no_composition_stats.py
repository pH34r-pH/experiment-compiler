"""Frozen paired statistics for issue #123's oracle no-composition benchmark."""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from hashlib import sha256
import math
from typing import Any

import torch


ISSUE_NUMBER = 123
STATS_SCHEMA = "oracle-no-composition-statistics/v1"
SUMMARY_SCHEMA = "oracle-no-composition-summary-for-127/v1"
PRIMARY_ARCHITECTURE = "vanilla-transformer"
REPRESENTATION_CONDITIONS = (
    "byte_embedding",
    "spectral_current_uncomposed",
    "spectral_roles_uncomposed",
    "spectral_composite_raw",
    "spectral_composite_learned_matched",
    "spectral_roles_demultiplexed",
)
TRAINING_SEEDS = (17, 31, 47)
# Public aliases used by the runner/protocol manifest.  The older names above
# remain canonical within this file for compatibility with the initial draft.
CONDITION_ORDER = REPRESENTATION_CONDITIONS
DOWNSTREAM_SEEDS = TRAINING_SEEDS
CHECKPOINT_STEPS = (0, 8, 16, 32, 64, 96, 128)
BUDGET_FRACTIONS = (0.0, 1 / 16, 1 / 8, 1 / 4, 1 / 2, 3 / 4, 1.0)
EXPECTED_DOCUMENT_COUNT = 8
BOOTSTRAP_SAMPLES = 65_536
BOOTSTRAP_SEED = 12_365_536
CANONICAL_DRAW_SHA256 = "66ae49f1c3cad563b9d3a7c064975c7c06ace812a187be3358163557e80c8a24"
BOOTSTRAP_DRAWS_SHA256 = CANONICAL_DRAW_SHA256
FAMILYWISE_ALPHA = 0.05
MATERIAL_THRESHOLD = 0.01
EQUIVALENCE_MARGIN = 0.005
MOST_RECOVERED_FRACTION = 0.80

# Positive means the processed/right-hand stage is worse, except that
# demux_repair is deliberately positive when demultiplexing helps.
CONTRAST_DEFINITIONS: Mapping[str, tuple[tuple[str, float], ...]] = {
    "R": (("spectral_current_uncomposed", 1.0), ("byte_embedding", -1.0)),
    "C": (("spectral_composite_raw", 1.0), ("spectral_roles_uncomposed", -1.0)),
    "A": (("spectral_composite_learned_matched", 1.0), ("spectral_composite_raw", -1.0)),
    "P": (("spectral_composite_learned_matched", 1.0), ("spectral_roles_uncomposed", -1.0)),
    "D": (("spectral_roles_demultiplexed", 1.0), ("spectral_roles_uncomposed", -1.0)),
    "demux_repair": (("spectral_composite_raw", 1.0), ("spectral_roles_demultiplexed", -1.0)),
    "E": (("spectral_composite_learned_matched", 1.0), ("spectral_roles_demultiplexed", -1.0)),
}
PRIMARY_CONTRASTS = tuple(CONTRAST_DEFINITIONS)
DECISION_STATISTICS = (*PRIMARY_CONTRASTS, "H")
OUTCOMES = ("final", "aulc")
DECISION_FAMILY_SIZE = len(DECISION_STATISTICS) * len(OUTCOMES)


def _finite(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} must be finite")
    return float(value)


def _positive_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{label} must be a positive integer")
    return value


def integer_draw_sha256(draws: torch.Tensor) -> str:
    if draws.device.type != "cpu" or draws.dtype != torch.int64 or draws.ndim != 2:
        raise ValueError("bootstrap draws must be a two-dimensional CPU int64 tensor")
    value = draws.contiguous()
    digest = sha256()
    digest.update(str(tuple(value.shape)).encode("ascii"))
    digest.update(str(value.dtype).encode("ascii"))
    digest.update(value.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def aggregate_document_seeds(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Validate the exact primary grid and average seeds within each document."""
    if not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)) or not rows:
        raise ValueError("#123 statistics require non-empty document rows")
    cells: dict[tuple[str, int, str, int], tuple[float, int]] = {}
    document_bytes: dict[str, int] = {}
    documents: set[str] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            raise TypeError(f"row {index} must be a mapping")
        condition = row.get("condition")
        seed = row.get("seed")
        document = row.get("document_id")
        step = row.get("checkpoint_step")
        if condition not in REPRESENTATION_CONDITIONS:
            raise ValueError("unknown #123 representation condition")
        if isinstance(seed, bool) or seed not in TRAINING_SEEDS:
            raise ValueError("non-preregistered training seed")
        if not isinstance(document, str) or not document:
            raise ValueError("document_id must be non-empty")
        if isinstance(step, bool) or step not in CHECKPOINT_STEPS:
            raise ValueError("non-preregistered checkpoint")
        if row.get("architecture") != PRIMARY_ARCHITECTURE:
            raise ValueError("primary statistics require exact vanilla-transformer architecture")
        total = _finite(row.get("total_nll"), "total_nll")
        count = _positive_int(row.get("original_byte_count"), "original_byte_count")
        if total < 0:
            raise ValueError("total_nll must be nonnegative")
        normalized = _finite(row.get("byte_normalized_nll"), "byte_normalized_nll")
        if normalized < 0 or not math.isclose(
            normalized, total / count, abs_tol=1e-11, rel_tol=1e-9
        ):
            raise ValueError("byte_normalized_nll does not match total_nll/original_byte_count")
        if document in document_bytes and document_bytes[document] != count:
            raise ValueError("paired rows disagree on original-byte count")
        document_bytes[document] = count
        key = (str(condition), int(seed), document, int(step))
        if key in cells:
            raise ValueError("duplicate condition/seed/document/checkpoint cell")
        cells[key] = (total, count)
        documents.add(document)
    document_ids = sorted(documents)
    if len(document_ids) != EXPECTED_DOCUMENT_COUNT:
        raise ValueError("qualification requires exactly eight validation documents")
    expected = {
        (condition, seed, document, step)
        for condition in REPRESENTATION_CONDITIONS
        for seed in TRAINING_SEEDS
        for document in document_ids
        for step in CHECKPOINT_STEPS
    }
    if set(cells) != expected:
        raise ValueError(
            f"incomplete frozen statistics Cartesian product: {len(expected-set(cells))} missing, "
            f"{len(set(cells)-expected)} extra"
        )
    output: list[dict[str, Any]] = []
    for condition in REPRESENTATION_CONDITIONS:
        for document in document_ids:
            for step, fraction in zip(CHECKPOINT_STEPS, BUDGET_FRACTIONS, strict=True):
                values = [cells[(condition, seed, document, step)] for seed in TRAINING_SEEDS]
                output.append({
                    "condition": condition,
                    "document_id": document,
                    "checkpoint_step": step,
                    "budget_fraction": fraction,
                    "mean_total_nll": math.fsum(value[0] for value in values) / len(values),
                    "original_byte_count": values[0][1],
                    "seed_aggregation": "within-document arithmetic mean of fixed seeds",
                    "seeds": list(TRAINING_SEEDS),
                })
    return output


def byte_pooled_condition_outcomes(rows: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, float]]:
    """Byte-pool only after fixed seeds have been averaged within documents.

    The public interface accepts the immutable raw 1008-row primary grid.  An
    already aggregated grid is also accepted for internal bootstrap replay.
    """
    if not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)) or not rows:
        raise ValueError("condition outcomes require non-empty rows")
    if "seed" in rows[0]:
        rows = aggregate_document_seeds(rows)
    index: dict[tuple[str, int], list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        index[(str(row.get("condition")), int(row.get("checkpoint_step", -1)))].append(row)
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    output: dict[str, dict[str, float]] = {}
    for condition in REPRESENTATION_CONDITIONS:
        curve: list[float] = []
        for step in CHECKPOINT_STEPS:
            group = index[(condition, step)]
            if len(group) != EXPECTED_DOCUMENT_COUNT:
                raise ValueError("aggregated rows lack the frozen document/checkpoint grid")
            total = math.fsum(_finite(row.get("mean_total_nll"), "mean_total_nll") for row in group)
            count = sum(_positive_int(row.get("original_byte_count"), "original_byte_count") for row in group)
            curve.append(total / count)
        values = torch.tensor(curve, dtype=torch.float64)
        output[condition] = {"final": float(values[-1]), "aulc": float(torch.trapezoid(values, fractions))}
    return output


def primary_contrasts(
    outcomes: Mapping[str, Mapping[str, float]] | Sequence[Mapping[str, Any]],
) -> dict[str, dict[str, float]]:
    if not isinstance(outcomes, Mapping):
        outcomes = byte_pooled_condition_outcomes(outcomes)
    if set(outcomes) != set(REPRESENTATION_CONDITIONS):
        raise ValueError("condition outcomes are incomplete")
    result: dict[str, dict[str, float]] = {name: {} for name in OUTCOMES}
    for outcome in OUTCOMES:
        for name, terms in CONTRAST_DEFINITIONS.items():
            result[outcome][name] = math.fsum(
                coefficient * _finite(outcomes[condition].get(outcome), f"{condition}/{outcome}")
                for condition, coefficient in terms
            )
        result[outcome]["H"] = result[outcome]["D"] - 0.20 * result[outcome]["C"]
    return result


def paired_document_bootstrap(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    aggregated = aggregate_document_seeds(rows)
    documents = sorted({str(row["document_id"]) for row in aggregated})
    lookup = {(row["condition"], row["checkpoint_step"], row["document_id"]): row for row in aggregated}
    generator = torch.Generator(device="cpu").manual_seed(BOOTSTRAP_SEED)
    draws = torch.randint(len(documents), (BOOTSTRAP_SAMPLES, len(documents)), generator=generator, dtype=torch.int64)
    draw_hash = integer_draw_sha256(draws)
    if draw_hash != CANONICAL_DRAW_SHA256:
        raise RuntimeError("frozen #123 bootstrap integer schedule drifted")
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    replicates: dict[str, dict[str, torch.Tensor]] = {condition: {} for condition in REPRESENTATION_CONDITIONS}
    for condition in REPRESENTATION_CONDITIONS:
        curve = []
        for step in CHECKPOINT_STEPS:
            totals = torch.tensor([float(lookup[(condition, step, doc)]["mean_total_nll"]) for doc in documents], dtype=torch.float64)
            counts = torch.tensor([int(lookup[(condition, step, doc)]["original_byte_count"]) for doc in documents], dtype=torch.float64)
            curve.append(totals[draws].sum(1) / counts[draws].sum(1))
        values = torch.stack(curve, 1)
        replicates[condition] = {"final": values[:, -1], "aulc": torch.trapezoid(values, fractions, dim=1)}
    points = byte_pooled_condition_outcomes(aggregated)
    point_contrasts = primary_contrasts(points)
    replicate_contrasts: dict[str, dict[str, torch.Tensor]] = {outcome: {} for outcome in OUTCOMES}
    for outcome in OUTCOMES:
        for name, terms in CONTRAST_DEFINITIONS.items():
            replicate_contrasts[outcome][name] = sum(
                coefficient * replicates[condition][outcome] for condition, coefficient in terms
            )
        replicate_contrasts[outcome]["H"] = replicate_contrasts[outcome]["D"] - 0.20 * replicate_contrasts[outcome]["C"]
    per_alpha = FAMILYWISE_ALPHA / DECISION_FAMILY_SIZE
    quantiles = torch.tensor((per_alpha / 2, 1 - per_alpha / 2), dtype=torch.float64)
    intervals: dict[str, dict[str, dict[str, Any]]] = {outcome: {} for outcome in OUTCOMES}
    for outcome in OUTCOMES:
        for name in DECISION_STATISTICS:
            lower, upper = torch.quantile(replicate_contrasts[outcome][name], quantiles)
            intervals[outcome][name] = {
                "point": point_contrasts[outcome][name], "lower": float(lower), "upper": float(upper),
                "confidence": 1 - per_alpha, "familywise_confidence": 1 - FAMILYWISE_ALPHA,
                "resampling_unit": "source-document", "seed_aggregation": "within-document",
                "bootstrap_samples": BOOTSTRAP_SAMPLES,
            }
    definitions = {
        name: [{"condition": condition, "coefficient": coefficient} for condition, coefficient in terms]
        for name, terms in CONTRAST_DEFINITIONS.items()
    }
    return {
        "schema_version": STATS_SCHEMA, "issue": ISSUE_NUMBER,
        "primary_architecture": PRIMARY_ARCHITECTURE,
        "condition_order": list(REPRESENTATION_CONDITIONS), "checkpoint_steps": list(CHECKPOINT_STEPS),
        "budget_fractions": list(BUDGET_FRACTIONS), "training_seeds": list(TRAINING_SEEDS),
        "document_ids": documents, "document_count": len(documents), "condition_outcomes": points,
        "contrast_definitions": definitions,
        "most_recovered_definition": "H = D - 0.20*C; H <= 0 conditional on materially positive C",
        "contrasts": intervals,
        "bootstrap": {
            "method": "paired percentile source-document block bootstrap; fixed seeds averaged within each document before resampling; shared draws across all conditions/checkpoints",
            "samples": BOOTSTRAP_SAMPLES, "seed": BOOTSTRAP_SEED, "draws_sha256": draw_hash,
            "familywise_alpha": FAMILYWISE_ALPHA, "decision_family_size": DECISION_FAMILY_SIZE,
            "per_interval_two_sided_alpha": per_alpha, "lower_quantile": per_alpha / 2,
            "upper_quantile": 1 - per_alpha / 2,
            "float_replay_policy": {"cross_host_exact_hash_required": False, "validation": "semantic float comparison only (abs=1e-10, rel=1e-8)", "integer_draw_schedule_exact_hash_required": True},
        },
        "thresholds": {"material_nats_per_original_byte": MATERIAL_THRESHOLD, "equivalence_nats_per_original_byte": EQUIVALENCE_MARGIN, "most_recovered_fraction": MOST_RECOVERED_FRACTION},
    }


def interval_decision_flags(interval: Mapping[str, Any]) -> dict[str, bool | str]:
    point, lower, upper = (_finite(interval.get(key), key) for key in ("point", "lower", "upper"))
    # A percentile interval need not contain its plug-in point estimate when
    # the bootstrap distribution is sufficiently biased.  Only ordered,
    # finite bounds are an instrumentation invariant.
    if lower > upper:
        raise ValueError("interval bounds are reversed")
    positive = lower >= MATERIAL_THRESHOLD
    negative = upper <= -MATERIAL_THRESHOLD
    equivalent = lower >= -EQUIVALENCE_MARGIN and upper <= EQUIVALENCE_MARGIN
    unresolved = not (positive or negative or equivalent)
    state = (
        "material_worse" if positive else
        "material_better" if negative else
        "equivalent" if equivalent else
        "unresolved"
    )
    return {"material_positive": positive, "material_negative": negative, "material_worse": positive,
            "material_better": negative, "equivalent": equivalent,
            "unresolved": unresolved, "state": state}


def validate_statistics(value: Mapping[str, Any]) -> None:
    if value.get("schema_version") != STATS_SCHEMA or value.get("issue") != ISSUE_NUMBER:
        raise ValueError("unsupported #123 statistics identity")
    if value.get("primary_architecture") != PRIMARY_ARCHITECTURE:
        raise ValueError("primary architecture drifted")
    if tuple(value.get("condition_order", ())) != REPRESENTATION_CONDITIONS or tuple(value.get("checkpoint_steps", ())) != CHECKPOINT_STEPS:
        raise ValueError("condition/checkpoint policy drifted")
    if tuple(value.get("budget_fractions", ())) != BUDGET_FRACTIONS:
        raise ValueError("normalized training-byte AULC axis drifted")
    if tuple(value.get("training_seeds", ())) != TRAINING_SEEDS or value.get("document_count") != EXPECTED_DOCUMENT_COUNT:
        raise ValueError("seed/document policy drifted")
    documents = value.get("document_ids")
    if (
        not isinstance(documents, list)
        or len(documents) != EXPECTED_DOCUMENT_COUNT
        or documents != sorted(documents)
        or len(set(documents)) != EXPECTED_DOCUMENT_COUNT
        or any(not isinstance(document, str) or not document for document in documents)
    ):
        raise ValueError("paired validation-document inventory drifted")
    expected_thresholds = {"material_nats_per_original_byte": MATERIAL_THRESHOLD, "equivalence_nats_per_original_byte": EQUIVALENCE_MARGIN, "most_recovered_fraction": MOST_RECOVERED_FRACTION}
    if value.get("thresholds") != expected_thresholds:
        raise ValueError("thresholds drifted")
    bootstrap = value.get("bootstrap")
    expected_bootstrap = {"samples": BOOTSTRAP_SAMPLES, "seed": BOOTSTRAP_SEED, "draws_sha256": CANONICAL_DRAW_SHA256,
                          "familywise_alpha": FAMILYWISE_ALPHA, "decision_family_size": DECISION_FAMILY_SIZE,
                          "per_interval_two_sided_alpha": FAMILYWISE_ALPHA / DECISION_FAMILY_SIZE,
                          "lower_quantile": FAMILYWISE_ALPHA / (2 * DECISION_FAMILY_SIZE),
                          "upper_quantile": 1 - FAMILYWISE_ALPHA / (2 * DECISION_FAMILY_SIZE)}
    if not isinstance(bootstrap, Mapping):
        raise ValueError("bootstrap audit missing")
    for key, expected in expected_bootstrap.items():
        observed = bootstrap.get(key)
        if isinstance(expected, float):
            if not math.isclose(_finite(observed, key), expected, abs_tol=1e-15, rel_tol=0):
                raise ValueError(f"bootstrap {key} drifted")
        elif observed != expected:
            raise ValueError(f"bootstrap {key} drifted")
    if bootstrap.get("method") != (
        "paired percentile source-document block bootstrap; fixed seeds averaged "
        "within each document before resampling; shared draws across all "
        "conditions/checkpoints"
    ):
        raise ValueError("bootstrap resampling method drifted")
    if bootstrap.get("float_replay_policy") != {
        "cross_host_exact_hash_required": False,
        "validation": "semantic float comparison only (abs=1e-10, rel=1e-8)",
        "integer_draw_schedule_exact_hash_required": True,
    }:
        raise ValueError("bootstrap float/integer replay policy drifted")
    outcomes = value.get("condition_outcomes")
    if not isinstance(outcomes, Mapping) or set(outcomes) != set(REPRESENTATION_CONDITIONS):
        raise ValueError("condition outcomes incomplete")
    expected_points = primary_contrasts(outcomes)
    definitions = value.get("contrast_definitions")
    expected_defs = {name: [{"condition": c, "coefficient": k} for c, k in terms] for name, terms in CONTRAST_DEFINITIONS.items()}
    if definitions != expected_defs:
        raise ValueError("contrast definitions drifted")
    contrasts = value.get("contrasts")
    if not isinstance(contrasts, Mapping) or set(contrasts) != set(OUTCOMES):
        raise ValueError("contrast outcomes incomplete")
    for outcome in OUTCOMES:
        if set(contrasts[outcome]) != set(DECISION_STATISTICS):
            raise ValueError("decision family incomplete")
        for name, interval in contrasts[outcome].items():
            if not isinstance(interval, Mapping):
                raise ValueError("decision interval must be an object")
            interval_decision_flags(interval)
            if not math.isclose(float(interval["point"]), expected_points[outcome][name], abs_tol=1e-10, rel_tol=1e-8):
                raise ValueError("contrast point does not match outcomes")
            expected_metadata = {
                "confidence": 1 - FAMILYWISE_ALPHA / DECISION_FAMILY_SIZE,
                "familywise_confidence": 1 - FAMILYWISE_ALPHA,
                "resampling_unit": "source-document",
                "seed_aggregation": "within-document",
                "bootstrap_samples": BOOTSTRAP_SAMPLES,
            }
            for key, expected in expected_metadata.items():
                observed = interval.get(key)
                if isinstance(expected, float):
                    if not math.isclose(_finite(observed, key), expected, abs_tol=1e-15, rel_tol=0):
                        raise ValueError(f"interval {outcome}/{name} metadata drifted")
                elif observed != expected:
                    raise ValueError(f"interval {outcome}/{name} metadata drifted")


def _semantic_replay(expected: Any, observed: Any, path: str) -> None:
    """Exact structure/integer replay with the sealed #115 float boundary."""
    if isinstance(expected, Mapping):
        if not isinstance(observed, Mapping) or set(expected) != set(observed):
            raise ValueError(f"{path} keys do not replay")
        for key in expected:
            _semantic_replay(expected[key], observed[key], f"{path}.{key}")
        return
    if isinstance(expected, list):
        if not isinstance(observed, list) or len(expected) != len(observed):
            raise ValueError(f"{path} list does not replay")
        for index, (left, right) in enumerate(zip(expected, observed, strict=True)):
            _semantic_replay(left, right, f"{path}[{index}]")
        return
    if isinstance(expected, float):
        if not math.isclose(expected, _finite(observed, path), abs_tol=1e-10, rel_tol=1e-8):
            raise ValueError(f"{path} float does not replay")
        return
    if type(expected) is not type(observed) or expected != observed:
        raise ValueError(f"{path} does not replay")


def validate_statistics_against_rows(
    rows: Sequence[Mapping[str, Any]], value: Mapping[str, Any]
) -> None:
    """Regenerate every point, interval, and audit field from immutable trace rows."""
    validate_statistics(value)
    expected = paired_document_bootstrap(rows)
    _semantic_replay(expected, value, "statistics")


def decision_flags(statistics: Mapping[str, Any]) -> dict[str, Any]:
    validate_statistics(statistics)
    by_outcome = {outcome: {name: interval_decision_flags(statistics["contrasts"][outcome][name]) for name in DECISION_STATISTICS} for outcome in OUTCOMES}
    most_final = by_outcome["final"]["C"]["material_worse"] and float(statistics["contrasts"]["final"]["H"]["upper"]) <= 0
    most_aulc = by_outcome["aulc"]["C"]["material_worse"] and float(statistics["contrasts"]["aulc"]["H"]["upper"]) <= 0
    sensitive = []
    for name in DECISION_STATISTICS:
        def state(outcome: str) -> str:
            return str(by_outcome[outcome][name]["state"])
        if state("final") != state("aulc"):
            sensitive.append(name)
    return {"final": by_outcome["final"], "aulc": by_outcome["aulc"],
            "demux_most_recovered_final": most_final, "demux_most_recovered_aulc": most_aulc,
            "budget_sensitive": bool(sensitive), "budget_sensitive_contrasts": sensitive,
            "not_material_is_equivalence": False}


def classify_oracle_no_composition(statistics: Mapping[str, Any], *, instrumentation_passed: bool) -> dict[str, Any]:
    if instrumentation_passed is not True:
        return {"status": "invalid-instrumentation", "classification": "inconclusive / invalid instrumentation",
                "decision_eligible": False, "reason": "one or more preregistered instrumentation gates failed"}
    flags = decision_flags(statistics)
    final = flags["final"]
    if final["R"]["material_worse"] and final["C"]["material_worse"]:
        classification, reason = "mixed-representation-and-composition", "both source-matched representation and composition gaps are material"
    elif final["R"]["material_worse"]:
        classification, reason = "representation/downstream-geometry-precedes-composition", "the uncomposed current-symbol spectral condition is already materially behind byte"
    elif final["C"]["material_worse"] and not (final["R"]["equivalent"] or final["R"]["material_better"]):
        classification, reason = "composition-penalty-with-unresolved-representation", "composition is material while representation equivalence is unresolved"
    elif final["C"]["material_worse"] and flags["demux_most_recovered_final"]:
        if final["D"]["equivalent"] or final["D"]["material_better"]:
            classification = "receiver/composition-entanglement-dominant"
            reason = "demultiplexing recovers at least 80% and reaches or improves on the uncomposed condition"
        elif final["D"]["material_worse"]:
            classification = "receiver/composition-entanglement-dominant-with-residual"
            reason = "demultiplexing recovers at least 80% of the material composition gap, with a material residual versus uncomposed roles"
        else:
            classification = "receiver/composition-entanglement-dominant-residual-unresolved"
            reason = "demultiplexing recovers at least 80% of the material composition gap, while its residual interval is unresolved"
    elif final["C"]["material_worse"] and final["A"]["material_better"] and (final["P"]["equivalent"] or final["P"]["material_better"]):
        classification, reason = "fixed-receiver-recoverability/conditioning", "the frozen aggregate receiver materially repairs the composition penalty"
    elif final["C"]["material_worse"] and final["D"]["material_worse"]:
        classification, reason = "residual-composition/interface-limitation", "an operational residual remains after frozen explicit demultiplexing"
    elif final["C"]["material_worse"]:
        classification, reason = "raw-composition-penalty/recovery-inconclusive", "composition is material but recovery/residual rules remain unresolved"
    elif final["C"]["material_better"]:
        classification, reason = "raw-composite-material-advantage", "raw composite materially outperforms explicit uncomposed roles"
    elif final["C"]["equivalent"]:
        classification, reason = "no-detected-composition-penalty", "the simultaneous composition interval is within the equivalence margin"
    else:
        classification, reason = "inconclusive", "frozen materiality/equivalence rules do not select a disposition"
    return {"status": "complete", "classification": classification, "decision_eligible": True, "reason": reason,
            "flags": flags, "primary_outcome": "final validation NLL at frozen byte budget",
            "learning_curve_outcome": "normalized byte-budget validation-NLL AULC",
            "budget_sensitive": flags["budget_sensitive"],
            "causal_scope": "frozen representations, downstream recipe, receiver, and bounded budget only",
            "information_destruction_claim": False, "architecture_limited_claim": False,
            "final_121_classification_deferred_to_issue_127": True}


def summary_for_127(statistics: Mapping[str, Any], disposition: Mapping[str, Any]) -> dict[str, Any]:
    if disposition.get("decision_eligible") is not True:
        return {"schema_version": SUMMARY_SCHEMA, "issue": ISSUE_NUMBER, "status": disposition.get("status", "invalid-instrumentation"),
                "classification": disposition.get("classification", "inconclusive / invalid instrumentation"),
                "decision_eligible": False, "information_destruction_claim": False, "final_121_classification_deferred": True}
    flags = decision_flags(statistics)
    final = flags["final"]
    return {"schema_version": SUMMARY_SCHEMA, "issue": ISSUE_NUMBER, "status": disposition.get("status"),
            "classification": disposition.get("classification"), "decision_eligible": True,
            "representation_or_geometry_gap": final["R"]["material_worse"],
            "representation_source_matched_equivalence": final["R"]["equivalent"],
            "raw_composition_penalty": final["C"]["material_worse"], "raw_composition_equivalence": final["C"]["equivalent"],
            "fixed_receiver_material_repair": final["A"]["material_better"],
            "fixed_receiver_reaches_uncomposed": final["P"]["equivalent"] or final["P"]["material_better"],
            "demux_material_repair": final["demux_repair"]["material_positive"],
            "demux_reaches_uncomposed": final["D"]["equivalent"] or final["D"]["material_better"],
            "demux_residual_material": final["D"]["material_worse"], "demux_most_recovered": flags["demux_most_recovered_final"],
            "explicit_slots_materially_better_than_aggregate": final["E"]["material_positive"],
            "explicit_slots_equivalent_to_aggregate": final["E"]["equivalent"],
            "explicit_slots_materially_worse_than_aggregate": final["E"]["material_negative"],
            "budget_sensitive": flags["budget_sensitive"], "budget_sensitive_contrasts": flags["budget_sensitive_contrasts"],
            "information_destruction_claim": False, "bounded_decoder_failure_is_absence_claim": False,
            "architecture_limited_claim": False, "final_121_classification_deferred": True}


__all__ = [name for name in globals() if name.isupper()] + [
    "aggregate_document_seeds", "byte_pooled_condition_outcomes", "primary_contrasts",
    "paired_document_bootstrap", "integer_draw_sha256", "interval_decision_flags",
    "validate_statistics", "validate_statistics_against_rows", "decision_flags",
    "classify_oracle_no_composition", "summary_for_127",
]
