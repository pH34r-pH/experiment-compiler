"""Receiver-first probes for spectral superposition (issues #108--#111).

These are intentionally small analysis receivers.  They make role recovery,
cross-talk, code correlation, load, and parameter cost measurable before any
new transmitter family is credited with an improvement.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import math
from typing import Any, Literal, Sequence

import torch
from torch import nn
from torch.nn import functional as F


def role_vectors(window_length: int, dimension: int, *, device=None) -> torch.Tensor:
    """Deterministic unit-norm role signatures with low mutual correlation."""
    if window_length < 1 or dimension < window_length: raise ValueError("need dimension >= window length >= 1")
    index = torch.arange(dimension, dtype=torch.float32, device=device)
    rows = torch.stack([torch.cos(2 * math.pi * (role + 1) * index / dimension) for role in range(window_length)])
    return F.normalize(rows, dim=-1)


def compose_roles(symbols: torch.Tensor, roles: torch.Tensor) -> torch.Tensor:
    """Compose ``[batch, role, dim]`` symbols into a single received state."""
    if symbols.ndim != 3 or roles.shape != symbols.shape[1:]: raise ValueError("symbols/roles have incompatible shapes")
    return (symbols * roles[None]).sum(1)


ReceiverMode = Literal["raw", "fixed", "learned-matched", "unconstrained"]


def tensor_fingerprint(value: torch.Tensor) -> str:
    """Return a stable identity for a frozen tensor's shape, dtype, and values.

    This deliberately fingerprints the *received state*, rather than a module
    object or a configuration name.  A Phase-1 run can therefore prove that
    every receiver condition consumed exactly the same frozen transmitter
    output before a decoder sees it.
    """
    detached = value.detach().cpu().contiguous()
    digest = sha256()
    digest.update(str(tuple(detached.shape)).encode("ascii"))
    digest.update(str(detached.dtype).encode("ascii"))
    digest.update(detached.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def freeze_transmitter_(transmitter: nn.Module) -> nn.Module:
    """Freeze a transmitter in-place and keep it in deterministic eval mode."""
    transmitter.eval()
    for parameter in transmitter.parameters():
        parameter.requires_grad_(False)
    return transmitter


def _count_parameters(module: nn.Module | None) -> dict[str, int]:
    if module is None:
        return {"total": 0, "trainable": 0, "frozen": 0}
    total = sum(parameter.numel() for parameter in module.parameters())
    trainable = sum(parameter.numel() for parameter in module.parameters() if parameter.requires_grad)
    return {"total": total, "trainable": trainable, "frozen": total - trainable}


@dataclass(frozen=True)
class SpectralPrecompositionState:
    """True symbol and role states before the Gate-A mean/L2 operations.

    ``current_symbols`` are the position-rotated states emitted for each
    causal input ID.  ``role_slots`` gather those same states at every
    receiver offset without applying the transmitter's mean or L2 scaling.
    Consequently ``role_slots.sum(-2)`` exactly describes the raw additive
    superposition represented by ``pre_operator_composite``.  The
    ``pre_normalization_composite`` then applies only the declared sum/mean
    operator; it is the input to the optional L2 normalization.

    These are oracle analysis views of the existing transmitter.  They do not
    add a new transmitted channel or alter :class:`SpectralWindowState`'s
    established scaled-component semantics.
    """

    current_symbols: torch.Tensor
    canonical_current_symbols: torch.Tensor
    role_slots: torch.Tensor
    canonical_role_slots: torch.Tensor
    valid_roles: torch.Tensor
    pre_operator_composite: torch.Tensor
    pre_normalization_composite: torch.Tensor
    frequency: torch.Tensor
    transmitter_kind: str
    composition_operator: str
    composition_normalization: str

    @property
    def window_length(self) -> int:
        return self.role_slots.size(-2)

    @property
    def dimension(self) -> int:
        return self.role_slots.size(-1)


@dataclass(frozen=True)
class SpectralWindowState:
    """A frozen Gate-A composite state and its known analytical components.

    ``components`` are the actual transmitter contributions in the composed
    coordinate system.  ``canonical_components`` undo the transmitter's known
    complex phase at each temporal offset.  The latter is the target a fixed
    analytical receiver is allowed to recover; it is not a synthetic role
    tensor.  All tensors are detached so a receiver-only optimization cannot
    update the transmitter through this object.
    """

    composite: torch.Tensor
    components: torch.Tensor
    canonical_components: torch.Tensor
    role_phases: torch.Tensor
    valid_roles: torch.Tensor
    transmitter_kind: str
    transmitter_config: dict[str, Any]
    # Added for the #122/#123 decomposition program.  Existing fields above
    # retain their exact meanings, shapes, and construction.  The default
    # preserves compatibility with any external code that manually constructs
    # the historical seven-field state.
    precomposition: SpectralPrecompositionState | None = None

    @property
    def window_length(self) -> int:
        return self.components.size(-2)

    @property
    def dimension(self) -> int:
        return self.components.size(-1)

    @property
    def state_fingerprint(self) -> str:
        return tensor_fingerprint(self.composite)

    @property
    def precomposition_current_symbols(self) -> torch.Tensor | None:
        return None if self.precomposition is None else self.precomposition.current_symbols

    @property
    def precomposition_role_slots(self) -> torch.Tensor | None:
        return None if self.precomposition is None else self.precomposition.role_slots

    @property
    def pre_normalization_composite(self) -> torch.Tensor | None:
        return None if self.precomposition is None else self.precomposition.pre_normalization_composite


def _spectral_frontend(transmitter: nn.Module) -> nn.Module:
    """Accept either a Gate-A frontend or a ``FrontendLM`` owning one."""
    frontend = getattr(transmitter, "frontend", transmitter)
    if not isinstance(frontend, nn.Module):
        raise TypeError("transmitter must be a spectral frontend or an object with .frontend")
    return frontend


def _complex_rotation(vectors: torch.Tensor, phase: torch.Tensor) -> torch.Tensor:
    """Rotate packed ``[real..., imag...]`` vectors by per-channel phases."""
    if vectors.size(-1) % 2:
        raise ValueError("complex spectral receivers require an even state dimension")
    real, imag = vectors.chunk(2, dim=-1)
    cosine, sine = phase.to(dtype=vectors.dtype).cos(), phase.to(dtype=vectors.dtype).sin()
    return torch.cat((real * cosine - imag * sine, real * sine + imag * cosine), dim=-1)


def _raw_spectral_vectors(frontend: nn.Module, token_ids: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, str]:
    """Reproduce the uncomposed Gate-A complex state without redesigning it.

    The two supported cases mirror ``LearnedSpectrumFrontend.forward`` and
    ``OscillatorFrontend.forward`` exactly.  We intentionally keep this logic
    here, instead of changing a transmitter, because the receiver experiment
    must treat that transmitter as frozen.
    """
    if hasattr(frontend, "real") and hasattr(frontend, "imag"):
        embedding = frontend.real
        channels = embedding.embedding_dim
        positions = torch.arange(token_ids.size(1), device=token_ids.device, dtype=embedding.weight.dtype)
        frequency = 10_000.0 ** (-torch.arange(channels, device=token_ids.device, dtype=embedding.weight.dtype) / max(channels, 1))
        phase = positions[None, :, None] * frequency[None, None]
        real, imag = frontend.real(token_ids), frontend.imag(token_ids)
        vectors = torch.cat((real * phase.cos() - imag * phase.sin(), real * phase.sin() + imag * phase.cos()), dim=-1)
        canonical = torch.cat((real, imag), dim=-1)
        return vectors, canonical, frequency.detach(), "learned-spectrum"
    if hasattr(frontend, "amplitude") and hasattr(frontend, "phase") and hasattr(frontend, "frequency"):
        frequency = frontend.frequency.detach().to(device=token_ids.device)
        positions = torch.arange(token_ids.size(1), device=token_ids.device, dtype=frequency.dtype)
        phase = frontend.phase(token_ids) + positions[None, :, None] * frequency[None, None]
        amplitude = F.softplus(frontend.amplitude(token_ids))
        vectors = torch.cat((amplitude * phase.cos(), amplitude * phase.sin()), dim=-1)
        canonical = torch.cat((amplitude * frontend.phase(token_ids).cos(), amplitude * frontend.phase(token_ids).sin()), dim=-1)
        vectors = vectors.masked_fill(token_ids[..., None].eq(0), 0.0)
        canonical = canonical.masked_fill(token_ids[..., None].eq(0), 0.0)
        return vectors, canonical, frequency, "constrained-oscillator"
    raise TypeError("receiver requires LearnedSpectrumFrontend or OscillatorFrontend")


def _unscaled_role_slots(vectors: torch.Tensor, window_length: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Gather causal ``[B,T,D]`` symbols into unscaled ``[B,T,W,D]`` slots."""
    batch, time, dimension = vectors.shape
    offsets = torch.arange(window_length, device=vectors.device)
    positions = torch.arange(time, device=vectors.device)[:, None] - offsets[None, :]
    valid_roles = positions.ge(0)[None].expand(batch, -1, -1)
    slots = vectors.new_zeros(batch, time, window_length, dimension)
    for offset in range(window_length):
        if offset < time:
            slots[:, offset:, offset] = vectors[:, : time - offset]
    return slots, valid_roles


def freeze_spectral_precomposition_state(
    transmitter: nn.Module,
    token_ids: torch.Tensor,
) -> SpectralPrecompositionState:
    """Expose the frozen transmitter immediately before window composition.

    This public analysis interface mirrors the existing Gate-A transmitter;
    it never substitutes synthetic role vectors.  It is intentionally limited
    to the learned-spectrum and constrained-oscillator families already
    supported by :func:`freeze_spectral_window_state`.
    """
    frontend = _spectral_frontend(transmitter)
    # Duck-typing on ``real``/``imag`` is unsafe here: GlobalPositionFrontend
    # owns those attributes too, but applies an additional binding that the
    # fixed Gate-A precomposition path below does not reproduce.  Fail closed
    # until that binding has its own exact, tested decomposition.
    from .spectral import LearnedSpectrumFrontend, OscillatorFrontend
    if not isinstance(frontend, (LearnedSpectrumFrontend, OscillatorFrontend)):
        raise TypeError(
            "pre-composition analysis supports only LearnedSpectrumFrontend "
            "or OscillatorFrontend; globally bound frontends require an exact binding-aware interface"
        )
    if token_ids.ndim != 2:
        raise ValueError("token_ids must be [batch, time]")
    window_length = int(getattr(frontend, "window_length", 0))
    operator = getattr(frontend, "operator", None)
    normalization = getattr(frontend, "normalization", None)
    if window_length < 1 or operator not in {"sum", "mean"} or normalization not in {"none", "l2"}:
        raise TypeError("receiver requires a Gate-A spectral window frontend")

    freeze_transmitter_(frontend)
    with torch.no_grad():
        current, canonical, frequency, kind = _raw_spectral_vectors(frontend, token_ids)
        current, canonical = current.detach(), canonical.detach()
        role_slots, valid_roles = _unscaled_role_slots(current, window_length)
        canonical_role_slots, canonical_valid = _unscaled_role_slots(canonical, window_length)
        if not torch.equal(valid_roles, canonical_valid):  # pragma: no cover - construction invariant
            raise RuntimeError("transmitted and canonical role masks diverged")
        pre_operator = role_slots.sum(dim=-2)
        if operator == "mean":
            counts = torch.arange(
                1, token_ids.size(1) + 1, device=token_ids.device, dtype=current.dtype,
            ).clamp(max=window_length)
            pre_normalization = pre_operator / counts[None, :, None]
        else:
            pre_normalization = pre_operator

    return SpectralPrecompositionState(
        current_symbols=current,
        canonical_current_symbols=canonical,
        role_slots=role_slots.detach(),
        canonical_role_slots=canonical_role_slots.detach(),
        valid_roles=valid_roles.detach(),
        pre_operator_composite=pre_operator.detach(),
        pre_normalization_composite=pre_normalization.detach(),
        frequency=frequency.detach(),
        transmitter_kind=kind,
        composition_operator=str(operator),
        composition_normalization=str(normalization),
    )


def freeze_spectral_window_state(
    transmitter: nn.Module,
    token_ids: torch.Tensor,
    document_positions: torch.Tensor | None = None,
    document_lengths: torch.Tensor | None = None,
) -> SpectralWindowState:
    """Capture actual frozen Gate-A states plus per-offset analytical targets.

    The returned component sum reconstructs the frontend's exact composed
    state (up to floating-point rounding), including the configured sum/mean
    and L2 normalization.  ``role_phases`` contain ``-p * frequency`` for the
    original source position ``p=t-offset``; multiplying a composite by those
    phases is the fixed matched unbinding operation for the existing spectral
    transmitter, not a random-code proxy.
    """
    frontend = _spectral_frontend(transmitter)
    if token_ids.ndim != 2:
        raise ValueError("token_ids must be [batch, time]")
    window_length = int(getattr(frontend, "window_length", 0))
    operator = getattr(frontend, "operator", None)
    normalization = getattr(frontend, "normalization", None)
    if window_length < 1 or operator not in {"sum", "mean"} or normalization not in {"none", "l2"}:
        raise TypeError("receiver requires a Gate-A spectral window frontend")

    precomposition = freeze_spectral_precomposition_state(frontend, token_ids)
    with torch.no_grad():
        composite = frontend(
            token_ids,
            document_positions=document_positions,
            document_lengths=document_lengths,
        ).detach()

    batch_size, time, dimension = precomposition.current_symbols.shape
    positions = torch.arange(time, device=token_ids.device)[:, None] - torch.arange(
        window_length, device=token_ids.device,
    )[None, :]
    valid_roles = precomposition.valid_roles
    # Preserve the historical component construction exactly, now starting
    # from the explicitly exposed true pre-composition slots.
    components = precomposition.role_slots.clone()
    canonical_components = precomposition.canonical_role_slots.clone()

    # The frontend applies the mean before its optional L2 normalization.
    if operator == "mean":
        counts = torch.arange(
            1, time + 1, device=token_ids.device, dtype=precomposition.current_symbols.dtype,
        ).clamp(max=window_length)
        components = components / counts[None, :, None, None]
        canonical_components = canonical_components / counts[None, :, None, None]
    if normalization == "l2":
        denominator = components.sum(-2).norm(dim=-1, keepdim=True).clamp_min(1e-12)
        components = components / denominator[:, :, None]
        canonical_components = canonical_components / denominator[:, :, None]

    source_positions = positions.clamp_min(0).to(dtype=precomposition.frequency.dtype)
    role_phases = -source_positions[None, :, :, None] * precomposition.frequency[None, None, None, :]
    role_phases = role_phases.expand(batch_size, -1, -1, -1).detach()
    config = {
        "window_length": window_length,
        "composition_operator": operator,
        "composition_normalization": normalization,
        "dimension": dimension,
    }
    return SpectralWindowState(
        composite=composite,
        components=components.detach(),
        canonical_components=canonical_components.detach(),
        role_phases=role_phases,
        valid_roles=valid_roles.detach(),
        transmitter_kind=precomposition.transmitter_kind,
        transmitter_config=config,
        precomposition=precomposition,
    )


class ReceiverAnalysisBank(nn.Module):
    """Capacity-controlled raw, matched, and learned analyses of frozen states.

    Every non-raw condition receives the same declared role-coordinate
    scaffold: the transmitter's known time/offset phase is inverted before
    its per-role linear bank.  ``fixed`` therefore has an identity bank after
    analytical unbinding; ``learned-matched`` starts from that same identity;
    and ``unconstrained`` starts from independent orthogonal matrices with
    exactly the same ``W × D × D`` budget.  Giving the unconstrained control
    the same role-distinguishing coordinates is essential: otherwise
    averaging W copies of the raw composite would make most of its nominal
    parameters functionally redundant.
    """

    def __init__(self, window_length: int, dimension: int, mode: ReceiverMode = "fixed"):
        super().__init__()
        if window_length < 1 or dimension < 2 or dimension % 2:
            raise ValueError("receiver dimension must be even and window_length positive")
        if mode not in {"raw", "fixed", "learned-matched", "unconstrained"}:
            raise ValueError(f"unknown receiver mode {mode!r}")
        self.window_length, self.dimension, self.mode = window_length, dimension, mode
        identity = torch.eye(dimension).expand(window_length, -1, -1).clone()
        if mode == "unconstrained":
            analysis = torch.empty_like(identity)
            for matrix in analysis:
                nn.init.orthogonal_(matrix)
            self.analysis = nn.Parameter(analysis)
        elif mode == "learned-matched":
            self.analysis = nn.Parameter(identity)
        else:
            self.register_buffer("analysis", identity, persistent=True)

    @property
    def is_learned(self) -> bool:
        return self.mode in {"learned-matched", "unconstrained"}

    def _unpack(
        self,
        state: torch.Tensor | SpectralWindowState,
        role_phases: torch.Tensor | None,
        valid_roles: torch.Tensor | None,
    ) -> tuple[torch.Tensor, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None]:
        targets = None
        if isinstance(state, SpectralWindowState):
            if role_phases is not None or valid_roles is not None:
                raise ValueError("SpectralWindowState already supplies receiver role metadata")
            role_phases, valid_roles = state.role_phases, state.valid_roles
            targets = state.canonical_components if self.mode != "raw" else state.components
            state = state.composite
        if state.ndim != 3 or state.size(-1) != self.dimension:
            raise ValueError("receiver state must be [batch, time, dimension]")
        if role_phases is not None:
            expected = (*state.shape[:2], self.window_length, self.dimension // 2)
            if tuple(role_phases.shape) != expected:
                raise ValueError(f"role_phases must be {expected}")
        if valid_roles is not None and tuple(valid_roles.shape) != (*state.shape[:2], self.window_length):
            raise ValueError("valid_roles must be [batch, time, window_length]")
        return state, role_phases, valid_roles, targets

    def analyze(
        self,
        state: torch.Tensor | SpectralWindowState,
        *,
        role_phases: torch.Tensor | None = None,
        valid_roles: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Return one recovered ``D``-state per temporal offset, ``[B,T,W,D]``."""
        composite, role_phases, _, _ = self._unpack(state, role_phases, valid_roles)
        slots = composite[:, :, None, :].expand(-1, -1, self.window_length, -1)
        if self.mode != "raw" and role_phases is not None:
            slots = _complex_rotation(slots, role_phases)
        if self.mode == "raw":
            return slots
        return torch.einsum("btwd,wde->btwe", slots, self.analysis)

    def forward(
        self,
        state: torch.Tensor | SpectralWindowState,
        *,
        role_phases: torch.Tensor | None = None,
        valid_roles: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Produce a same-width receiver state suitable for the unchanged decoder."""
        composite, role_phases, valid_roles, _ = self._unpack(state, role_phases, valid_roles)
        if self.mode == "raw":
            return composite
        slots = self.analyze(composite, role_phases=role_phases, valid_roles=valid_roles)
        if valid_roles is None:
            return slots.mean(dim=-2)
        weights = valid_roles.to(dtype=slots.dtype)[..., None]
        return (slots * weights).sum(dim=-2) / weights.sum(dim=-2).clamp_min(1.0)

    def parameter_decomposition(self) -> dict[str, int | str]:
        """Expose receiver-only capacity, including frozen analytical matrices."""
        analysis = 0 if self.mode == "raw" else self.analysis.numel()
        trainable = sum(parameter.numel() for parameter in self.parameters() if parameter.requires_grad)
        return {
            "mode": self.mode,
            "analysis_parameters": analysis,
            "aggregation_parameters": 0,
            "receiver_total_parameters": analysis,
            "receiver_trainable_parameters": trainable,
            "receiver_frozen_parameters": analysis - trainable,
        }

    def diagnostics(
        self,
        state: torch.Tensor | SpectralWindowState,
        *,
        role_targets: torch.Tensor | None = None,
        role_phases: torch.Tensor | None = None,
        valid_roles: torch.Tensor | None = None,
    ) -> dict[str, Any]:
        """Report per-offset recovery, cross-talk, rank, and conditioning.

        Supplying a :class:`SpectralWindowState` automatically chooses actual
        Gate-A canonical targets for matched receivers and transmitted targets
        for raw/unconstrained controls.  Passing synthetic targets remains
        possible only for focused unit tests, never as an implicit default.
        """
        composite, role_phases, valid_roles, default_targets = self._unpack(state, role_phases, valid_roles)
        targets = role_targets if role_targets is not None else default_targets
        slots = self.analyze(composite, role_phases=role_phases, valid_roles=valid_roles)
        flat_analysis = self.analysis.reshape(-1, self.dimension)
        gram = flat_analysis.T @ flat_analysis
        result: dict[str, Any] = {
            "mode": self.mode,
            "state_fingerprint": tensor_fingerprint(composite),
            "analysis_rank": int(torch.linalg.matrix_rank(flat_analysis).detach()),
            "analysis_condition_number": float(torch.linalg.cond(gram).detach()),
            **self.parameter_decomposition(),
        }
        if targets is None:
            result |= {
                "per_offset_recovery": None,
                "mean_recovery": None,
                "cross_talk": None,
                "cross_talk_matrix": None,
            }
            return result
        if tuple(targets.shape) != tuple(slots.shape):
            raise ValueError("role_targets must be [batch, time, window_length, dimension]")
        diagonal = F.cosine_similarity(slots, targets, dim=-1)
        if valid_roles is None:
            valid_roles = torch.ones_like(diagonal, dtype=torch.bool)
        weights = valid_roles.to(dtype=diagonal.dtype)
        per_offset = (diagonal * weights).sum((0, 1)) / weights.sum((0, 1)).clamp_min(1.0)
        cross_values, cross_weights = [], []
        cross_matrix: list[list[float]] = []
        for receiver_offset in range(self.window_length):
            matrix_row: list[float] = []
            for source_offset in range(self.window_length):
                if receiver_offset == source_offset:
                    matrix_row.append(0.0)
                    continue
                value = F.cosine_similarity(
                    slots[:, :, receiver_offset],
                    targets[:, :, source_offset],
                    dim=-1,
                ).abs()
                pair_valid = valid_roles[:, :, receiver_offset] & valid_roles[:, :, source_offset]
                cross_values.append((value * pair_valid).sum())
                cross_weights.append(pair_valid.sum())
                matrix_row.append(float(
                    ((value * pair_valid).sum() / pair_valid.sum().clamp_min(1)).detach()
                ))
            cross_matrix.append(matrix_row)
        if cross_values:
            cross_talk = torch.stack(cross_values).sum() / torch.stack(cross_weights).sum().clamp_min(1)
        else:
            cross_talk = torch.zeros((), device=composite.device)
        result |= {
            "per_offset_recovery": per_offset.detach().tolist(),
            # Keep the legacy spelling as an alias for existing consumers.
            "per_role_recovery": per_offset.detach().tolist(),
            "mean_recovery": float((diagonal * weights).sum().detach() / weights.sum().clamp_min(1)),
            "cross_talk": float(cross_talk.detach()),
            "cross_talk_matrix": cross_matrix,
        }
        return result


def receiver_parameter_decomposition(
    receiver: ReceiverAnalysisBank,
    *,
    transmitter: nn.Module | None = None,
    decoder: nn.Module | None = None,
) -> dict[str, Any]:
    """Return a named transmitter/receiver/decoder parameter ledger."""
    transmitter_counts, decoder_counts = _count_parameters(transmitter), _count_parameters(decoder)
    receiver_counts = receiver.parameter_decomposition()
    total = transmitter_counts["total"] + int(receiver_counts["receiver_total_parameters"]) + decoder_counts["total"]
    trainable = transmitter_counts["trainable"] + int(receiver_counts["receiver_trainable_parameters"]) + decoder_counts["trainable"]
    return {
        "transmitter": transmitter_counts,
        "receiver": receiver_counts,
        "decoder_backbone": decoder_counts,
        "total_parameters": total,
        "total_trainable_parameters": trainable,
        "total_frozen_parameters": total - trainable,
    }


class FrozenSpectralReceiver(nn.Module):
    """Wrap one frozen Gate-A transmitter with one receiver-only analysis bank."""

    def __init__(self, transmitter: nn.Module, receiver: ReceiverAnalysisBank):
        super().__init__()
        self.transmitter = _spectral_frontend(transmitter)
        self.receiver = receiver
        freeze_transmitter_(self.transmitter)

    def train(self, mode: bool = True) -> "FrozenSpectralReceiver":
        # ``nn.Module.train`` would otherwise reactivate dropout mode on a
        # frozen transmitter when the receiver/decoder is optimized.
        super().train(mode)
        self.transmitter.eval()
        return self

    def window_state(
        self,
        token_ids: torch.Tensor,
        document_positions: torch.Tensor | None = None,
        document_lengths: torch.Tensor | None = None,
    ) -> SpectralWindowState:
        return freeze_spectral_window_state(
            self.transmitter,
            token_ids,
            document_positions=document_positions,
            document_lengths=document_lengths,
        )

    def forward_from_state(self, state: SpectralWindowState) -> torch.Tensor:
        return self.receiver(state)

    def forward(
        self,
        token_ids: torch.Tensor,
        document_positions: torch.Tensor | None = None,
        document_lengths: torch.Tensor | None = None,
    ) -> torch.Tensor:
        return self.forward_from_state(self.window_state(token_ids, document_positions, document_lengths))

    def parameter_decomposition(self, *, decoder: nn.Module | None = None) -> dict[str, Any]:
        return receiver_parameter_decomposition(self.receiver, transmitter=self.transmitter, decoder=decoder)


def build_receiver_variants(window_length: int, dimension: int) -> dict[str, ReceiverAnalysisBank]:
    """Build the four predeclared Phase-1 receiver conditions."""
    return {
        mode: ReceiverAnalysisBank(window_length, dimension, mode)  # type: ignore[arg-type]
        for mode in ("raw", "fixed", "learned-matched", "unconstrained")
    }


SpreadCodeFamily = Literal["random", "structured", "near-orthogonal", "learned"]


def _structured_spread_codes(window_length: int, dimension: int) -> torch.Tensor:
    """Real DCT rows: deterministic, orthogonal codes at the fixed dimension."""
    if window_length > dimension:
        raise ValueError(
            "structured orthogonal codes require window_length <= dimension; "
            "use near-orthogonal rather than increasing the code dimension"
        )
    channels = torch.arange(dimension, dtype=torch.float32) + 0.5
    orders = torch.arange(window_length, dtype=torch.float32)[:, None]
    return F.normalize(torch.cos(math.pi * orders * channels[None] / dimension), dim=-1)


class SpreadCodeAnalysisBank(nn.Module):
    """Same-dimension spread/despread analysis for the real Gate-A harness.

    Codes have shape ``[window_length, dimension]`` in every condition.  The
    structured condition uses DCT rows only when they fit in that fixed
    dimension; an overcomplete request must explicitly use the
    ``near-orthogonal`` control, so this class can never silently buy a larger
    representation to obtain orthogonality.  The learned condition optimizes
    exactly the same-size code tensor.
    """

    def __init__(
        self,
        window_length: int,
        dimension: int,
        family: SpreadCodeFamily = "random",
        *,
        seed: int = 17,
    ):
        super().__init__()
        if window_length < 1 or dimension < 2 or dimension % 2:
            raise ValueError("spread-code dimension must be even and window_length positive")
        if family not in {"random", "structured", "near-orthogonal", "learned"}:
            raise ValueError(f"unknown spread-code family {family!r}")
        self.window_length, self.dimension, self.family = window_length, dimension, family
        generator = torch.Generator().manual_seed(seed)
        if family == "structured":
            codes = _structured_spread_codes(window_length, dimension)
        else:
            # With W>D no real code family can be mutually orthogonal.  This
            # seeded normalized bank is therefore explicitly named
            # near-orthogonal rather than overclaiming its capacity.
            codes = F.normalize(torch.randn(window_length, dimension, generator=generator), dim=-1)
        if family == "learned":
            self.codes = nn.Parameter(codes)
        else:
            self.register_buffer("codes", codes, persistent=True)

    @property
    def is_learned(self) -> bool:
        return self.family == "learned"

    def _unpack(
        self,
        state: torch.Tensor | SpectralWindowState,
    ) -> tuple[torch.Tensor, torch.Tensor | None, torch.Tensor | None, torch.Tensor | None]:
        if isinstance(state, SpectralWindowState):
            return state.composite, state.role_phases, state.valid_roles, state.canonical_components
        if state.ndim != 3 or state.size(-1) != self.dimension:
            raise ValueError("spread-code state must be [batch, time, dimension]")
        return state, None, None, None

    def analyze(self, state: torch.Tensor | SpectralWindowState) -> torch.Tensor:
        """Apply known phase alignment and fixed-size elementwise despreading."""
        composite, role_phases, _, _ = self._unpack(state)
        slots = composite[:, :, None, :].expand(-1, -1, self.window_length, -1)
        if role_phases is not None:
            slots = _complex_rotation(slots, role_phases)
        # Unit-norm code multiplication has a dimension-dependent scale.  The
        # sqrt(D) factor preserves a comparable state magnitude for the same
        # downstream decoder without changing capacity.
        return slots * self.codes[None, None] * math.sqrt(self.dimension)

    def forward(self, state: torch.Tensor | SpectralWindowState) -> torch.Tensor:
        slots = self.analyze(state)
        _, _, valid_roles, _ = self._unpack(state)
        if valid_roles is None:
            return slots.mean(dim=-2)
        weights = valid_roles.to(dtype=slots.dtype)[..., None]
        return (slots * weights).sum(dim=-2) / weights.sum(dim=-2).clamp_min(1.0)

    def parameter_decomposition(self) -> dict[str, int | str]:
        total = self.codes.numel()
        trainable = sum(parameter.numel() for parameter in self.parameters() if parameter.requires_grad)
        return {
            "family": self.family,
            "code_dimension": self.dimension,
            "code_parameters": total,
            "receiver_total_parameters": total,
            "receiver_trainable_parameters": trainable,
            "receiver_frozen_parameters": total - trainable,
        }

    def diagnostics(
        self,
        state: torch.Tensor | SpectralWindowState,
        *,
        role_targets: torch.Tensor | None = None,
    ) -> dict[str, Any]:
        """Report code correlation and actual per-offset recovery/cross-talk."""
        composite, _, valid_roles, default_targets = self._unpack(state)
        slots = self.analyze(state)
        targets = role_targets if role_targets is not None else default_targets
        normalized = F.normalize(self.codes, dim=-1)
        correlation = normalized @ normalized.T
        off_diagonal = ~torch.eye(self.window_length, dtype=torch.bool, device=correlation.device)
        result: dict[str, Any] = {
            "family": self.family,
            "state_fingerprint": tensor_fingerprint(composite),
            "autocorrelation": float(torch.diag(correlation).mean().detach()),
            "cross_correlation_abs": float(correlation[off_diagonal].abs().mean().detach()) if off_diagonal.any() else 0.0,
            **self.parameter_decomposition(),
        }
        if targets is None:
            result |= {"per_offset_recovery": None, "mean_recovery": None, "cross_talk": None}
            return result
        if tuple(targets.shape) != tuple(slots.shape):
            raise ValueError("role_targets must be [batch, time, window_length, dimension]")
        diagonal = F.cosine_similarity(slots, targets, dim=-1)
        if valid_roles is None:
            valid_roles = torch.ones_like(diagonal, dtype=torch.bool)
        weights = valid_roles.to(dtype=diagonal.dtype)
        per_offset = (diagonal * weights).sum((0, 1)) / weights.sum((0, 1)).clamp_min(1.0)
        cross_values, cross_weights = [], []
        for receiver_offset in range(self.window_length):
            for source_offset in range(self.window_length):
                if receiver_offset == source_offset:
                    continue
                value = F.cosine_similarity(slots[:, :, receiver_offset], targets[:, :, source_offset], dim=-1).abs()
                pair_valid = valid_roles[:, :, receiver_offset] & valid_roles[:, :, source_offset]
                cross_values.append((value * pair_valid).sum())
                cross_weights.append(pair_valid.sum())
        cross_talk = (
            torch.stack(cross_values).sum() / torch.stack(cross_weights).sum().clamp_min(1)
            if cross_values
            else torch.zeros((), device=composite.device)
        )
        result |= {
            "per_offset_recovery": per_offset.detach().tolist(),
            "role_symbol_recovery": float((diagonal * weights).sum().detach() / weights.sum().clamp_min(1)),
            "mean_recovery": float((diagonal * weights).sum().detach() / weights.sum().clamp_min(1)),
            "cross_talk": float(cross_talk.detach()),
        }
        return result


class MatchedRoleReceiver(nn.Module):
    """Legacy synthetic analysis bank; not eligible as frozen-Gate-A evidence."""
    def __init__(self, window_length: int, dimension: int, mode: Literal["fixed", "learned-matched", "unconstrained"] = "fixed"):
        super().__init__(); self.window_length, self.dimension, self.mode = window_length, dimension, mode
        base = role_vectors(window_length, dimension)
        if mode == "fixed": self.register_buffer("analysis", base)
        elif mode == "learned-matched": self.analysis = nn.Parameter(base.clone())
        elif mode == "unconstrained": self.analysis = nn.Parameter(torch.empty_like(base)); nn.init.orthogonal_(self.analysis)
        else: raise ValueError("unknown receiver mode")

    def forward(self, received: torch.Tensor) -> torch.Tensor:
        return received[:, None, :] * self.analysis[None, :, :]

    def diagnostics(self, symbols: torch.Tensor) -> dict:
        roles = role_vectors(self.window_length, self.dimension, device=symbols.device); received = compose_roles(symbols, roles); recovered = self(received)
        diagonal = torch.stack([F.cosine_similarity(recovered[:, role], symbols[:, role], dim=-1) for role in range(self.window_length)], -1)
        cross = torch.stack([F.cosine_similarity(recovered[:, role], symbols[:, other], dim=-1).abs() for role in range(self.window_length) for other in range(self.window_length) if role != other], -1)
        gram = self.analysis @ self.analysis.T
        return {"mode": self.mode, "per_role_recovery": diagonal.mean(0).detach().tolist(), "mean_recovery": float(diagonal.mean().detach()), "cross_talk": float(cross.mean().detach()) if cross.numel() else 0.0, "analysis_condition_number": float(torch.linalg.cond(gram).detach()), "analysis_rank": int(torch.linalg.matrix_rank(gram).detach()), "parameters": sum(parameter.numel() for parameter in self.parameters()), "evidence_eligible": False}


class SpreadSpectrumReceiver(nn.Module):
    """Legacy synthetic code probe, explicitly not Phase-1 evidence.

    Use :class:`SpreadCodeAnalysisBank` with a
    :class:`SpectralWindowState` for the real same-dimension receiver
    experiment.  This small standalone simulator remains useful for unit
    tests, but its diagnostics carry ``evidence_eligible=False`` so it cannot
    be mistaken for a frozen-transmitter LM result.
    """
    def __init__(self, symbols: int, window_length: int, dimension: int, family: Literal["random", "orthogonal", "near-orthogonal", "learned"] = "random", seed: int = 17):
        super().__init__(); self.symbols, self.window_length, self.dimension, self.family = symbols, window_length, dimension, family
        generator = torch.Generator().manual_seed(seed)
        if family == "orthogonal":
            if dimension < symbols * window_length: raise ValueError("orthogonal codes need dimension >= symbols*window_length")
            code = torch.eye(dimension)[:symbols * window_length].reshape(symbols, window_length, dimension)
        else: code = F.normalize(torch.randn(symbols, window_length, dimension, generator=generator), dim=-1)
        if family == "learned": self.codes = nn.Parameter(code)
        elif family in {"random", "orthogonal", "near-orthogonal"}: self.register_buffer("codes", code)
        else: raise ValueError("unknown code family")

    def encode(self, ids: torch.Tensor) -> torch.Tensor:
        if ids.ndim != 2 or ids.shape[1] != self.window_length: raise ValueError("ids must be [batch, window_length]")
        selected = self.codes[ids, torch.arange(self.window_length, device=ids.device)[None]]
        return selected.sum(1)

    def decode(self, received: torch.Tensor) -> torch.Tensor:
        return torch.einsum("bd,srd->brs", received, self.codes)

    def diagnostics(self, ids: torch.Tensor, noise_std: float = 0.0) -> dict:
        received = self.encode(ids); noisy = received + noise_std * torch.randn_like(received); scores = self.decode(noisy); guesses = scores.argmax(-1); correct = guesses.eq(ids)
        flat = F.normalize(self.codes.flatten(0, 1), dim=-1); corr = flat @ flat.T; off = corr[~torch.eye(len(flat), dtype=torch.bool, device=corr.device)]
        return {"family": self.family, "role_symbol_recovery": float(correct.float().mean().detach()), "per_role_recovery": correct.float().mean(0).detach().tolist(), "autocorrelation": float(torch.diag(corr).mean().detach()), "cross_correlation_abs": float(off.abs().mean().detach()), "noise_std": noise_std, "parameters": sum(parameter.numel() for parameter in self.parameters()), "orthogonality_regime": "exact" if self.family == "orthogonal" else "near" if self.family == "near-orthogonal" else "random", "evidence_eligible": False}


def processing_gain_sweep(dimensions: Sequence[int], windows: Sequence[int], *, trials: int = 64, symbols: int = 32, seed: int = 7) -> list[dict]:
    """Synthetic diagnostic load curve, explicitly not Phase-1 evidence."""
    generator = torch.Generator().manual_seed(seed); rows = []
    for dimension in dimensions:
        for window in windows:
            if dimension < window: continue
            receiver = SpreadSpectrumReceiver(symbols, window, dimension, "random", seed)
            ids = torch.randint(symbols, (trials, window), generator=generator); metrics = receiver.diagnostics(ids)
            rows.append({"dimension": dimension, "window_length": window, "processing_gain": dimension / window, "load": window / dimension, "recovery_error": 1.0 - metrics["role_symbol_recovery"], "cross_talk": metrics["cross_correlation_abs"], "parameters": metrics["parameters"], "evidence_eligible": False})
    return rows


def receiver_synthesis(rows: Sequence[dict], *, raw_nll: float | None = None, repaired_nll: float | None = None) -> dict:
    """Deprecated diagnostic summary which never classifies #111 evidence.

    ``rows`` and two floats are not enough to establish a scientific result:
    they do not prove frozen-transmitter identity, dataset membership,
    validation-only tuning, matched budgets, or that the measurements came
    from a persisted Phase-1 run.  Real #111 classification is intentionally
    owned by ``synthesize_receiver_phase1`` after it validates its saved
    Phase-1 artifact.  Keep this helper only for backwards-compatible display
    of exploratory/synthetic diagnostics.
    """
    if not rows: raise ValueError("receiver synthesis requires results")
    best = max(rows, key=lambda row: row.get("mean_recovery", row.get("role_symbol_recovery", 0.0)))
    missing = [name for name, value in (("raw_byte_nll", raw_nll), ("repaired_byte_nll", repaired_nll)) if value is None or not math.isfinite(value)]
    recovery = best.get("mean_recovery", best.get("role_symbol_recovery", 0.0))
    downstream_gain = None if missing else raw_nll - repaired_nll  # type: ignore[operator]
    return {
        "status": "incomplete",
        "evidence_complete": False,
        "classification": None,
        "missing_evidence": ["validated_persisted_phase1_artifact", *missing],
        "strongest_receiver": best.get("mode", best.get("family")),
        "best_recovery": recovery,
        "diagnostic_downstream_byte_nll_gain": downstream_gain,
        "interpretation": "unvalidated receiver rows are diagnostic-only; use synthesize_receiver_phase1 on a validated saved Phase-1 artifact for #111 classification",
    }
