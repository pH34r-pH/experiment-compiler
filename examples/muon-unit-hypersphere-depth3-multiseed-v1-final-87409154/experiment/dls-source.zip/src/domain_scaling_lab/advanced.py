"""Curriculum-grade implementations for tokenization, attention, optimization, and scaling."""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
import math
import random
import torch
from torch import nn
from torch.nn import functional as F


class ByteBPE:
    """Deliberately small byte-level BPE: training, encode/decode, and merge-budget studies."""
    def __init__(self, merges: list[tuple[int, int]] | None = None): self.merges = merges or []
    def fit(self, texts: list[str], merges: int) -> "ByteBPE":
        words = [list(text.encode("utf-8")) for text in texts]
        for _ in range(merges):
            counts = Counter(pair for word in words for pair in zip(word, word[1:]))
            if not counts: break
            pair, _ = counts.most_common(1)[0]; self.merges.append(pair); token = 256 + len(self.merges) - 1
            words = [[token if i + 1 < len(w) and (w[i], w[i + 1]) == pair else w[i] for i in range(len(w)) if not (i and (w[i - 1], w[i]) == pair)] for w in words]
        return self
    def encode(self, text: str) -> list[int]:
        ids = list(text.encode("utf-8"))
        for rank, pair in enumerate(self.merges):
            out=[]; i=0
            while i < len(ids):
                if i + 1 < len(ids) and (ids[i], ids[i+1]) == pair: out.append(256 + rank); i += 2
                else: out.append(ids[i]); i += 1
            ids=out
        return ids
    def decode(self, ids: list[int]) -> str:
        def expand(token: int) -> list[int]:
            if token < 256: return [token]
            left, right = self.merges[token - 256]
            return expand(left) + expand(right)
        return bytes(byte for token in ids for byte in expand(token)).decode("utf-8")


def pack_documents(documents: list[list[int]], block_size: int, eos_id: int, pad_id: int = 0) -> tuple[list[list[int]], list[list[bool]], list[list[bool]]]:
    """Greedy EOS-aware packing returning tokens, loss mask, and same-document attention mask."""
    flat=[]; doc_ids=[]
    for doc_id, document in enumerate(documents): flat += document + [eos_id]; doc_ids += [doc_id] * (len(document)+1)
    blocks=[]; loss=[]; doc_masks=[]
    for start in range(0, len(flat), block_size):
        tokens=flat[start:start+block_size]; ids=doc_ids[start:start+block_size]; valid=len(tokens)
        tokens += [pad_id]*(block_size-valid); ids += [-1]*(block_size-valid)
        blocks.append(tokens); loss.append([i < valid for i in range(block_size)])
        doc_masks.append([ids[i] >= 0 and ids[i] == ids[j] and j <= i for i in range(block_size) for j in range(block_size)])
    return blocks, loss, doc_masks


def attention_diagnostics(batch: int = 2, time: int = 5, d_model: int = 16, heads: int = 4) -> dict[str, float | tuple[int,...]]:
    x=torch.randn(batch,time,d_model); d=d_model//heads; qkv=torch.randn(d_model,3*d_model); q,k,v=(x@qkv).chunk(3,-1)
    q,k,v=(z.view(batch,time,heads,d).transpose(1,2) for z in (q,k,v)); raw=q@k.transpose(-2,-1)
    manual=F.scaled_dot_product_attention(q,k,v,is_causal=True); scale=(torch.ones(time,time,dtype=torch.bool).tril())
    scores=(raw/math.sqrt(d)).masked_fill(~scale,float('-inf')); explicit=scores.softmax(-1)@v
    altered=v.clone(); altered[:,:, -1] += 1e6; leak=(F.scaled_dot_product_attention(q[:,:,:1],k,altered,is_causal=True)-manual[:,:,:1]).abs().max()
    return {"q_shape":tuple(q.shape),"raw_variance":float(raw.var()),"scaled_variance":float((raw/math.sqrt(d)).var()),"saturation":float(scores.softmax(-1).max()),"sdpa_gap":float((manual-explicit).abs().max()),"future_leak":float(leak)}


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float=1e-6): super().__init__(); self.weight=nn.Parameter(torch.ones(dim)); self.eps=eps
    def forward(self,x): return x*torch.rsqrt(x.square().mean(-1,keepdim=True)+self.eps)*self.weight


def rope(x: torch.Tensor, positions: torch.Tensor | None = None, base: float = 10000.0) -> torch.Tensor:
    d=x.size(-1); assert d%2==0
    pos=torch.arange(x.size(-2),device=x.device) if positions is None else positions.to(x.device)
    inv=base**(-torch.arange(0,d,2,device=x.device)/d); angles=pos[...,None]*inv
    cos,sin=angles.cos(),angles.sin(); even,odd=x[...,0::2],x[...,1::2]
    return torch.stack((even*cos-odd*sin,even*sin+odd*cos),-1).flatten(-2)


class GroupedQueryAttention(nn.Module):
    def __init__(self, dim:int, heads:int, kv_heads:int):
        super().__init__(); assert heads%kv_heads==0; self.heads,self.kv_heads,self.d=heads,kv_heads,dim//heads
        self.q=nn.Linear(dim,dim,bias=False); self.k=nn.Linear(dim,kv_heads*self.d,bias=False); self.v=nn.Linear(dim,kv_heads*self.d,bias=False); self.out=nn.Linear(dim,dim,bias=False)
    def forward(self,x,cache=None):
        b,t,_=x.shape; q=rope(self.q(x).view(b,t,self.heads,self.d).transpose(1,2)); k=rope(self.k(x).view(b,t,self.kv_heads,self.d).transpose(1,2)); v=self.v(x).view(b,t,self.kv_heads,self.d).transpose(1,2)
        if cache is not None: k=torch.cat([cache[0],k],2); v=torch.cat([cache[1],v],2)
        repeat=self.heads//self.kv_heads; k=k.repeat_interleave(repeat,1); v=v.repeat_interleave(repeat,1)
        return self.out(F.scaled_dot_product_attention(q,k,v,is_causal=cache is None).transpose(1,2).reshape(b,t,-1)), (k[:,:self.kv_heads],v[:,:self.kv_heads])


class ContemporaryBlock(nn.Module):
    def __init__(self, dim:int, heads:int, kv_heads:int, hidden:int|None=None):
        super().__init__(); self.norm1,self.norm2=RMSNorm(dim),RMSNorm(dim); self.attn=GroupedQueryAttention(dim,heads,kv_heads); h=hidden or int(8*dim/3)
        self.gate,self.up,self.down=nn.Linear(dim,h,bias=False),nn.Linear(dim,h,bias=False),nn.Linear(h,dim,bias=False)
    def forward(self,x):
        a,_=self.attn(self.norm1(x)); x=x+a; return x+self.down(F.silu(self.gate(self.norm2(x)))*self.up(self.norm2(x)))


def kv_cache_bytes(layers:int, batch:int, length:int, head_dim:int, kv_heads:int, dtype_bytes:int=2)->int: return 2*layers*batch*length*head_dim*kv_heads*dtype_bytes
def model_parameters(model:nn.Module)->int: return sum(p.numel() for p in model.parameters())
def train_flops(parameters:int,tokens:int)->int: return 6*parameters*tokens
def isoflop_allocations(compute:int, parameter_choices:list[int])->list[tuple[int,int]]: return [(n,compute//(6*n)) for n in parameter_choices if n>0]


class AdamWFromScratch:
    def __init__(self, params, lr=1e-3, betas=(.9,.999), eps=1e-8, weight_decay=.01): self.params=list(params); self.lr,self.betas,self.eps,self.wd=lr,betas,eps,weight_decay; self.state={}; self.step_count=0
    @torch.no_grad()
    def step(self):
        self.step_count+=1; b1,b2=self.betas
        for p in self.params:
            if p.grad is None: continue
            m,v=self.state.setdefault(id(p),(torch.zeros_like(p),torch.zeros_like(p))); g=p.grad; m.mul_(b1).add_(g,alpha=1-b1); v.mul_(b2).addcmul_(g,g,value=1-b2)
            p.mul_(1-self.lr*self.wd); p.addcdiv_(m/(1-b1**self.step_count), (v/(1-b2**self.step_count)).sqrt().add_(self.eps), value=-self.lr)


def warmup_cosine(step:int,total:int,warmup:int,peak:float)->float:
    if step<warmup:return peak*(step+1)/warmup
    return peak*.5*(1+math.cos(math.pi*(step-warmup)/max(1,total-warmup)))
def set_seed(seed:int)->dict[str,int]: random.seed(seed); torch.manual_seed(seed); return {"seed":seed,"torch_version":torch.__version__}

def rope_shift_invariant(q: torch.Tensor, k: torch.Tensor, shift: int = 3) -> bool:
    """RoPE preserves relative-position dot products under a common absolute shift."""
    positions=torch.arange(q.size(-2),device=q.device)
    a=rope(q,positions) @ rope(k,positions).transpose(-2,-1)
    b=rope(q,positions+shift) @ rope(k,positions+shift).transpose(-2,-1)
    return bool(torch.allclose(a,b,atol=1e-5))

def norm_and_swiglu_accounting(dim:int, hidden:int) -> dict[str,int]:
    return {"rmsnorm_parameters":dim,"swiglu_parameters":3*dim*hidden,"gelu_mlp_parameters":2*dim*hidden}

def optimizer_norms(parameters, before: list[torch.Tensor]) -> dict[str,float]:
    params=list(parameters); update=torch.cat([(p.detach()-b).flatten() for p,b in zip(params,before)])
    grad=torch.cat([p.grad.flatten() for p in params if p.grad is not None]); weights=torch.cat([p.detach().flatten() for p in params])
    return {"gradient_norm":float(grad.norm()),"parameter_norm":float(weights.norm()),"update_norm":float(update.norm())}

def clip_preserves_direction(gradient: torch.Tensor, max_norm: float) -> bool:
    p=torch.nn.Parameter(torch.zeros_like(gradient)); p.grad=gradient.clone()
    torch.nn.utils.clip_grad_norm_([p], max_norm)
    return bool(torch.allclose(p.grad/p.grad.norm(), gradient/gradient.norm(), atol=1e-6))

def optimizer_study(model_factory, tokens: torch.Tensor, steps: int = 8) -> dict[str, dict[str,float]]:
    result={}
    for name,scheduled,clipped in (("constant",False,False),("scheduled",True,False),("scheduled_clipped",True,True)):
        model=model_factory(); opt=torch.optim.AdamW(model.parameters(),lr=1e-3); first=None
        for step in range(steps):
            before=[p.detach().clone() for p in model.parameters()]; opt.zero_grad(); loss=model.loss(tokens); loss.backward()
            if clipped: torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
            if scheduled:
                for group in opt.param_groups: group['lr']=warmup_cosine(step,steps,2,1e-3)
            if first is None: first=optimizer_norms(model.parameters(),before)
            opt.step()
        state=next(iter(opt.state.values())); result[name]={"loss":float(loss.detach()),"moment_norm":float(state['exp_avg'].norm()),"bias_correction":1-opt.param_groups[0]['betas'][0]**steps,**first}
    return result

def tiny_capacity_study(model_factory, train: torch.Tensor, heldout: torch.Tensor, steps: int = 20) -> dict[str,dict[str,float]]:
    out={}
    for name,factory in model_factory.items():
        model=factory(); opt=torch.optim.AdamW(model.parameters(),lr=2e-3)
        for _ in range(steps): opt.zero_grad(); loss=model.loss(train); loss.backward(); opt.step()
        held=float(model.loss(heldout).detach()); out[name]={"parameters":model_parameters(model),"heldout_loss":held,"heldout_perplexity":math.exp(held),"sample_last_token":float(model.generate(heldout[:1,:2],4)[0,-1])}
    return out

def gradient_accumulation_equivalent(model: nn.Module, batch: torch.Tensor, microbatch: int) -> bool:
    left=type(model)(model.config); left.load_state_dict(model.state_dict()); right=type(model)(model.config); right.load_state_dict(model.state_dict())
    left.loss(batch).backward()
    for chunk in batch.split(microbatch): (right.loss(chunk) * (len(chunk)/len(batch))).backward()
    return all(torch.allclose(a.grad,b.grad,atol=1e-6) for a,b in zip(left.parameters(),right.parameters()))

def isoflop_sweep(results: list[tuple[int,int,float]]) -> dict[int,tuple[int,float]]:
    """Select lowest loss by compute bucket from (parameters, tokens, heldout_loss)."""
    buckets={}
    for n,d,loss in results:
        c=train_flops(n,d)
        if c not in buckets or loss<buckets[c][1]: buckets[c]=(n,loss)
    return buckets

def extrapolation_error(train_compute:list[float], train_loss:list[float], held_compute:float, held_loss:float) -> float:
    x=torch.tensor(train_compute).log(); y=torch.tensor(train_loss).log(); design=torch.stack([torch.ones_like(x),x],1); a,b=torch.linalg.lstsq(design,y).solution
    return abs(float((a+b*math.log(held_compute)).exp())-held_loss)

