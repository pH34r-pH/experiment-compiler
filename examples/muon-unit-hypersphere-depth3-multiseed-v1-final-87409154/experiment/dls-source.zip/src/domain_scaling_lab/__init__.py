"""Small, inspectable building blocks for the Domain Scaling Lab curriculum."""

from .data import CorpusRecord, DeterministicCharTokenizer, mix_records, normalize_text
from .experiments import CountBigramLM, NeuralBigramLM, diagnostic_scores, manual_cross_entropy, perplexity, train_neural_bigram
from .model import DecoderOnlyTransformer, TransformerConfig, causal_attention
from .training import TrainConfig, batch_iterator, evaluate, fit_power_law, train_steps

__all__ = [
    "CorpusRecord", "DecoderOnlyTransformer", "DeterministicCharTokenizer",
    "TrainConfig", "TransformerConfig", "batch_iterator", "causal_attention",
    "evaluate", "fit_power_law", "mix_records", "normalize_text", "train_steps",
    "CountBigramLM", "NeuralBigramLM", "diagnostic_scores", "manual_cross_entropy", "perplexity", "train_neural_bigram",
]


def main() -> None:
    print("Domain Scaling Lab: import the curriculum building blocks from Python.")

