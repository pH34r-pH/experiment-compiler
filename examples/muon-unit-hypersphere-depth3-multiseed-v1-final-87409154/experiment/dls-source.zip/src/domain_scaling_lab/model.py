"""Decoder-only Transformer components, kept intentionally explicit for study."""
from __future__ import annotations
from dataclasses import dataclass
import math
import torch
from torch import nn
from torch.nn import functional as F


def causal_attention(query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
    """Scaled dot-product causal attention for tensors shaped [batch, heads, time, dim]."""
    time = query.size(-2)
    scores = query @ key.transpose(-2, -1) / math.sqrt(query.size(-1))
    causal = torch.ones(time, key.size(-2), device=query.device, dtype=torch.bool).tril()
    scores = scores.masked_fill(~causal, float("-inf"))
    if mask is not None:
        scores = scores.masked_fill(~mask[:, None, None, :].bool(), float("-inf"))
    return F.softmax(scores, dim=-1) @ value


@dataclass(frozen=True)
class TransformerConfig:
    vocab_size: int
    block_size: int = 128
    d_model: int = 128
    n_heads: int = 4
    n_layers: int = 2
    dropout: float = 0.0


class TransformerBlock(nn.Module):
    def __init__(self, config: TransformerConfig):
        super().__init__()
        self.norm1, self.norm2 = nn.LayerNorm(config.d_model), nn.LayerNorm(config.d_model)
        self.attn = nn.MultiheadAttention(config.d_model, config.n_heads, batch_first=True, dropout=config.dropout)
        self.mlp = nn.Sequential(nn.Linear(config.d_model, 4 * config.d_model), nn.GELU(), nn.Linear(4 * config.d_model, config.d_model))

    def forward(self, x: torch.Tensor, padding_mask: torch.Tensor | None = None) -> torch.Tensor:
        length = x.size(1)
        causal = torch.ones(length, length, dtype=torch.bool, device=x.device).triu(1)
        y, _ = self.attn(self.norm1(x), self.norm1(x), self.norm1(x), attn_mask=causal, key_padding_mask=padding_mask)
        return x + y + self.mlp(self.norm2(x + y))


class DecoderOnlyTransformer(nn.Module):
    def __init__(self, config: TransformerConfig):
        super().__init__(); self.config = config
        self.token_embedding = nn.Embedding(config.vocab_size, config.d_model)
        self.position_embedding = nn.Embedding(config.block_size, config.d_model)
        self.blocks = nn.ModuleList([TransformerBlock(config) for _ in range(config.n_layers)])
        self.norm, self.head = nn.LayerNorm(config.d_model), nn.Linear(config.d_model, config.vocab_size, bias=False)
        self.head.weight = self.token_embedding.weight

    def forward(self, tokens: torch.Tensor, padding_mask: torch.Tensor | None = None) -> torch.Tensor:
        if tokens.size(1) > self.config.block_size: raise ValueError("sequence exceeds block_size")
        positions = torch.arange(tokens.size(1), device=tokens.device)
        x = self.token_embedding(tokens) + self.position_embedding(positions)
        for block in self.blocks: x = block(x, padding_mask)
        return self.head(self.norm(x))

    def loss(self, tokens: torch.Tensor, padding_mask: torch.Tensor | None = None) -> torch.Tensor:
        logits = self(tokens[:, :-1], None if padding_mask is None else ~padding_mask[:, :-1])
        targets = tokens[:, 1:]
        return F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1), ignore_index=0)

    @torch.no_grad()
    def generate(self, tokens: torch.Tensor, max_new_tokens: int, *, temperature: float = 1.0, greedy: bool = True) -> torch.Tensor:
        """Autoregressive generation; keeps only the usable causal context."""
        self.eval()
        for _ in range(max_new_tokens):
            logits = self(tokens[:, -self.config.block_size:])[:, -1] / temperature
            next_token = logits.argmax(-1, keepdim=True) if greedy else torch.multinomial(logits.softmax(-1), 1)
            tokens = torch.cat([tokens, next_token], dim=1)
        return tokens

