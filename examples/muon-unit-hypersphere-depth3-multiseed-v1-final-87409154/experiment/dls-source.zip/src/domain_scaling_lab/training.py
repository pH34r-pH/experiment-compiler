"""Reproducible, small-scale training and scaling-law measurement helpers."""
from __future__ import annotations
from dataclasses import dataclass
import torch
from torch import nn


@dataclass(frozen=True)
class TrainConfig:
    learning_rate: float = 3e-4
    weight_decay: float = 0.1
    grad_clip: float = 1.0


def batch_iterator(tokens: torch.Tensor, block_size: int, batch_size: int, *, seed: int = 0):
    generator = torch.Generator().manual_seed(seed)
    if tokens.numel() <= block_size: raise ValueError("need more tokens than block_size")
    while True:
        starts = torch.randint(0, tokens.numel() - block_size, (batch_size,), generator=generator)
        yield torch.stack([tokens[i:i + block_size] for i in starts])


def train_steps(model: nn.Module, batches, steps: int, config: TrainConfig = TrainConfig()) -> list[float]:
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    model.train(); losses = []
    for _ in range(steps):
        batch = next(batches); optimizer.zero_grad(set_to_none=True)
        loss = model.loss(batch); loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), config.grad_clip)
        optimizer.step(); losses.append(float(loss.detach()))
    return losses


@torch.no_grad()
def evaluate(model: nn.Module, batches, steps: int = 4) -> float:
    model.eval(); return sum(float(model.loss(next(batches))) for _ in range(steps)) / steps


def fit_power_law(compute: list[float], losses: list[float]) -> tuple[float, float]:
    """Fit loss ≈ a * compute**b in log space; useful only within observed range."""
    x, y = torch.tensor(compute).log(), torch.tensor(losses).log()
    design = torch.stack([torch.ones_like(x), x], dim=1)
    intercept, exponent = torch.linalg.lstsq(design, y).solution
    return float(intercept.exp()), float(exponent)

