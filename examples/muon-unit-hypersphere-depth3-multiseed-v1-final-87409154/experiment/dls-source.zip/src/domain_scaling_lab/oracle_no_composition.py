"""Issue #123 oracle no-composition benchmark primitives.

The benchmark deliberately changes only the representation exposed to a
fresh downstream predictor.  The Gate-A transmitter and the selected Phase-1
``learned-matched`` receiver remain frozen at D=32, W=4, seed=7.  Every input
condition is adapted to the same 128-coordinate contract with a parameter-
free mask/right-pad/flatten operation and one train-split-only scalar RMS.

This module contains no dataset selection and never reads the official test
split.  Runners supply source-disjoint calibration and evaluation batches and
are responsible for binding their sealed-split receipt to the returned cell.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
import math
import resource
import sys
import time
from typing import Any, Mapping, Sequence

import torch
from torch import nn
from torch.nn import functional as F

from .representation_conditions import (
    REPRESENTATION_CONDITION_NAMES,
    RepresentationView,
    build_representation_bundle,
)
from .receivers import ReceiverAnalysisBank
from .spectral import (
    ByteFrontend,
    FrontendLM,
    LearnedSpectrumFrontend,
    TextBatch,
    module_state_fingerprint,
    tensor_state_fingerprint,
)


ISSUE_NUMBER = 123
CONFIG_SCHEMA = "oracle-no-composition-config/v1"
CELL_SCHEMA = "oracle-no-composition-cell/v1"
CONTROL_SCHEMA = "oracle-no-composition-controls/v1"
CANONICAL_SCHEMA = "oracle-no-composition-canonical-representation/v1"
RMS_SCHEMA = "oracle-no-composition-rms-calibration/v1"

DOWNSTREAM_FAMILIES = (
    "linear",
    "shallow-mlp",
    "vanilla-transformer",
    "bounded-oracle-transformer",
)


def _jsonable(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


def _wire(value: Any) -> str:
    return json.dumps(
        _jsonable(value), ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False,
    )


def _digest(value: Any) -> str:
    return sha256(_wire(value).encode("utf-8")).hexdigest()


def _is_sha256(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


@dataclass(frozen=True)
class OracleNoCompositionConfig:
    """Frozen architecture, optimization, control, and decision policy."""

    schema_version: str = CONFIG_SCHEMA
    profile: str = "qualifying"
    primary_dimension: int = 32
    primary_window: int = 4
    phase1_seed: int = 7
    downstream_seeds: tuple[int, ...] = (17, 31, 47)
    downstream_families: tuple[str, ...] = DOWNSTREAM_FAMILIES
    canonical_width: int = 128
    updates: int = 128
    checkpoint_steps: tuple[int, ...] = (0, 8, 16, 32, 64, 96, 128)
    batch_schedule: str = "full-calibration-batch-repeated"
    learning_rate: float = 1e-3
    weight_decay: float = 1e-2
    gradient_clip_norm: float = 1.0
    rms_epsilon: float = 1e-8
    shallow_width: int = 128
    transformer_heads: int = 4
    vanilla_transformer_layers: int = 1
    bounded_oracle_layers: int = 2
    bounded_oracle_parameter_cap: int = 1_000_000
    position_encoding: str = "fixed-sinusoidal-transformer-only"
    expected_calibration_documents: int = 8
    expected_evaluation_documents: int = 8
    expected_segment_bytes: int = 224
    expected_evaluation_document_bytes: tuple[int, ...] = (224, 224, 224, 224, 109, 224, 224, 224)
    material_nll_threshold: float = 0.01
    equivalence_nll_margin: float = 0.005
    demux_fraction_required: float = 0.80
    bootstrap_samples: int = 65_536
    bootstrap_seed: int = 12_365_536
    control_seed: int = 123_007
    control_updates: int = 96
    control_learning_rate: float = 0.005
    pointwise_positive_min: float = 0.98
    temporal_effect_min: float = 1e-8
    future_gradient_max: float = 1e-10
    invertible_mix_nrmse_max: float = 1e-6
    invertible_decoder_logit_max: float = 1e-5
    alias_ceiling_tolerance: float = 1e-12

    def validate(self) -> None:
        if self.schema_version != CONFIG_SCHEMA:
            raise ValueError("unsupported #123 config schema")
        if self.profile not in {"qualifying", "fixture"}:
            raise ValueError("profile must be qualifying or fixture")
        if (self.primary_dimension, self.primary_window, self.phase1_seed) != (32, 4, 7):
            raise ValueError("the #111 learned-matched reference is fixed at D32/W4/seed7")
        if tuple(self.downstream_seeds) != (17, 31, 47):
            raise ValueError("the preregistered downstream seeds are fixed")
        if tuple(self.downstream_families) != DOWNSTREAM_FAMILIES:
            raise ValueError("the downstream architecture ladder drifted")
        if self.canonical_width != self.primary_dimension * self.primary_window:
            raise ValueError("canonical width must be D*W=128")
        if self.updates < 1 or len(self.checkpoint_steps) != 7:
            raise ValueError("exactly seven checkpoints, including zero and final, are required")
        if tuple(sorted(set(self.checkpoint_steps))) != tuple(self.checkpoint_steps):
            raise ValueError("checkpoint steps must be unique and increasing")
        if self.checkpoint_steps[0] != 0 or self.checkpoint_steps[-1] != self.updates:
            raise ValueError("checkpoint schedule must include zero and the final update")
        if self.batch_schedule != "full-calibration-batch-repeated":
            raise ValueError("the paired full-batch schedule is frozen")
        if not 0 < self.learning_rate <= 0.1 or not 0 <= self.weight_decay <= 0.1:
            raise ValueError("invalid AdamW hyperparameters")
        if self.gradient_clip_norm <= 0 or self.rms_epsilon <= 0:
            raise ValueError("invalid numerical policy")
        if self.shallow_width != 128 or self.transformer_heads != 4:
            raise ValueError("the common-width shallow/attention architecture is frozen")
        if (self.vanilla_transformer_layers, self.bounded_oracle_layers) != (1, 2):
            raise ValueError("the one-layer/two-layer Transformer ladder is frozen")
        if self.position_encoding != "fixed-sinusoidal-transformer-only":
            raise ValueError("learned or condition-specific positions are deferred to #125")
        if self.bounded_oracle_parameter_cap != 1_000_000:
            raise ValueError("the bounded-oracle parameter cap drifted")
        if (self.expected_calibration_documents, self.expected_evaluation_documents) != (8, 8):
            raise ValueError("the source-disjoint 8/8 selection is frozen")
        if self.expected_segment_bytes != 224:
            raise ValueError("the #122 segment budget is frozen")
        if self.expected_evaluation_document_bytes != (224, 224, 224, 224, 109, 224, 224, 224):
            raise ValueError("the exact #122 validation segment byte counts drifted")
        if (self.material_nll_threshold, self.equivalence_nll_margin) != (0.01, 0.005):
            raise ValueError("the preregistered NLL thresholds drifted")
        if self.demux_fraction_required != 0.80:
            raise ValueError("the demultiplexing recovery fraction drifted")
        if (self.bootstrap_samples, self.bootstrap_seed) != (65_536, 12_365_536):
            raise ValueError("the paired bootstrap policy drifted")
        if not 0.9 <= self.pointwise_positive_min <= 1:
            raise ValueError("invalid pointwise control threshold")
        if not 0 < self.invertible_mix_nrmse_max <= 1e-4:
            raise ValueError("invalid invertible-mix threshold")
        if not 0 < self.invertible_decoder_logit_max <= 1e-3:
            raise ValueError("invalid invertible decoder-path threshold")
        if self.control_updates < 1 or not 0 < self.control_learning_rate <= 0.01:
            raise ValueError("bounded control budget must be positive")
        if self.profile == "qualifying":
            if self.updates != 128 or self.checkpoint_steps != (0, 8, 16, 32, 64, 96, 128):
                raise ValueError("qualifying optimization/checkpoint budget drifted")
            if self.control_updates != 96 or self.control_learning_rate != 0.005:
                raise ValueError("qualifying machinery-control budget drifted")


DEFAULT_CONFIG = OracleNoCompositionConfig()


def fast_fixture_config() -> OracleNoCompositionConfig:
    """Return a small, still seven-checkpoint config for tests and fixtures."""

    config = replace(
        DEFAULT_CONFIG,
        profile="fixture",
        updates=6,
        checkpoint_steps=(0, 1, 2, 3, 4, 5, 6),
        control_updates=24,
    )
    config.validate()
    return config


def config_wire(config: OracleNoCompositionConfig = DEFAULT_CONFIG) -> dict[str, Any]:
    config.validate()
    return _jsonable(asdict(config))


def config_digest(config: OracleNoCompositionConfig = DEFAULT_CONFIG) -> str:
    return _digest(config_wire(config))


@dataclass(frozen=True)
class RMSCalibration:
    schema_version: str
    condition_name: str
    scalar_rms: float
    epsilon: float
    valid_time_count: int
    canonical_element_count: int
    source_view_fingerprint: str
    calibration_sha256: str

    def validate(self) -> None:
        if self.schema_version != RMS_SCHEMA:
            raise ValueError("invalid RMS calibration schema")
        if self.condition_name not in REPRESENTATION_CONDITION_NAMES:
            raise ValueError("unknown RMS calibration condition")
        if not math.isfinite(self.scalar_rms) or self.scalar_rms <= 0:
            raise ValueError("RMS calibration must be finite and positive")
        if self.epsilon <= 0 or self.valid_time_count < 1 or self.canonical_element_count < 1:
            raise ValueError("invalid RMS calibration counts")
        if not _is_sha256(self.source_view_fingerprint):
            raise ValueError("invalid RMS source fingerprint")
        payload = asdict(self)
        observed = payload.pop("calibration_sha256")
        if observed != _digest(payload):
            raise ValueError("RMS calibration digest mismatch")


@dataclass(frozen=True)
class CanonicalRepresentation:
    condition_name: str
    states: torch.Tensor
    time_mask: torch.Tensor
    metadata: Mapping[str, Any]

    def __post_init__(self) -> None:
        if self.condition_name not in REPRESENTATION_CONDITION_NAMES:
            raise ValueError("unknown canonical representation condition")
        if self.states.ndim != 3 or self.states.size(-1) != 128:
            raise ValueError("canonical states must be [batch,time,128]")
        if tuple(self.time_mask.shape) != tuple(self.states.shape[:2]) or self.time_mask.dtype != torch.bool:
            raise ValueError("canonical time mask must be boolean [batch,time]")
        if not torch.isfinite(self.states).all():
            raise ValueError("canonical states must be finite")
        invalid = ~self.time_mask[..., None]
        if torch.any(self.states.masked_select(invalid.expand_as(self.states)).ne(0)):
            raise ValueError("canonical invalid times must be exactly zero")


def _raw_canonical_states(
    view: RepresentationView,
    config: OracleNoCompositionConfig,
) -> tuple[torch.Tensor, torch.Tensor]:
    config.validate()
    if view.name not in REPRESENTATION_CONDITION_NAMES:
        raise ValueError("the view is not part of the frozen six-condition interface")
    if view.dimension != config.primary_dimension:
        raise ValueError("#123 accepts only fixed D=32 representations")
    if view.slot_count > config.primary_window:
        raise ValueError("representation exposes more than the fixed W=4 slots")
    mask = view.slot_mask & view.time_mask[..., None]
    states = view.states.detach().to(torch.float32) * mask[..., None].to(torch.float32)
    if view.slot_count < config.primary_window:
        states = F.pad(states, (0, 0, 0, config.primary_window - view.slot_count))
    flat = states.flatten(start_dim=-2)
    flat = flat.masked_fill(~view.time_mask[..., None], 0.0)
    if flat.size(-1) != config.canonical_width:
        raise RuntimeError("canonical width drifted")
    return flat.contiguous(), view.time_mask.detach().bool().contiguous()


def _view_fingerprint(view: RepresentationView) -> str:
    """Bind values and both causal masks used by the adapter."""

    return _digest({
        "condition": view.name,
        "states": tensor_state_fingerprint(view.states),
        "slot_mask": tensor_state_fingerprint(view.slot_mask),
        "time_mask": tensor_state_fingerprint(view.time_mask),
    })


def fit_rms_calibration(
    view: RepresentationView,
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
) -> RMSCalibration:
    """Fit one scalar on calibration sources only, including structural zeros.

    The denominator is valid times times all 128 transmitted coordinates.
    Thus slot sparsity remains part of the representation while overall RMS is
    normalized without whitening, rotation, unmixing, or learned parameters.
    """

    raw, time_mask = _raw_canonical_states(view, config)
    valid_time_count = int(time_mask.sum().item())
    element_count = valid_time_count * config.canonical_width
    if element_count < 1:
        raise ValueError("cannot fit RMS on an empty calibration view")
    sum_squares = raw.square().sum(dtype=torch.float64).item()
    scalar_rms = math.sqrt(sum_squares / element_count)
    if not math.isfinite(scalar_rms):
        raise FloatingPointError("RMS calibration is non-finite")
    if scalar_rms <= config.rms_epsilon:
        raise ValueError(
            "RMS calibration is at or below epsilon; representation extraction "
            "is invalid instrumentation"
        )
    payload = {
        "schema_version": RMS_SCHEMA,
        "condition_name": view.name,
        "scalar_rms": scalar_rms,
        "epsilon": config.rms_epsilon,
        "valid_time_count": valid_time_count,
        "canonical_element_count": element_count,
        "source_view_fingerprint": _view_fingerprint(view),
    }
    result = RMSCalibration(**payload, calibration_sha256=_digest(payload))
    result.validate()
    return result


def canonicalize_representation(
    view: RepresentationView,
    calibration: RMSCalibration,
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
) -> CanonicalRepresentation:
    calibration.validate()
    if calibration.condition_name != view.name:
        raise ValueError("RMS calibration cannot cross representation conditions")
    if calibration.epsilon != config.rms_epsilon:
        raise ValueError("RMS calibration numerical policy drifted")
    raw, time_mask = _raw_canonical_states(view, config)
    states = raw / calibration.scalar_rms
    states = states.masked_fill(~time_mask[..., None], 0.0)
    return CanonicalRepresentation(
        condition_name=view.name,
        states=states,
        time_mask=time_mask,
        metadata={
            "schema_version": CANONICAL_SCHEMA,
            "adapter": "mask-right-zero-pad-W4-flatten-D32",
            "canonical_width": config.canonical_width,
            "parameter_count": 0,
            "learned_unmixing": False,
            "whitening": False,
            "rms_calibration_sha256": calibration.calibration_sha256,
            "source_view_fingerprint": _view_fingerprint(view),
            "canonical_state_fingerprint": tensor_state_fingerprint(states),
        },
    )


@dataclass(frozen=True)
class PredictorOutput:
    logits: torch.Tensor
    hidden: torch.Tensor


class LinearNextBytePredictor(nn.Module):
    """A genuine single learned linear projection to the 256 byte logits."""

    architecture = "linear"

    def __init__(self, width: int = 128):
        super().__init__()
        self.head = nn.Linear(width, 256)

    def forward(self, states: torch.Tensor, time_mask: torch.Tensor) -> PredictorOutput:
        masked = states.masked_fill(~time_mask[..., None], 0.0)
        logits = self.head(masked)
        logits = logits.masked_fill(~time_mask[..., None], 0.0)
        # For the one-layer model, the learned projection itself is the final
        # hidden state used by the post-projection recoverability diagnostic.
        return PredictorOutput(logits=logits, hidden=logits)


class ShallowMLPNextBytePredictor(nn.Module):
    architecture = "shallow-mlp"

    def __init__(self, width: int = 128, hidden_width: int = 128):
        super().__init__()
        self.projection = nn.Linear(width, hidden_width)
        self.head = nn.Linear(hidden_width, 256)

    def forward(self, states: torch.Tensor, time_mask: torch.Tensor) -> PredictorOutput:
        masked = states.masked_fill(~time_mask[..., None], 0.0)
        hidden = F.gelu(self.projection(masked))
        hidden = hidden.masked_fill(~time_mask[..., None], 0.0)
        logits = self.head(hidden).masked_fill(~time_mask[..., None], 0.0)
        return PredictorOutput(logits=logits, hidden=hidden)


def _fixed_sinusoid(time: int, width: int, *, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    positions = torch.arange(time, device=device, dtype=torch.float64)[:, None]
    frequencies = torch.exp(
        torch.arange(0, width, 2, device=device, dtype=torch.float64)
        * (-math.log(10_000.0) / width)
    )
    result = torch.zeros(time, width, device=device, dtype=torch.float64)
    result[:, 0::2] = torch.sin(positions * frequencies)
    result[:, 1::2] = torch.cos(positions * frequencies[: result[:, 1::2].size(1)])
    return result.to(dtype=dtype)


class CausalTransformerNextBytePredictor(nn.Module):
    """Small vanilla temporal Transformer with fixed sinusoidal position."""

    architecture = "vanilla-transformer"

    def __init__(self, width: int = 128, heads: int = 4, layers: int = 1):
        super().__init__()
        # Reuse the repository's established causal decoder implementation;
        # Identity is safe because this benchmark supplies frozen features.
        self.backbone = FrontendLM(nn.Identity(), width, heads=heads, layers=layers)
        self.width = width
        self.layers = layers

    def forward(self, states: torch.Tensor, time_mask: torch.Tensor) -> PredictorOutput:
        if states.ndim != 3 or tuple(time_mask.shape) != tuple(states.shape[:2]):
            raise ValueError("predictor inputs must be [batch,time,width] plus [batch,time] mask")
        if states.size(-1) != self.width:
            raise ValueError("predictor input width drifted")
        time_steps = states.size(1)
        causal = torch.ones(time_steps, time_steps, device=states.device, dtype=torch.bool).triu(1)
        position = _fixed_sinusoid(
            time_steps, self.width, device=states.device, dtype=states.dtype,
        )[None]
        x = states.masked_fill(~time_mask[..., None], 0.0) + position
        hidden = self.backbone.decoder(x, mask=causal, src_key_padding_mask=~time_mask)
        if not torch.isfinite(hidden).all():
            raise FloatingPointError("non-finite Transformer hidden state")
        hidden = hidden.masked_fill(~time_mask[..., None], 0.0)
        logits = self.backbone.head(hidden).masked_fill(~time_mask[..., None], 0.0)
        if not torch.isfinite(logits).all():
            raise FloatingPointError("non-finite Transformer logits")
        return PredictorOutput(logits=logits, hidden=hidden)


class BoundedOracleTransformerPredictor(CausalTransformerNextBytePredictor):
    architecture = "bounded-oracle-transformer"

    def __init__(self, width: int = 128, heads: int = 4, layers: int = 2):
        super().__init__(width=width, heads=heads, layers=layers)


def build_predictor(
    architecture: str,
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
    seed: int = 17,
) -> nn.Module:
    """Build one deterministically initialized architecture.

    Initialization depends only on architecture and seed, never condition.
    ``fork_rng`` prevents a cell from perturbing the enclosing runner RNG.
    """

    config.validate()
    if architecture not in config.downstream_families:
        raise ValueError(f"unknown downstream architecture {architecture!r}")
    if seed not in config.downstream_seeds and config.profile == "qualifying":
        raise ValueError("qualifying cells must use one of the three preregistered seeds")
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(int(seed))
        if architecture == "linear":
            model: nn.Module = LinearNextBytePredictor(config.canonical_width)
        elif architecture == "shallow-mlp":
            model = ShallowMLPNextBytePredictor(config.canonical_width, config.shallow_width)
        elif architecture == "vanilla-transformer":
            model = CausalTransformerNextBytePredictor(
                config.canonical_width, config.transformer_heads,
                config.vanilla_transformer_layers,
            )
        else:
            model = BoundedOracleTransformerPredictor(
                config.canonical_width, config.transformer_heads,
                config.bounded_oracle_layers,
            )
    if architecture == "bounded-oracle-transformer" and parameter_count(model) > config.bounded_oracle_parameter_cap:
        raise RuntimeError("bounded oracle exceeds its preregistered parameter cap")
    return model


def parameter_count(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters())


def _batch_fingerprint(canonical: CanonicalRepresentation, batch: TextBatch) -> str:
    return _digest({
        "condition": canonical.condition_name,
        "states": tensor_state_fingerprint(canonical.states),
        "time_mask": tensor_state_fingerprint(canonical.time_mask),
        "targets": tensor_state_fingerprint(batch.targets),
        "valid": tensor_state_fingerprint(batch.valid),
        "byte_count": int(batch.byte_count),
        "document_ids": list(batch.document_ids),
    })


def _objective_schedule_fingerprint(batch: TextBatch) -> str:
    """Condition-independent target/order identity for paired cell budgets."""

    return _digest({
        "targets": tensor_state_fingerprint(batch.targets),
        "valid": tensor_state_fingerprint(batch.valid),
        "byte_count": int(batch.byte_count),
        "document_ids": list(batch.document_ids),
    })


def _validate_batch(canonical: CanonicalRepresentation, batch: TextBatch, *, label: str) -> None:
    if tuple(batch.targets.shape) != tuple(canonical.states.shape[:2]):
        raise ValueError(f"{label} targets do not align with canonical states")
    if tuple(batch.valid.shape) != tuple(canonical.states.shape[:2]) or batch.valid.dtype != torch.bool:
        raise ValueError(f"{label} valid mask does not align with canonical states")
    if not torch.equal(batch.valid.cpu(), canonical.time_mask.cpu()):
        raise ValueError(f"{label} representation/objective masks differ")
    observed_bytes = int(batch.valid.sum().item())
    if int(batch.byte_count) != observed_bytes:
        raise ValueError(f"{label} byte_count must equal the original-byte objective mask")
    if observed_bytes < 1:
        raise ValueError(f"{label} batch is empty")
    if batch.document_ids and len(batch.document_ids) != canonical.states.size(0):
        raise ValueError(f"{label} document IDs must have one entry per row")
    if batch.targets[batch.valid].min().item() < 0 or batch.targets[batch.valid].max().item() > 255:
        raise ValueError(f"{label} next-byte targets must be 0..255")


def _nll_tensor(output: PredictorOutput, batch: TextBatch) -> torch.Tensor:
    return F.cross_entropy(output.logits.transpose(1, 2), batch.targets, reduction="none")


def _document_rows(
    output: PredictorOutput,
    batch: TextBatch,
    *,
    condition_name: str,
    architecture: str,
    seed: int,
    checkpoint_step: int,
) -> list[dict[str, Any]]:
    nll = _nll_tensor(output, batch)
    document_ids = batch.document_ids or tuple(f"row-{index:03d}" for index in range(nll.size(0)))
    rows: list[dict[str, Any]] = []
    for index, document_id in enumerate(document_ids):
        count = int(batch.valid[index].sum().item())
        if count < 1:
            raise ValueError("evaluation documents must each contain at least one objective byte")
        total = float((nll[index] * batch.valid[index]).sum(dtype=torch.float64).item())
        rows.append({
            "document_id": str(document_id),
            "total_nll": total,
            "original_byte_count": count,
            "byte_normalized_nll": total / count,
            "checkpoint_step": int(checkpoint_step),
            "condition": condition_name,
            "seed": int(seed),
            "architecture": architecture,
        })
    return rows


def _forward_flops(architecture: str, batch: int, time_steps: int, config: OracleNoCompositionConfig) -> int:
    """Deterministic multiply/add ledger (not a hardware profiler)."""

    d, vocab = config.canonical_width, 256
    if architecture == "linear":
        per_sequence = 2 * time_steps * d * vocab
    elif architecture == "shallow-mlp":
        per_sequence = (
            2 * time_steps * d * config.shallow_width
            + 8 * time_steps * config.shallow_width
            + 2 * time_steps * config.shallow_width * vocab
        )
    else:
        layers = config.vanilla_transformer_layers if architecture == "vanilla-transformer" else config.bounded_oracle_layers
        # Q/K/V/out projections, dense attention score/value products, and
        # d->4d->d feed-forward projections.
        layer = 8 * time_steps * d * d + 4 * time_steps * time_steps * d + 16 * time_steps * d * d
        per_sequence = layers * layer + 2 * time_steps * d * vocab
    return int(batch * per_sequence)


def _rss_bytes() -> int:
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value if sys.platform == "darwin" else value * 1024


def _evaluation_at_checkpoint(
    model: nn.Module,
    canonical: CanonicalRepresentation,
    batch: TextBatch,
    *,
    condition_name: str,
    architecture: str,
    seed: int,
    checkpoint_step: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    model.eval()
    started = time.perf_counter()
    with torch.no_grad():
        output = model(canonical.states, canonical.time_mask)
        rows = _document_rows(
            output, batch, condition_name=condition_name,
            architecture=architecture, seed=seed,
            checkpoint_step=checkpoint_step,
        )
    elapsed = max(time.perf_counter() - started, 1e-12)
    byte_count = sum(int(row["original_byte_count"]) for row in rows)
    total_nll = sum(float(row["total_nll"]) for row in rows)
    return rows, {
        "checkpoint_step": checkpoint_step,
        "total_nll": total_nll,
        "original_byte_count": byte_count,
        "byte_normalized_nll": total_nll / byte_count,
        "elapsed_seconds": elapsed,
        "original_bytes_per_second": byte_count / elapsed,
        "peak_process_rss_bytes": _rss_bytes(),
        "model_state_sha256": module_state_fingerprint(model),
    }


@dataclass
class FittedConditionPredictor:
    condition_name: str
    architecture: str
    seed: int
    model: nn.Module
    rms_calibration: RMSCalibration
    config_sha256: str
    training_evidence: Mapping[str, Any]


def fit_condition_predictor(
    condition_name: str,
    architecture: str,
    seed: int,
    calibration_view: RepresentationView,
    calibration_batch: TextBatch,
    evaluation_view: RepresentationView | None = None,
    evaluation_batch: TextBatch | None = None,
    *,
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
    device: str | torch.device = "cpu",
    test_seal_sha256: str | None = None,
) -> FittedConditionPredictor:
    config.validate()
    if condition_name != calibration_view.name:
        raise ValueError("cell condition does not match calibration view")
    if (evaluation_view is None) != (evaluation_batch is None):
        raise ValueError("evaluation view and batch must be supplied together")
    if evaluation_view is not None and evaluation_view.name != condition_name:
        raise ValueError("calibration/evaluation representation conditions differ")
    if test_seal_sha256 is not None and not _is_sha256(test_seal_sha256):
        raise ValueError("test seal must be a SHA-256 digest")

    calibration = fit_rms_calibration(calibration_view, config)
    canonical_train = canonicalize_representation(calibration_view, calibration, config)
    _validate_batch(canonical_train, calibration_batch, label="calibration")
    canonical_eval = None
    if evaluation_view is not None and evaluation_batch is not None:
        canonical_eval = canonicalize_representation(evaluation_view, calibration, config)
        _validate_batch(canonical_eval, evaluation_batch, label="evaluation")

    requested_device = torch.device(device)
    if requested_device.type != "cpu" and not torch.cuda.is_available():
        raise ValueError("requested accelerator is unavailable")
    model = build_predictor(architecture, config, seed).to(requested_device)
    train_states = canonical_train.states.to(requested_device)
    train_mask = canonical_train.time_mask.to(requested_device)
    train_batch = TextBatch(
        input_ids=calibration_batch.input_ids.to(requested_device),
        targets=calibration_batch.targets.to(requested_device),
        valid=calibration_batch.valid.to(requested_device),
        byte_count=calibration_batch.byte_count,
        document_ids=calibration_batch.document_ids,
        document_positions=None,
        document_lengths=None,
    )
    eval_canonical_device = None
    eval_batch_device = None
    if canonical_eval is not None and evaluation_batch is not None:
        eval_canonical_device = CanonicalRepresentation(
            canonical_eval.condition_name,
            canonical_eval.states.to(requested_device),
            canonical_eval.time_mask.to(requested_device),
            canonical_eval.metadata,
        )
        eval_batch_device = TextBatch(
            input_ids=evaluation_batch.input_ids.to(requested_device),
            targets=evaluation_batch.targets.to(requested_device),
            valid=evaluation_batch.valid.to(requested_device),
            byte_count=evaluation_batch.byte_count,
            document_ids=evaluation_batch.document_ids,
            document_positions=None,
            document_lengths=None,
        )

    initial_model_sha256 = module_state_fingerprint(model)
    calibration_input_sha256 = _batch_fingerprint(canonical_train, calibration_batch)
    evaluation_input_sha256 = (
        _batch_fingerprint(canonical_eval, evaluation_batch)
        if canonical_eval is not None and evaluation_batch is not None else None
    )
    schedule = {
        "kind": config.batch_schedule,
        "updates": config.updates,
        "checkpoint_steps": list(config.checkpoint_steps),
        "optimizer": "AdamW",
        "learning_rate": config.learning_rate,
        "weight_decay": config.weight_decay,
        "gradient_clip_norm": config.gradient_clip_norm,
        # Representation fingerprints are recorded separately.  The schedule
        # hash binds only the condition-independent optimizer, source order,
        # masks, and next-byte objectives and must therefore match all six
        # paired conditions for one architecture/seed.
        "objective_schedule_sha256": _objective_schedule_fingerprint(calibration_batch),
    }
    schedule_sha256 = _digest(schedule)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay,
    )
    batch_size, time_steps = canonical_train.states.shape[:2]
    per_forward_flops = _forward_flops(architecture, batch_size, time_steps, config)

    train_curve: list[dict[str, Any]] = []
    validation_learning_curve: list[dict[str, Any]] = []
    checkpoint_ledger: list[dict[str, Any]] = []
    gradient_norms: list[float] = []
    update_norms: list[float] = []
    start_rss = _rss_bytes()
    total_wall_started = time.perf_counter()
    training_update_elapsed = 0.0

    def evaluate_checkpoint(step: int) -> None:
        if eval_canonical_device is None or eval_batch_device is None:
            return
        rows, ledger = _evaluation_at_checkpoint(
            model, eval_canonical_device, eval_batch_device,
            condition_name=condition_name, architecture=architecture,
            seed=seed, checkpoint_step=step,
        )
        cumulative_bytes = int(train_batch.byte_count) * step
        cumulative_flops = 3 * per_forward_flops * step
        for row in rows:
            row["cumulative_training_original_bytes"] = cumulative_bytes
            row["cumulative_training_flops_estimate"] = cumulative_flops
        ledger["cumulative_training_original_bytes"] = cumulative_bytes
        ledger["cumulative_training_flops_estimate"] = cumulative_flops
        validation_learning_curve.extend(rows)
        checkpoint_ledger.append(ledger)

    evaluate_checkpoint(0)
    for step in range(1, config.updates + 1):
        update_started = time.perf_counter()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        output = model(train_states, train_mask)
        nll = _nll_tensor(output, train_batch)
        total_nll = (nll * train_batch.valid).sum()
        loss = total_nll / train_batch.byte_count
        if not torch.isfinite(loss):
            raise RuntimeError("non-finite #123 training loss")
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip_norm)
        norm_value = float(norm.detach().cpu().item())
        if not math.isfinite(norm_value):
            raise RuntimeError("non-finite #123 gradient norm")
        gradient_norms.append(norm_value)
        parameters_before = [parameter.detach().clone() for parameter in model.parameters()]
        optimizer.step()
        update_square = 0.0
        parameters_finite = True
        for before, parameter in zip(parameters_before, model.parameters(), strict=True):
            difference = parameter.detach() - before
            update_square += float(difference.square().sum(dtype=torch.float64).item())
            parameters_finite = parameters_finite and bool(torch.isfinite(parameter).all().item())
        update_norm = math.sqrt(update_square)
        if not parameters_finite or not math.isfinite(update_norm):
            raise RuntimeError("non-finite #123 parameter update")
        update_norms.append(update_norm)
        training_update_elapsed += time.perf_counter() - update_started
        train_curve.append({
            "step": step,
            "total_nll": float(total_nll.detach().cpu().item()),
            "original_byte_count": int(train_batch.byte_count),
            "byte_normalized_nll": float(loss.detach().cpu().item()),
            "preclip_gradient_l2_norm": norm_value,
            "parameter_update_l2_norm": update_norm,
            "parameters_finite": parameters_finite,
            "cumulative_training_original_bytes": int(train_batch.byte_count) * step,
            "cumulative_training_flops_estimate": 3 * per_forward_flops * step,
        })
        if step in config.checkpoint_steps:
            evaluate_checkpoint(step)

    total_wall_elapsed = max(time.perf_counter() - total_wall_started, 1e-12)
    train_elapsed = max(training_update_elapsed, 1e-12)
    final_model_sha256 = module_state_fingerprint(model)
    if _batch_fingerprint(canonical_train, calibration_batch) != calibration_input_sha256:
        raise RuntimeError("calibration representation or targets mutated during fitting")
    if canonical_eval is not None and evaluation_batch is not None:
        if _batch_fingerprint(canonical_eval, evaluation_batch) != evaluation_input_sha256:
            raise RuntimeError("evaluation representation or targets mutated during fitting")

    evaluation_forwards = len(config.checkpoint_steps) if canonical_eval is not None else 0
    eval_flops = 0
    if canonical_eval is not None:
        eval_flops = evaluation_forwards * _forward_flops(
            architecture, canonical_eval.states.size(0), canonical_eval.states.size(1), config,
        )
    parameters = parameter_count(model)
    parameter_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
    state_bytes = train_states.numel() * train_states.element_size()
    memory_ledger = {
        "parameter_bytes": parameter_bytes,
        "adamw_state_bytes_estimate": 2 * parameter_bytes,
        "calibration_state_bytes": state_bytes,
        "start_process_peak_rss_bytes": start_rss,
        "end_process_peak_rss_bytes": _rss_bytes(),
    }
    training_evidence: dict[str, Any] = {
        "train_curve": train_curve,
        "validation_learning_curve": validation_learning_curve,
        "checkpoint_ledger": checkpoint_ledger,
        "gradient_ledger": {
            "steps": len(gradient_norms),
            "minimum_preclip_l2_norm": min(gradient_norms),
            "maximum_preclip_l2_norm": max(gradient_norms),
            "mean_preclip_l2_norm": sum(gradient_norms) / len(gradient_norms),
            "zero_gradient_steps": sum(value == 0 for value in gradient_norms),
            "minimum_parameter_update_l2_norm": min(update_norms),
            "maximum_parameter_update_l2_norm": max(update_norms),
            "mean_parameter_update_l2_norm": sum(update_norms) / len(update_norms),
            "zero_parameter_update_steps": sum(value == 0 for value in update_norms),
            "all_parameters_finite": True,
        },
        "training_elapsed_seconds": train_elapsed,
        "cell_total_wall_elapsed_seconds": total_wall_elapsed,
        "training_original_bytes_processed": int(train_batch.byte_count) * config.updates,
        "training_original_bytes_per_second": int(train_batch.byte_count) * config.updates / train_elapsed,
        "initial_model_state_sha256": initial_model_sha256,
        "final_model_state_sha256": final_model_sha256,
        "schedule": schedule,
        "schedule_sha256": schedule_sha256,
        "calibration_input_sha256": calibration_input_sha256,
        "evaluation_input_sha256": evaluation_input_sha256,
        "calibration_batch_shape": [batch_size, time_steps],
        "evaluation_batch_shape": (
            [canonical_eval.states.size(0), canonical_eval.states.size(1)]
            if canonical_eval is not None else None
        ),
        "parameter_ledger": {
            "total_parameters": parameters,
            "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
            "bounded_oracle_parameter_cap": config.bounded_oracle_parameter_cap if architecture == "bounded-oracle-transformer" else None,
        },
        "flop_ledger": {
            "estimation": "deterministic-multiply-add-ledger",
            "forward_flops_per_calibration_batch": per_forward_flops,
            "training_flops_estimate": 3 * per_forward_flops * config.updates,
            "checkpoint_evaluation_flops_estimate": eval_flops,
            "total_flops_estimate": 3 * per_forward_flops * config.updates + eval_flops,
        },
        "memory_ledger": memory_ledger,
        "test_split": {
            "status": "sealed-not-read",
            "manifest_sha256": test_seal_sha256,
        },
    }
    return FittedConditionPredictor(
        condition_name=condition_name,
        architecture=architecture,
        seed=seed,
        model=model,
        rms_calibration=calibration,
        config_sha256=config_digest(config),
        training_evidence=training_evidence,
    )


def evaluate_condition_predictor(
    fitted: FittedConditionPredictor,
    evaluation_view: RepresentationView,
    evaluation_batch: TextBatch,
    *,
    checkpoint_step: int | None = None,
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
) -> dict[str, Any]:
    if fitted.config_sha256 != config_digest(config):
        raise ValueError("fitted predictor/config digest mismatch")
    if evaluation_view.name != fitted.condition_name:
        raise ValueError("evaluation condition differs from fitted condition")
    canonical = canonicalize_representation(evaluation_view, fitted.rms_calibration, config)
    _validate_batch(canonical, evaluation_batch, label="evaluation")
    device = next(fitted.model.parameters()).device
    canonical_device = CanonicalRepresentation(
        canonical.condition_name, canonical.states.to(device), canonical.time_mask.to(device), canonical.metadata,
    )
    batch_device = TextBatch(
        evaluation_batch.input_ids.to(device), evaluation_batch.targets.to(device),
        evaluation_batch.valid.to(device), evaluation_batch.byte_count,
        evaluation_batch.document_ids,
    )
    step = config.updates if checkpoint_step is None else int(checkpoint_step)
    rows, ledger = _evaluation_at_checkpoint(
        fitted.model, canonical_device, batch_device,
        condition_name=fitted.condition_name, architecture=fitted.architecture,
        seed=fitted.seed, checkpoint_step=step,
    )
    return {"documents": rows, "aggregate": ledger}


def fit_and_evaluate_condition(
    condition_name: str,
    architecture: str,
    seed: int,
    calibration_view: RepresentationView,
    evaluation_view: RepresentationView,
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    *,
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
    device: str | torch.device = "cpu",
    test_seal_sha256: str | None = None,
) -> tuple[FittedConditionPredictor, dict[str, Any]]:
    fitted = fit_condition_predictor(
        condition_name, architecture, seed, calibration_view, calibration_batch,
        evaluation_view, evaluation_batch, config=config, device=device,
        test_seal_sha256=test_seal_sha256,
    )
    final_rows = [
        row for row in fitted.training_evidence["validation_learning_curve"]
        if int(row["checkpoint_step"]) == config.updates
    ]
    if not final_rows:
        raise RuntimeError("fit did not produce a final validation checkpoint")
    total_nll = sum(float(row["total_nll"]) for row in final_rows)
    byte_count = sum(int(row["original_byte_count"]) for row in final_rows)
    cell_ledger = {
        "parameter_ledger": fitted.training_evidence["parameter_ledger"],
        "flop_ledger": fitted.training_evidence["flop_ledger"],
        "throughput_ledger": {
            "training_elapsed_seconds": fitted.training_evidence["training_elapsed_seconds"],
            "cell_total_wall_elapsed_seconds": fitted.training_evidence["cell_total_wall_elapsed_seconds"],
            "training_original_bytes_per_second": fitted.training_evidence["training_original_bytes_per_second"],
            "checkpoint_evaluations": fitted.training_evidence["checkpoint_ledger"],
        },
        "memory_ledger": fitted.training_evidence["memory_ledger"],
        "gradient_ledger": fitted.training_evidence["gradient_ledger"],
        "initial_model_state_sha256": fitted.training_evidence["initial_model_state_sha256"],
        "final_model_state_sha256": fitted.training_evidence["final_model_state_sha256"],
        "schedule_sha256": fitted.training_evidence["schedule_sha256"],
        "calibration_input_sha256": fitted.training_evidence["calibration_input_sha256"],
        "evaluation_input_sha256": fitted.training_evidence["evaluation_input_sha256"],
    }
    cell = {
        "schema_version": CELL_SCHEMA,
        "issue": ISSUE_NUMBER,
        "condition": condition_name,
        "architecture": architecture,
        "seed": seed,
        "config_sha256": fitted.config_sha256,
        "rms_calibration": asdict(fitted.rms_calibration),
        "training_evidence": fitted.training_evidence,
        "validation_learning_curve": fitted.training_evidence["validation_learning_curve"],
        "final_evaluation": {
            "documents": final_rows,
            "total_nll": total_nll,
            "original_byte_count": byte_count,
            "byte_normalized_nll": total_nll / byte_count,
        },
        "cell_ledger": cell_ledger,
        "test_split": fitted.training_evidence["test_split"],
    }
    validate_cell_result(
        cell, expected_condition=condition_name,
        expected_architecture=architecture, expected_seed=seed,
        config=config, expected_test_seal_sha256=test_seal_sha256,
    )
    return fitted, cell


def validate_cell_result(
    cell: Mapping[str, Any],
    *,
    expected_condition: str | None = None,
    expected_architecture: str | None = None,
    expected_seed: int | None = None,
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
    expected_test_seal_sha256: str | None = None,
) -> None:
    """Fail closed on identities, complete curves, and recomputed byte NLL."""

    config.validate()
    if cell.get("schema_version") != CELL_SCHEMA or cell.get("issue") != ISSUE_NUMBER:
        raise ValueError("invalid #123 cell schema/issue")
    condition = cell.get("condition")
    architecture = cell.get("architecture")
    seed = cell.get("seed")
    if condition not in REPRESENTATION_CONDITION_NAMES or architecture not in DOWNSTREAM_FAMILIES:
        raise ValueError("unknown #123 condition/architecture")
    if expected_condition is not None and condition != expected_condition:
        raise ValueError("cell condition mismatch")
    if expected_architecture is not None and architecture != expected_architecture:
        raise ValueError("cell architecture mismatch")
    if expected_seed is not None and seed != expected_seed:
        raise ValueError("cell seed mismatch")
    if cell.get("config_sha256") != config_digest(config):
        raise ValueError("cell config digest mismatch")
    calibration = RMSCalibration(**dict(cell.get("rms_calibration", {})))
    calibration.validate()
    if calibration.condition_name != condition:
        raise ValueError("cell RMS calibration condition mismatch")

    evidence = cell.get("training_evidence")
    if not isinstance(evidence, Mapping):
        raise ValueError("cell lacks training evidence")

    rows = cell.get("validation_learning_curve")
    if not isinstance(rows, list) or not rows:
        raise ValueError("cell lacks a validation learning curve")
    if evidence.get("validation_learning_curve") != rows:
        raise ValueError("duplicated validation curve does not match training evidence")
    documents_by_step: dict[int, set[str]] = {}
    document_order_by_step: dict[int, list[str]] = {}
    document_bytes_by_step: dict[int, list[int]] = {}
    totals_by_step: dict[int, tuple[float, int]] = {}
    for row in rows:
        if not isinstance(row, Mapping):
            raise ValueError("invalid validation row")
        if row.get("condition") != condition or row.get("architecture") != architecture or row.get("seed") != seed:
            raise ValueError("validation row identity mismatch")
        step = int(row.get("checkpoint_step", -1))
        if step not in config.checkpoint_steps:
            raise ValueError("validation row uses an unregistered checkpoint")
        document_id = row.get("document_id")
        total = float(row.get("total_nll", math.nan))
        count = int(row.get("original_byte_count", 0))
        normalized = float(row.get("byte_normalized_nll", math.nan))
        if not isinstance(document_id, str) or not document_id or count < 1 or not math.isfinite(total) or total < 0:
            raise ValueError("invalid per-document validation evidence")
        if not math.isfinite(normalized) or not math.isclose(normalized, total / count, rel_tol=1e-10, abs_tol=1e-12):
            raise ValueError("per-document byte normalization is not reproducible")
        if int(row.get("cumulative_training_original_bytes", -1)) < 0 or int(row.get("cumulative_training_flops_estimate", -1)) < 0:
            raise ValueError("validation row lacks byte/FLOP learning-curve axes")
        documents_by_step.setdefault(step, set())
        document_order_by_step.setdefault(step, [])
        document_bytes_by_step.setdefault(step, [])
        if document_id in documents_by_step[step]:
            raise ValueError("duplicate document/checkpoint validation row")
        documents_by_step[step].add(document_id)
        document_order_by_step[step].append(document_id)
        document_bytes_by_step[step].append(count)
        old_total, old_count = totals_by_step.get(step, (0.0, 0))
        totals_by_step[step] = (old_total + total, old_count + count)
    if tuple(sorted(documents_by_step)) != config.checkpoint_steps:
        raise ValueError("validation curve does not cover all seven checkpoints")
    document_sets = list(documents_by_step.values())
    if any(value != document_sets[0] for value in document_sets[1:]):
        raise ValueError("evaluation document pairing drifted across checkpoints")
    document_orders = list(document_order_by_step.values())
    if any(value != document_orders[0] for value in document_orders[1:]):
        raise ValueError("evaluation document order drifted across checkpoints")
    if config.profile == "qualifying" and len(document_sets[0]) != config.expected_evaluation_documents:
        raise ValueError("qualifying cell must contain exactly eight evaluation documents")
    if config.profile == "qualifying" and any(
        tuple(counts) != config.expected_evaluation_document_bytes
        for counts in document_bytes_by_step.values()
    ):
        raise ValueError("qualifying evaluation document byte counts drifted from the #122 selection")

    final = cell.get("final_evaluation")
    if not isinstance(final, Mapping):
        raise ValueError("cell lacks final evaluation summary")
    expected_final_rows = [row for row in rows if int(row["checkpoint_step"]) == config.updates]
    if final.get("documents") != expected_final_rows:
        raise ValueError("final per-document evidence differs from the final learning-curve checkpoint")
    expected_total, expected_count = totals_by_step[config.updates]
    if int(final.get("original_byte_count", 0)) != expected_count:
        raise ValueError("final evaluation byte count mismatch")
    if not math.isclose(float(final.get("total_nll", math.nan)), expected_total, rel_tol=1e-10, abs_tol=1e-9):
        raise ValueError("final evaluation total NLL mismatch")
    if not math.isclose(float(final.get("byte_normalized_nll", math.nan)), expected_total / expected_count, rel_tol=1e-10, abs_tol=1e-12):
        raise ValueError("final evaluation normalized NLL mismatch")

    train_curve = evidence.get("train_curve")
    if not isinstance(train_curve, list) or len(train_curve) != config.updates:
        raise ValueError("training curve must contain every optimizer update")
    if [int(row.get("step", -1)) for row in train_curve] != list(range(1, config.updates + 1)):
        raise ValueError("training update sequence drifted")
    calibration_shape = evidence.get("calibration_batch_shape")
    evaluation_shape = evidence.get("evaluation_batch_shape")
    if not (
        isinstance(calibration_shape, list) and len(calibration_shape) == 2
        and isinstance(evaluation_shape, list) and len(evaluation_shape) == 2
        and all(isinstance(value, int) and value > 0 for value in calibration_shape + evaluation_shape)
    ):
        raise ValueError("cell lacks calibration/evaluation batch shapes")
    if config.profile == "qualifying":
        if calibration_shape != [config.expected_calibration_documents, config.expected_segment_bytes]:
            raise ValueError("qualifying calibration batch shape drifted")
        if evaluation_shape != [config.expected_evaluation_documents, config.expected_segment_bytes]:
            raise ValueError("qualifying evaluation batch shape drifted")
    calibration_bytes = int(train_curve[0].get("original_byte_count", 0))
    if calibration_bytes < 1 or any(int(row.get("original_byte_count", 0)) != calibration_bytes for row in train_curve):
        raise ValueError("calibration original-byte budget drifted across updates")
    if config.profile == "qualifying" and calibration_bytes != config.expected_calibration_documents * config.expected_segment_bytes:
        raise ValueError("qualifying calibration byte budget drifted")
    if calibration.valid_time_count != calibration_bytes or calibration.canonical_element_count != calibration_bytes * config.canonical_width:
        raise ValueError("RMS calibration counts do not match the calibration objective mask")

    expected_model = build_predictor(str(architecture), config, int(seed))
    expected_parameters = parameter_count(expected_model)
    expected_initial_sha256 = module_state_fingerprint(expected_model)
    train_forward_flops = _forward_flops(
        str(architecture), int(calibration_shape[0]), int(calibration_shape[1]), config,
    )
    for train_row in train_curve:
        step = int(train_row["step"])
        total = float(train_row.get("total_nll", math.nan))
        normalized = float(train_row.get("byte_normalized_nll", math.nan))
        gradient = float(train_row.get("preclip_gradient_l2_norm", math.nan))
        update = float(train_row.get("parameter_update_l2_norm", math.nan))
        if not math.isfinite(total) or total < 0 or not math.isclose(normalized, total / calibration_bytes, rel_tol=1e-6, abs_tol=1e-8):
            raise ValueError("training byte-normalized NLL is not reproducible")
        if not math.isfinite(gradient) or gradient < 0 or not math.isfinite(update) or update < 0 or train_row.get("parameters_finite") is not True:
            raise ValueError("invalid gradient/update stability evidence")
        if int(train_row.get("cumulative_training_original_bytes", -1)) != calibration_bytes * step:
            raise ValueError("training cumulative-byte axis drifted")
        if int(train_row.get("cumulative_training_flops_estimate", -1)) != 3 * train_forward_flops * step:
            raise ValueError("training cumulative-FLOP axis drifted")

    for step in config.checkpoint_steps:
        expected_cumulative_bytes = calibration_bytes * step
        expected_cumulative_flops = 3 * train_forward_flops * step
        for row in rows:
            if int(row["checkpoint_step"]) == step:
                if int(row["cumulative_training_original_bytes"]) != expected_cumulative_bytes:
                    raise ValueError("validation cumulative-byte axis drifted")
                if int(row["cumulative_training_flops_estimate"]) != expected_cumulative_flops:
                    raise ValueError("validation cumulative-FLOP axis drifted")

    ledger = cell.get("cell_ledger")
    if not isinstance(ledger, Mapping):
        raise ValueError("cell lacks its cost/provenance ledger")
    params = ledger.get("parameter_ledger", {})
    if (
        int(params.get("total_parameters", 0)) != expected_parameters
        or params.get("trainable_parameters") != expected_parameters
    ):
        raise ValueError("invalid parameter ledger")
    if architecture == "bounded-oracle-transformer" and (
        params.get("bounded_oracle_parameter_cap") != config.bounded_oracle_parameter_cap
        or expected_parameters > config.bounded_oracle_parameter_cap
    ):
        raise ValueError("bounded-oracle parameter-cap evidence drifted")
    flops = ledger.get("flop_ledger", {})
    eval_forward_flops = _forward_flops(
        str(architecture), int(evaluation_shape[0]), int(evaluation_shape[1]), config,
    )
    expected_training_flops = 3 * train_forward_flops * config.updates
    expected_eval_flops = eval_forward_flops * len(config.checkpoint_steps)
    if (
        flops.get("estimation") != "deterministic-multiply-add-ledger"
        or int(flops.get("forward_flops_per_calibration_batch", -1)) != train_forward_flops
        or int(flops.get("training_flops_estimate", -1)) != expected_training_flops
        or int(flops.get("checkpoint_evaluation_flops_estimate", -1)) != expected_eval_flops
        or int(flops.get("total_flops_estimate", -1)) != expected_training_flops + expected_eval_flops
    ):
        raise ValueError("invalid FLOP ledger")
    for key in ("initial_model_state_sha256", "final_model_state_sha256", "schedule_sha256", "calibration_input_sha256", "evaluation_input_sha256"):
        if not _is_sha256(ledger.get(key)):
            raise ValueError(f"invalid cell ledger digest: {key}")
    if ledger.get("initial_model_state_sha256") != expected_initial_sha256:
        raise ValueError("condition-dependent or incorrect model initialization")

    # Recompute schedule, checkpoint, gradient, throughput, and memory ledgers
    # rather than trusting digest-shaped values or stored aggregate flags.
    schedule = evidence.get("schedule")
    if not isinstance(schedule, Mapping) or _digest(schedule) != evidence.get("schedule_sha256") or evidence.get("schedule_sha256") != ledger.get("schedule_sha256"):
        raise ValueError("training schedule digest mismatch")
    if (
        schedule.get("kind") != config.batch_schedule
        or int(schedule.get("updates", -1)) != config.updates
        or schedule.get("checkpoint_steps") != list(config.checkpoint_steps)
        or schedule.get("optimizer") != "AdamW"
        or float(schedule.get("learning_rate", -1)) != config.learning_rate
        or float(schedule.get("weight_decay", -1)) != config.weight_decay
        or float(schedule.get("gradient_clip_norm", -1)) != config.gradient_clip_norm
        or not _is_sha256(schedule.get("objective_schedule_sha256"))
    ):
        raise ValueError("training schedule policy drifted")
    if evidence.get("initial_model_state_sha256") != expected_initial_sha256 or evidence.get("final_model_state_sha256") != ledger.get("final_model_state_sha256"):
        raise ValueError("model state provenance mismatch")
    if evidence.get("calibration_input_sha256") != ledger.get("calibration_input_sha256") or evidence.get("evaluation_input_sha256") != ledger.get("evaluation_input_sha256"):
        raise ValueError("input provenance duplication mismatch")

    checkpoint_ledger = evidence.get("checkpoint_ledger")
    if not isinstance(checkpoint_ledger, list) or [int(row.get("checkpoint_step", -1)) for row in checkpoint_ledger] != list(config.checkpoint_steps):
        raise ValueError("checkpoint ledger inventory drifted")
    for checkpoint in checkpoint_ledger:
        step = int(checkpoint["checkpoint_step"])
        total, count = totals_by_step[step]
        if (
            not math.isclose(float(checkpoint.get("total_nll", math.nan)), total, rel_tol=1e-10, abs_tol=1e-9)
            or int(checkpoint.get("original_byte_count", -1)) != count
            or not math.isclose(float(checkpoint.get("byte_normalized_nll", math.nan)), total / count, rel_tol=1e-10, abs_tol=1e-12)
            or float(checkpoint.get("elapsed_seconds", -1)) <= 0
            or not math.isclose(
                float(checkpoint.get("original_bytes_per_second", math.nan)),
                count / float(checkpoint.get("elapsed_seconds", math.nan)),
                rel_tol=1e-12,
            )
            or int(checkpoint.get("peak_process_rss_bytes", -1)) <= 0
            or not _is_sha256(checkpoint.get("model_state_sha256"))
            or int(checkpoint.get("cumulative_training_original_bytes", -1)) != calibration_bytes * step
            or int(checkpoint.get("cumulative_training_flops_estimate", -1)) != 3 * train_forward_flops * step
        ):
            raise ValueError("checkpoint ledger is not reproducible")
    if checkpoint_ledger[0]["model_state_sha256"] != expected_initial_sha256 or checkpoint_ledger[-1]["model_state_sha256"] != ledger.get("final_model_state_sha256"):
        raise ValueError("checkpoint model-state endpoints drifted")

    gradient_ledger = evidence.get("gradient_ledger")
    gradients = [float(row["preclip_gradient_l2_norm"]) for row in train_curve]
    updates = [float(row["parameter_update_l2_norm"]) for row in train_curve]
    if not isinstance(gradient_ledger, Mapping) or gradient_ledger != ledger.get("gradient_ledger"):
        raise ValueError("gradient ledger duplication mismatch")
    expected_gradient_values = {
        "steps": config.updates,
        "minimum_preclip_l2_norm": min(gradients),
        "maximum_preclip_l2_norm": max(gradients),
        "mean_preclip_l2_norm": sum(gradients) / len(gradients),
        "zero_gradient_steps": sum(value == 0 for value in gradients),
        "minimum_parameter_update_l2_norm": min(updates),
        "maximum_parameter_update_l2_norm": max(updates),
        "mean_parameter_update_l2_norm": sum(updates) / len(updates),
        "zero_parameter_update_steps": sum(value == 0 for value in updates),
        "all_parameters_finite": True,
    }
    for key, value in expected_gradient_values.items():
        observed = gradient_ledger.get(key)
        if isinstance(value, float):
            if not math.isclose(float(observed), value, rel_tol=1e-12, abs_tol=1e-15):
                raise ValueError("gradient/update aggregate mismatch")
        elif observed != value:
            raise ValueError("gradient/update aggregate mismatch")

    throughput = ledger.get("throughput_ledger")
    if not isinstance(throughput, Mapping) or throughput.get("checkpoint_evaluations") != checkpoint_ledger:
        raise ValueError("throughput/checkpoint ledger mismatch")
    elapsed = float(evidence.get("training_elapsed_seconds", -1))
    processed = int(evidence.get("training_original_bytes_processed", -1))
    rate = float(evidence.get("training_original_bytes_per_second", -1))
    if elapsed <= 0 or processed != calibration_bytes * config.updates or not math.isclose(rate, processed / elapsed, rel_tol=1e-12):
        raise ValueError("training throughput is not reproducible")
    if float(throughput.get("training_elapsed_seconds", -1)) != elapsed or float(throughput.get("training_original_bytes_per_second", -1)) != rate:
        raise ValueError("throughput ledger duplication mismatch")
    if float(evidence.get("cell_total_wall_elapsed_seconds", -1)) <= elapsed or float(throughput.get("cell_total_wall_elapsed_seconds", -1)) != float(evidence.get("cell_total_wall_elapsed_seconds")):
        raise ValueError("total wall-time ledger mismatch")
    memory = ledger.get("memory_ledger")
    if not isinstance(memory, Mapping) or memory != evidence.get("memory_ledger"):
        raise ValueError("memory ledger duplication mismatch")
    parameter_bytes = sum(p.numel() * p.element_size() for p in expected_model.parameters())
    if (
        int(memory.get("parameter_bytes", -1)) != parameter_bytes
        or int(memory.get("adamw_state_bytes_estimate", -1)) != 2 * parameter_bytes
        or int(memory.get("calibration_state_bytes", -1)) != int(calibration_shape[0]) * int(calibration_shape[1]) * config.canonical_width * 4
        or int(memory.get("start_process_peak_rss_bytes", -1)) <= 0
        or int(memory.get("end_process_peak_rss_bytes", -1)) <= 0
        or int(memory.get("end_process_peak_rss_bytes", -1)) < int(memory.get("start_process_peak_rss_bytes", -1))
    ):
        raise ValueError("memory ledger is not reproducible")
    test_split = cell.get("test_split")
    if not isinstance(test_split, Mapping) or test_split.get("status") != "sealed-not-read":
        raise ValueError("official test split was not sealed")
    if expected_test_seal_sha256 is not None:
        if not _is_sha256(expected_test_seal_sha256) or test_split.get("manifest_sha256") != expected_test_seal_sha256:
            raise ValueError("cell test-seal binding mismatch")


def _pointwise_control(architecture: str, config: OracleNoCompositionConfig) -> dict[str, Any]:
    """Train every architecture on an easy pointwise copy task."""

    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(config.control_seed)
        batch, time_steps = 8, 8
        labels = (torch.arange(batch * time_steps).reshape(batch, time_steps) % 2).long()
        states = torch.zeros(batch, time_steps, config.canonical_width)
        states[..., 0] = labels.to(torch.float32).mul(8).sub(4)
        states[..., 1] = 1.0
        mask = torch.ones(batch, time_steps, dtype=torch.bool)
        model = build_predictor(architecture, config, seed=17)
        optimizer = torch.optim.AdamW(
            model.parameters(), lr=config.control_learning_rate, weight_decay=0.0,
        )
        targets = torch.where(labels.eq(0), torch.tensor(11), torch.tensor(193))
        for _ in range(config.control_updates):
            optimizer.zero_grad(set_to_none=True)
            logits = model(states, mask).logits
            loss = F.cross_entropy(logits.reshape(-1, 256), targets.reshape(-1))
            loss.backward()
            optimizer.step()
        with torch.no_grad():
            accuracy = float(model(states, mask).logits.argmax(-1).eq(targets).float().mean().item())
    return {
        "architecture": architecture,
        "accuracy": accuracy,
        "threshold": config.pointwise_positive_min,
        "passed": accuracy >= config.pointwise_positive_min,
        "updates": config.control_updates,
        "learning_rate": config.control_learning_rate,
    }


def _temporal_causality_control(
    architecture: str,
    condition_name: str,
    config: OracleNoCompositionConfig,
) -> dict[str, Any]:
    model = build_predictor(architecture, config, seed=17).eval()
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(config.control_seed + 1)
        states = torch.randn(1, 6, config.canonical_width, requires_grad=True)
    mask = torch.ones(1, 6, dtype=torch.bool)
    baseline = model(states, mask).logits
    future_changed = states.detach().clone()
    future_changed[:, 4:] += 20.0
    future_effect = float((model(future_changed, mask).logits[:, :4] - baseline[:, :4]).abs().max().item())
    past_changed = states.detach().clone()
    past_changed[:, 0] += 5.0
    temporal_effect = float((model(past_changed, mask).logits[:, 3] - baseline[:, 3]).abs().max().item())
    gradient = torch.autograd.grad(baseline[0, 3, 0], states)[0]
    future_gradient = float(gradient[:, 4:].abs().max().item())
    passed = (
        future_effect <= config.future_gradient_max
        and future_gradient <= config.future_gradient_max
        and temporal_effect >= config.temporal_effect_min
    )
    return {
        "architecture": architecture,
        "condition": condition_name,
        "future_perturbation_effect": future_effect,
        "future_gradient_max": future_gradient,
        "past_temporal_effect": temporal_effect,
        "future_tolerance": config.future_gradient_max,
        "temporal_effect_min": config.temporal_effect_min,
        "passed": passed,
    }


def _synthetic_view(
    name: str,
    states: torch.Tensor,
    slot_mask: torch.Tensor,
    time_mask: torch.Tensor,
) -> RepresentationView:
    return RepresentationView(
        name=name,
        states=states,
        slot_mask=slot_mask,
        time_mask=time_mask,
        metadata={"condition_name": name, "synthetic_control": True},
    )


def _invertible_padding_control(config: OracleNoCompositionConfig) -> dict[str, Any]:
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(config.control_seed + 2)
        sources = torch.randn(32, 64, dtype=torch.float64)
        q, _ = torch.linalg.qr(torch.randn(64, 64, dtype=torch.float64))
        mixed = sources @ q
        recovered = mixed @ q.T
        nrmse = float(torch.linalg.vector_norm(recovered - sources) / torch.linalg.vector_norm(sources))
        states = mixed.to(torch.float32).reshape(4, 8, 2, 32)
        slot_mask = torch.ones(4, 8, 2, dtype=torch.bool)
        time_mask = torch.ones(4, 8, dtype=torch.bool)
        slot_mask[0, 0, 1] = False
        view = _synthetic_view("spectral_roles_uncomposed", states, slot_mask, time_mask)
        calibration = fit_rms_calibration(view, config)
        canonical = canonicalize_representation(view, calibration, config)
        structural_padding_zero = bool(torch.all(canonical.states[..., 64:].eq(0)).item())
        masked_slot_zero = bool(torch.all(canonical.states[0, 0, 32:64].eq(0)).item())
        # Exercise the actual decoder forward path on the analytically
        # recovered values, not only the linear-algebra identity.
        source_128 = F.pad(sources.to(torch.float32), (0, 64)).reshape(4, 8, 128)
        recovered_128 = F.pad(recovered.to(torch.float32), (0, 64)).reshape(4, 8, 128)
        decoder = build_predictor("linear", config, seed=17).eval()
        with torch.no_grad():
            source_logits = decoder(source_128, time_mask).logits
            recovered_logits = decoder(recovered_128, time_mask).logits
        decoder_logit_error = float((source_logits - recovered_logits).abs().max().item())
    passed = (
        nrmse <= config.invertible_mix_nrmse_max
        and decoder_logit_error <= config.invertible_decoder_logit_max
        and structural_padding_zero and masked_slot_zero
    )
    return {
        "analytic_inverse_nrmse": nrmse,
        "threshold": config.invertible_mix_nrmse_max,
        "decoder_logit_max_abs_error": decoder_logit_error,
        "decoder_logit_threshold": config.invertible_decoder_logit_max,
        "right_padding_exact_zero": structural_padding_zero,
        "masked_slot_exact_zero": masked_slot_zero,
        "passed": passed,
    }


def _singular_alias_control(config: OracleNoCompositionConfig) -> dict[str, Any]:
    # The rank-one channel maps (+1,label0) and (+1,label1) to the same
    # observation equally often.  Its Bayes accuracy is exactly 1/2.
    observations = torch.ones(64, 1)
    labels = torch.arange(64) % 2
    _, inverse = torch.unique(observations, dim=0, return_inverse=True)
    correct = 0
    for group in inverse.unique():
        group_labels = labels[inverse.eq(group)]
        correct += int(torch.bincount(group_labels).max().item())
    ceiling = correct / labels.numel()
    states = torch.zeros(8, 8, config.canonical_width)
    states[..., 0] = 1.0
    mask = torch.ones(8, 8, dtype=torch.bool)
    targets = torch.where(labels.reshape(8, 8).eq(0), torch.tensor(13), torch.tensor(211))
    decoder = build_predictor("linear", config, seed=17)
    optimizer = torch.optim.AdamW(
        decoder.parameters(), lr=config.control_learning_rate, weight_decay=0.0,
    )
    for _ in range(config.control_updates):
        optimizer.zero_grad(set_to_none=True)
        logits = decoder(states, mask).logits
        loss = F.cross_entropy(logits.reshape(-1, 256), targets.reshape(-1))
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        decoder_accuracy = float(
            decoder(states, mask).logits.argmax(-1).eq(targets).float().mean().item()
        )
    passed = (
        abs(ceiling - 0.5) <= config.alias_ceiling_tolerance
        and abs(decoder_accuracy - ceiling) <= config.alias_ceiling_tolerance
    )
    return {
        "singular_rank": int(torch.linalg.matrix_rank(observations).item()),
        "bayes_accuracy_ceiling": ceiling,
        "expected_ceiling": 0.5,
        "decoder_evaluation_accuracy": decoder_accuracy,
        "tolerance": config.alias_ceiling_tolerance,
        "passed": passed,
    }


def _paired_budget_control(config: OracleNoCompositionConfig) -> dict[str, Any]:
    rows = []
    passed = True
    for architecture in DOWNSTREAM_FAMILIES:
        condition_hashes: dict[str, str] = {}
        condition_parameters: dict[str, int] = {}
        condition_flops: dict[str, int] = {}
        for condition_name in REPRESENTATION_CONDITION_NAMES:
            model = build_predictor(architecture, config, seed=17)
            condition_hashes[condition_name] = module_state_fingerprint(model)
            condition_parameters[condition_name] = parameter_count(model)
            condition_flops[condition_name] = _forward_flops(architecture, 8, 224, config)
        left_hash = next(iter(condition_hashes.values()))
        params = next(iter(condition_parameters.values()))
        equal = (
            len(set(condition_hashes.values())) == 1
            and len(set(condition_parameters.values())) == 1
            and len(set(condition_flops.values())) == 1
        )
        passed = passed and equal
        rows.append({
            "architecture": architecture,
            "condition_independent_initial_state_sha256": left_hash,
            "condition_initial_state_sha256": condition_hashes,
            "parameters": params,
            "condition_parameter_counts": condition_parameters,
            "condition_forward_flops": condition_flops,
            "schedule_sha256": _digest({
                "updates": config.updates,
                "checkpoints": config.checkpoint_steps,
                "batch_schedule": config.batch_schedule,
            }),
            "passed": equal,
        })
    return {"architectures": rows, "passed": passed}


def _poisoning_and_frozen_control(config: OracleNoCompositionConfig) -> dict[str, Any]:
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(config.control_seed + 3)
        spectral = LearnedSpectrumFrontend(
            config.primary_dimension, window_length=config.primary_window,
        )
        byte_reference = ByteFrontend(config.primary_dimension)
        receiver = ReceiverAnalysisBank(
            config.primary_window, config.primary_dimension, "learned-matched",
        )
        frozen_modules_before = {
            "transmitter": module_state_fingerprint(spectral),
            "receiver": module_state_fingerprint(receiver),
            "byte_reference": module_state_fingerprint(byte_reference),
        }
        clean_batch = spectral.batch(["causal-a", "causal-b"])
        poisoned = clean_batch.targets.clone()
        poisoned[clean_batch.valid] = (
            torch.flip(poisoned, dims=(1,))[clean_batch.valid] + 97
        ).remainder(256)
        poisoned_batch = replace(clean_batch, targets=poisoned)
        batch_poisoning_evidence = {
            "clean_targets": clean_batch.targets.detach().cpu().tolist(),
            "poisoned_targets": poisoned_batch.targets.detach().cpu().tolist(),
            "clean_targets_sha256": tensor_state_fingerprint(clean_batch.targets),
            "poisoned_targets_sha256": tensor_state_fingerprint(poisoned_batch.targets),
            "targets_differ_on_valid_objectives": bool(
                torch.any(clean_batch.targets[clean_batch.valid].ne(poisoned_batch.targets[poisoned_batch.valid])).item()
            ),
            "clean_input_ids": clean_batch.input_ids.detach().cpu().tolist(),
            "poisoned_input_ids": poisoned_batch.input_ids.detach().cpu().tolist(),
            "clean_input_ids_sha256": tensor_state_fingerprint(clean_batch.input_ids),
            "poisoned_input_ids_sha256": tensor_state_fingerprint(poisoned_batch.input_ids),
            "input_ids_invariant": torch.equal(clean_batch.input_ids, poisoned_batch.input_ids),
            "clean_valid": clean_batch.valid.detach().cpu().tolist(),
            "poisoned_valid": poisoned_batch.valid.detach().cpu().tolist(),
            "clean_valid_sha256": tensor_state_fingerprint(clean_batch.valid),
            "poisoned_valid_sha256": tensor_state_fingerprint(poisoned_batch.valid),
            "valid_mask_invariant": torch.equal(clean_batch.valid, poisoned_batch.valid),
            "clean_byte_count": int(clean_batch.byte_count),
            "poisoned_byte_count": int(poisoned_batch.byte_count),
            "document_ids_invariant": clean_batch.document_ids == poisoned_batch.document_ids,
        }
        clean_bundle = build_representation_bundle(
            clean_batch,
            spectral_frontend=spectral,
            learned_matched_receiver=receiver,
            byte_reference=byte_reference,
        )
        poisoned_bundle = build_representation_bundle(
            poisoned_batch,
            spectral_frontend=spectral,
            learned_matched_receiver=receiver,
            byte_reference=byte_reference,
        )
    condition_rows: list[dict[str, Any]] = []
    all_passed = True
    for condition_name in REPRESENTATION_CONDITION_NAMES:
        clean_view = clean_bundle.condition(condition_name)
        poisoned_view = poisoned_bundle.condition(condition_name)
        before = tensor_state_fingerprint(clean_view.states)
        poisoned_source = tensor_state_fingerprint(poisoned_view.states)
        calibration = fit_rms_calibration(clean_view, config)
        canonical_a = canonicalize_representation(clean_view, calibration, config)
        canonical_b = canonicalize_representation(poisoned_view, calibration, config)
        family_rows = []
        for architecture in DOWNSTREAM_FAMILIES:
            model = build_predictor(architecture, config, seed=17).eval()
            with torch.no_grad():
                clean_logits = model(canonical_a.states, canonical_a.time_mask).logits
                poisoned_logits = model(canonical_b.states, canonical_b.time_mask).logits
            invariant = torch.equal(clean_logits, poisoned_logits)
            family_rows.append({"architecture": architecture, "logits_invariant": invariant})
        after = tensor_state_fingerprint(clean_view.states)
        equal = torch.equal(canonical_a.states, canonical_b.states)
        passed = (
            equal and before == poisoned_source == after
            and all(row["logits_invariant"] for row in family_rows)
        )
        all_passed = all_passed and passed
        condition_rows.append({
            "condition": condition_name,
            "source_before_sha256": before,
            "poisoned_target_extraction_sha256": poisoned_source,
            "source_after_sha256": after,
            "canonical_target_poisoning_invariant": equal,
            "frozen_source_fingerprint_invariant": before == after,
            "families": family_rows,
            "passed": passed,
        })
    frozen_modules_after = {
        "transmitter": module_state_fingerprint(spectral),
        "receiver": module_state_fingerprint(receiver),
        "byte_reference": module_state_fingerprint(byte_reference),
    }
    modules_frozen = frozen_modules_before == frozen_modules_after
    return {
        "batch_poisoning_evidence": batch_poisoning_evidence,
        "conditions": condition_rows,
        "frozen_modules_before": frozen_modules_before,
        "frozen_modules_after": frozen_modules_after,
        "frozen_modules_invariant": modules_frozen,
        "passed": all_passed and modules_frozen,
    }


def run_machinery_controls(
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
    *,
    test_seal_sha256: str | None = None,
) -> dict[str, Any]:
    """Run all deterministic controls before any qualifying language cell."""

    config.validate()
    if test_seal_sha256 is not None and not _is_sha256(test_seal_sha256):
        raise ValueError("test seal must be a SHA-256 digest")
    pointwise = [_pointwise_control(name, config) for name in DOWNSTREAM_FAMILIES]
    temporal = [
        _temporal_causality_control(architecture, condition_name, config)
        for architecture in ("vanilla-transformer", "bounded-oracle-transformer")
        for condition_name in REPRESENTATION_CONDITION_NAMES
    ]
    controls = {
        "pointwise_copy": pointwise,
        "temporal_causality": temporal,
        "invertible_mix_and_padding": _invertible_padding_control(config),
        "singular_alias": _singular_alias_control(config),
        "paired_initialization_and_budget": _paired_budget_control(config),
        "target_poisoning_and_frozen_input": _poisoning_and_frozen_control(config),
    }
    passed = (
        all(item["passed"] for item in pointwise)
        and all(item["passed"] for item in temporal)
        and all(value["passed"] for key, value in controls.items() if key not in {"pointwise_copy", "temporal_causality"})
    )
    return {
        "schema_version": CONTROL_SCHEMA,
        "issue": ISSUE_NUMBER,
        "config_sha256": config_digest(config),
        "language_data_read": False,
        "test_accessed": False,
        "test_split": {"status": "sealed-not-read", "manifest_sha256": test_seal_sha256},
        "controls": controls,
        "all_required_controls_passed": passed,
        "interpretation_allowed": passed,
    }


def require_machinery_controls(
    evidence: Mapping[str, Any],
    config: OracleNoCompositionConfig = DEFAULT_CONFIG,
    *,
    expected_test_seal_sha256: str | None = None,
) -> None:
    if evidence.get("schema_version") != CONTROL_SCHEMA or evidence.get("issue") != ISSUE_NUMBER:
        raise RuntimeError("invalid #123 machinery-control evidence")
    if evidence.get("config_sha256") != config_digest(config):
        raise RuntimeError("machinery controls were run under a different config")
    if evidence.get("language_data_read") is not False or evidence.get("test_accessed") is not False:
        raise RuntimeError("machinery controls were not isolated from language data")
    test_split = evidence.get("test_split")
    if not isinstance(test_split, Mapping) or test_split.get("status") != "sealed-not-read":
        raise RuntimeError("machinery controls do not attest a sealed test split")
    if expected_test_seal_sha256 is not None:
        if not _is_sha256(expected_test_seal_sha256) or test_split.get("manifest_sha256") != expected_test_seal_sha256:
            raise RuntimeError("machinery-control test seal mismatch")

    controls = evidence.get("controls")
    if not isinstance(controls, Mapping) or set(controls) != {
        "pointwise_copy", "temporal_causality", "invertible_mix_and_padding",
        "singular_alias", "paired_initialization_and_budget",
        "target_poisoning_and_frozen_input",
    }:
        raise RuntimeError("machinery-control inventory drifted")
    pointwise = controls["pointwise_copy"]
    if not isinstance(pointwise, list) or [row.get("architecture") for row in pointwise] != list(DOWNSTREAM_FAMILIES):
        raise RuntimeError("pointwise control architecture inventory drifted")
    derived = True
    for row in pointwise:
        passed = (
            float(row.get("accuracy", -1)) >= config.pointwise_positive_min
            and float(row.get("threshold", -1)) == config.pointwise_positive_min
            and int(row.get("updates", -1)) == config.control_updates
            and float(row.get("learning_rate", -1)) == config.control_learning_rate
        )
        if row.get("passed") is not passed:
            raise RuntimeError("pointwise control pass flag does not match raw metrics")
        derived = derived and passed

    temporal = controls["temporal_causality"]
    expected_temporal = [
        (architecture, condition)
        for architecture in ("vanilla-transformer", "bounded-oracle-transformer")
        for condition in REPRESENTATION_CONDITION_NAMES
    ]
    if not isinstance(temporal, list) or [(row.get("architecture"), row.get("condition")) for row in temporal] != expected_temporal:
        raise RuntimeError("temporal-control condition inventory drifted")
    for row in temporal:
        passed = (
            float(row.get("future_perturbation_effect", math.inf)) <= config.future_gradient_max
            and float(row.get("future_gradient_max", math.inf)) <= config.future_gradient_max
            and float(row.get("past_temporal_effect", -math.inf)) >= config.temporal_effect_min
            and float(row.get("future_tolerance", -1)) == config.future_gradient_max
            and float(row.get("temporal_effect_min", -1)) == config.temporal_effect_min
        )
        if row.get("passed") is not passed:
            raise RuntimeError("temporal-control pass flag does not match raw metrics")
        derived = derived and passed

    invertible = controls["invertible_mix_and_padding"]
    passed = (
        float(invertible.get("analytic_inverse_nrmse", math.inf)) <= config.invertible_mix_nrmse_max
        and float(invertible.get("threshold", -1)) == config.invertible_mix_nrmse_max
        and float(invertible.get("decoder_logit_max_abs_error", math.inf)) <= config.invertible_decoder_logit_max
        and float(invertible.get("decoder_logit_threshold", -1)) == config.invertible_decoder_logit_max
        and invertible.get("right_padding_exact_zero") is True
        and invertible.get("masked_slot_exact_zero") is True
    )
    if invertible.get("passed") is not passed:
        raise RuntimeError("invertible control pass flag does not match raw metrics")
    derived = derived and passed

    singular = controls["singular_alias"]
    passed = (
        int(singular.get("singular_rank", -1)) == 1
        and abs(float(singular.get("bayes_accuracy_ceiling", math.inf)) - 0.5) <= config.alias_ceiling_tolerance
        and abs(float(singular.get("decoder_evaluation_accuracy", math.inf)) - float(singular.get("bayes_accuracy_ceiling", -math.inf))) <= config.alias_ceiling_tolerance
        and float(singular.get("expected_ceiling", -1)) == 0.5
        and float(singular.get("tolerance", -1)) == config.alias_ceiling_tolerance
    )
    if singular.get("passed") is not passed:
        raise RuntimeError("singular control pass flag does not match raw metrics")
    derived = derived and passed

    paired = controls["paired_initialization_and_budget"]
    paired_rows = paired.get("architectures") if isinstance(paired, Mapping) else None
    if not isinstance(paired_rows, list) or [row.get("architecture") for row in paired_rows] != list(DOWNSTREAM_FAMILIES):
        raise RuntimeError("paired-budget control inventory drifted")
    paired_pass = True
    for row in paired_rows:
        architecture = str(row.get("architecture"))
        hashes = row.get("condition_initial_state_sha256")
        params = row.get("condition_parameter_counts")
        flops = row.get("condition_forward_flops")
        if not all(
            isinstance(item, Mapping) and set(item) == set(REPRESENTATION_CONDITION_NAMES)
            for item in (hashes, params, flops)
        ):
            raise RuntimeError("paired-budget condition map drifted")
        expected_model = build_predictor(architecture, config, seed=17)
        expected_hash = module_state_fingerprint(expected_model)
        expected_params = parameter_count(expected_model)
        expected_flops = _forward_flops(architecture, 8, 224, config)
        expected_schedule = _digest({
            "updates": config.updates,
            "checkpoints": config.checkpoint_steps,
            "batch_schedule": config.batch_schedule,
        })
        row_pass = (
            set(hashes.values()) == {expected_hash}
            and set(params.values()) == {expected_params}
            and set(flops.values()) == {expected_flops}
            and row.get("condition_independent_initial_state_sha256") == expected_hash
            and row.get("parameters") == expected_params
            and row.get("schedule_sha256") == expected_schedule
        )
        if row.get("passed") is not row_pass:
            raise RuntimeError("paired-budget pass flag does not match raw evidence")
        paired_pass = paired_pass and row_pass
    if paired.get("passed") is not paired_pass:
        raise RuntimeError("paired-budget aggregate flag does not match raw evidence")
    derived = derived and paired_pass

    poisoning = controls["target_poisoning_and_frozen_input"]
    batch_poison = poisoning.get("batch_poisoning_evidence") if isinstance(poisoning, Mapping) else None
    if not isinstance(batch_poison, Mapping):
        raise RuntimeError("target-poisoning batch evidence is absent")
    try:
        clean_targets = torch.tensor(batch_poison["clean_targets"], dtype=torch.long)
        poisoned_targets = torch.tensor(batch_poison["poisoned_targets"], dtype=torch.long)
        clean_inputs = torch.tensor(batch_poison["clean_input_ids"], dtype=torch.long)
        poisoned_inputs = torch.tensor(batch_poison["poisoned_input_ids"], dtype=torch.long)
        clean_valid = torch.tensor(batch_poison["clean_valid"], dtype=torch.bool)
        poisoned_valid = torch.tensor(batch_poison["poisoned_valid"], dtype=torch.bool)
    except (KeyError, TypeError, ValueError) as error:
        raise RuntimeError("target-poisoning tensors are malformed") from error
    batch_poison_pass = (
        tuple(clean_targets.shape) == tuple(poisoned_targets.shape) == tuple(clean_inputs.shape)
        and tuple(clean_inputs.shape) == tuple(poisoned_inputs.shape) == tuple(clean_valid.shape) == tuple(poisoned_valid.shape)
        and tensor_state_fingerprint(clean_targets) == batch_poison.get("clean_targets_sha256")
        and tensor_state_fingerprint(poisoned_targets) == batch_poison.get("poisoned_targets_sha256")
        and tensor_state_fingerprint(clean_inputs) == batch_poison.get("clean_input_ids_sha256")
        and tensor_state_fingerprint(poisoned_inputs) == batch_poison.get("poisoned_input_ids_sha256")
        and tensor_state_fingerprint(clean_valid) == batch_poison.get("clean_valid_sha256")
        and tensor_state_fingerprint(poisoned_valid) == batch_poison.get("poisoned_valid_sha256")
        and torch.equal(clean_inputs, poisoned_inputs)
        and torch.equal(clean_valid, poisoned_valid)
        and bool(torch.any(clean_targets[clean_valid].ne(poisoned_targets[poisoned_valid])).item())
        and batch_poison.get("targets_differ_on_valid_objectives") is True
        and batch_poison.get("input_ids_invariant") is True
        and batch_poison.get("valid_mask_invariant") is True
        and int(batch_poison.get("clean_byte_count", -1)) == int(clean_valid.sum().item())
        and batch_poison.get("clean_byte_count") == batch_poison.get("poisoned_byte_count")
        and batch_poison.get("document_ids_invariant") is True
    )
    if not batch_poison_pass:
        raise RuntimeError("target-poisoning batch invariants failed rederivation")
    poison_rows = poisoning.get("conditions") if isinstance(poisoning, Mapping) else None
    if not isinstance(poison_rows, list) or [row.get("condition") for row in poison_rows] != list(REPRESENTATION_CONDITION_NAMES):
        raise RuntimeError("target-poisoning condition inventory drifted")
    poison_pass = batch_poison_pass
    for row in poison_rows:
        family_rows = row.get("families")
        row_pass = (
            _is_sha256(row.get("source_before_sha256"))
            and row.get("source_before_sha256") == row.get("poisoned_target_extraction_sha256")
            and row.get("source_before_sha256") == row.get("source_after_sha256")
            and row.get("canonical_target_poisoning_invariant") is True
            and row.get("frozen_source_fingerprint_invariant") is True
            and isinstance(family_rows, list)
            and [item.get("architecture") for item in family_rows] == list(DOWNSTREAM_FAMILIES)
            and all(item.get("logits_invariant") is True for item in family_rows)
        )
        if row.get("passed") is not row_pass:
            raise RuntimeError("target-poisoning pass flag does not match raw evidence")
        poison_pass = poison_pass and row_pass
    modules_before = poisoning.get("frozen_modules_before")
    modules_after = poisoning.get("frozen_modules_after")
    modules_pass = (
        isinstance(modules_before, Mapping)
        and set(modules_before) == {"transmitter", "receiver", "byte_reference"}
        and all(_is_sha256(value) for value in modules_before.values())
        and modules_before == modules_after
        and poisoning.get("frozen_modules_invariant") is True
    )
    poison_pass = poison_pass and modules_pass
    if poisoning.get("passed") is not poison_pass:
        raise RuntimeError("target-poisoning aggregate flag does not match raw evidence")
    derived = derived and poison_pass

    if evidence.get("all_required_controls_passed") is not derived or evidence.get("interpretation_allowed") is not derived:
        raise RuntimeError("machinery-control aggregate does not match rederived gates")
    if not derived:
        raise RuntimeError("#123 invalid-instrumentation: a required machinery control failed")


__all__ = [
    "ISSUE_NUMBER", "CONFIG_SCHEMA", "CELL_SCHEMA", "CONTROL_SCHEMA",
    "DOWNSTREAM_FAMILIES", "OracleNoCompositionConfig", "DEFAULT_CONFIG",
    "fast_fixture_config", "config_wire", "config_digest",
    "RMSCalibration", "CanonicalRepresentation", "fit_rms_calibration",
    "canonicalize_representation", "PredictorOutput",
    "LinearNextBytePredictor", "ShallowMLPNextBytePredictor",
    "CausalTransformerNextBytePredictor", "BoundedOracleTransformerPredictor",
    "build_predictor", "parameter_count", "FittedConditionPredictor",
    "fit_condition_predictor", "evaluate_condition_predictor",
    "fit_and_evaluate_condition", "validate_cell_result",
    "run_machinery_controls", "require_machinery_controls",
]
