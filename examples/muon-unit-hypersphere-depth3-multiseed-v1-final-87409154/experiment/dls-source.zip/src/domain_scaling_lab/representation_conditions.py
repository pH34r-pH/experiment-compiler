"""Reusable representation-stage interfaces for issues #122 and #123.

The interfaces in this module make the causal decomposition explicit without
changing the frozen Gate-A transmitter or the selected Phase-1 receiver.  A
``RepresentationBundle`` exposes the same batch at six named stages, while
``SourceVariables`` records input-symbol labels separately from the next-byte
objective.  Phonology and position values may be attached as diagnostic
sidecars, but they are never silently added to a transmitted representation.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

import torch
from torch import nn

from .receivers import (
    ReceiverAnalysisBank,
    SpectralWindowState,
    freeze_spectral_window_state,
    tensor_fingerprint,
)
from .spectral import TextBatch, module_state_fingerprint


REPRESENTATION_BUNDLE_SCHEMA = "representation-decomposition/v1"
REPRESENTATION_CONDITION_NAMES = (
    "byte_embedding",
    "spectral_current_uncomposed",
    "spectral_roles_uncomposed",
    "spectral_composite_raw",
    "spectral_composite_learned_matched",
    "spectral_roles_demultiplexed",
)


@dataclass(frozen=True)
class RepresentationView:
    """One stage of the decomposition in a common slot-shaped contract.

    ``states`` are always ``[batch, time, slots, dimension]``.  ``slot_mask``
    says which slots contain an actual causal source at an objective-valid
    time, while ``time_mask`` preserves the original next-byte objective
    timeline.  The distinction is important at BOS: the objective may be
    valid even though no prior input symbol exists for a spectral slot.
    """

    name: str
    states: torch.Tensor
    slot_mask: torch.Tensor
    time_mask: torch.Tensor
    metadata: Mapping[str, Any]

    def __post_init__(self) -> None:
        if self.states.ndim != 4:
            raise ValueError("representation states must be [batch, time, slots, dimension]")
        if tuple(self.slot_mask.shape) != tuple(self.states.shape[:3]):
            raise ValueError("slot_mask must align with representation batch/time/slots")
        if tuple(self.time_mask.shape) != tuple(self.states.shape[:2]):
            raise ValueError("time_mask must align with representation batch/time")
        if self.slot_mask.dtype != torch.bool or self.time_mask.dtype != torch.bool:
            raise TypeError("representation masks must be boolean")
        if self.name != self.metadata.get("condition_name"):
            raise ValueError("representation metadata must bind its stable condition name")

    @property
    def slot_count(self) -> int:
        return self.states.size(-2)

    @property
    def dimension(self) -> int:
        return self.states.size(-1)

    def flatten_slots(self) -> torch.Tensor:
        """Return a deterministic masked ``[B,T,S*D]`` adapter for probes."""
        masked = self.states * self.slot_mask[..., None].to(dtype=self.states.dtype)
        return masked.flatten(start_dim=-2)


@dataclass(frozen=True)
class SourceVariables:
    """Causal source labels and coordinates shared by every condition.

    Labels are UTF-8 byte values ``0..255`` derived from ``batch.input_ids``;
    ``-1`` marks BOS, padding, or an unavailable role.  They are deliberately
    not copied from ``batch.targets``.
    """

    causal_input_symbol_labels: torch.Tensor
    causal_input_symbol_valid: torch.Tensor
    role_input_symbol_labels: torch.Tensor
    role_input_symbol_valid: torch.Tensor
    role_offsets: torch.Tensor
    local_role_positions: torch.Tensor
    document_role_positions: torch.Tensor
    document_positions: torch.Tensor
    document_lengths: torch.Tensor
    diagnostic_sidecars: Mapping[str, torch.Tensor]
    sidecar_metadata: Mapping[str, Mapping[str, Any]]

    def __post_init__(self) -> None:
        batch_time = tuple(self.causal_input_symbol_labels.shape)
        if len(batch_time) != 2 or tuple(self.causal_input_symbol_valid.shape) != batch_time:
            raise ValueError("causal input-symbol labels must be [batch, time]")
        role_shape = tuple(self.role_input_symbol_labels.shape)
        if len(role_shape) != 3 or role_shape[:2] != batch_time:
            raise ValueError("role input-symbol labels must be [batch, time, role]")
        if tuple(self.role_input_symbol_valid.shape) != role_shape:
            raise ValueError("role input-symbol mask must align with role labels")
        if tuple(self.local_role_positions.shape) != role_shape or tuple(self.document_role_positions.shape) != role_shape:
            raise ValueError("role coordinates must align with role labels")
        if tuple(self.document_positions.shape) != batch_time or tuple(self.document_lengths.shape) != batch_time:
            raise ValueError("document coordinates must be [batch, time]")
        if tuple(self.role_offsets.shape) != (role_shape[-1],):
            raise ValueError("role_offsets must have one entry per role")
        if self.causal_input_symbol_valid.dtype != torch.bool or self.role_input_symbol_valid.dtype != torch.bool:
            raise TypeError("source-variable masks must be boolean")
        if torch.any(self.causal_input_symbol_labels[~self.causal_input_symbol_valid].ne(-1)):
            raise ValueError("invalid current-symbol labels must use the -1 sentinel")
        if torch.any(self.role_input_symbol_labels[~self.role_input_symbol_valid].ne(-1)):
            raise ValueError("invalid role-symbol labels must use the -1 sentinel")
        for name, value in self.diagnostic_sidecars.items():
            if value.ndim < 2 or tuple(value.shape[:2]) != batch_time:
                raise ValueError(f"diagnostic sidecar {name!r} must align with batch/time")
            metadata = self.sidecar_metadata.get(name)
            if metadata is None or metadata.get("transmitted_source") is not False or metadata.get("diagnostic_only") is not True:
                raise ValueError(f"diagnostic sidecar {name!r} lacks a non-transmitted scope declaration")


@dataclass(frozen=True)
class RepresentationBundle:
    """The six stable #122/#123 views for one frozen causal batch."""

    views: Mapping[str, RepresentationView]
    sources: SourceVariables
    spectral_state: SpectralWindowState
    metadata: Mapping[str, Any]

    def __post_init__(self) -> None:
        if tuple(self.views) != REPRESENTATION_CONDITION_NAMES:
            raise ValueError("representation bundle conditions or ordering drifted")
        if tuple(self.metadata.get("condition_names", ())) != REPRESENTATION_CONDITION_NAMES:
            raise ValueError("representation bundle metadata does not bind the condition order")
        batch_time = tuple(self.sources.causal_input_symbol_labels.shape)
        if any(tuple(view.time_mask.shape) != batch_time for view in self.views.values()):
            raise ValueError("all representation views must share one batch/time timeline")

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(self.views)

    def condition(self, name: str) -> RepresentationView:
        try:
            return self.views[name]
        except KeyError as error:
            raise KeyError(f"unknown representation condition {name!r}") from error


def _role_source_variables(
    batch: TextBatch,
    window_length: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Align causal input IDs and coordinates to every spectral role."""
    batch_size, time = batch.input_ids.shape
    device = batch.input_ids.device
    offsets = torch.arange(window_length, device=device, dtype=torch.long)
    source_timeline = torch.arange(time, device=device)[:, None] - offsets[None, :]
    gather_timeline = source_timeline.clamp_min(0)
    role_input_ids = batch.input_ids[:, gather_timeline]
    temporal_valid = source_timeline.ge(0)[None].expand(batch_size, -1, -1)
    role_valid = temporal_valid & batch.valid[..., None] & role_input_ids.ne(0)
    role_labels = torch.where(role_valid, role_input_ids - 1, torch.full_like(role_input_ids, -1))
    # ``source_timeline`` indexes the causal input-state buffer.  Its lexical
    # ID at input time ``i`` is the source byte at local coordinate ``i - 1``
    # (input time zero is BOS).  Keep the source-byte coordinate here so local
    # and document positions describe the same underlying byte.
    local_positions = (source_timeline - 1)[None].expand(batch_size, -1, -1)
    local_positions = torch.where(role_valid, local_positions, torch.full_like(local_positions, -1))
    return role_labels, role_valid, offsets, local_positions, source_timeline


def _document_coordinates(batch: TextBatch) -> tuple[torch.Tensor, torch.Tensor]:
    batch_size, time = batch.input_ids.shape
    if batch.document_positions is None:
        positions = torch.arange(time, device=batch.input_ids.device).expand(batch_size, time)
    else:
        positions = batch.document_positions
    if batch.document_lengths is None:
        lengths = torch.full_like(positions, time)
    else:
        lengths = batch.document_lengths
    if tuple(positions.shape) != tuple(batch.input_ids.shape) or tuple(lengths.shape) != tuple(batch.input_ids.shape):
        raise ValueError("document coordinates must align with batch input IDs")
    return positions.detach(), lengths.detach()


def _sidecar(
    name: str,
    value: torch.Tensor | None,
    batch: TextBatch,
    *,
    construction: str,
) -> tuple[torch.Tensor | None, dict[str, Any] | None]:
    if value is None:
        return None, None
    if value.ndim < 2 or tuple(value.shape[:2]) != tuple(batch.input_ids.shape):
        raise ValueError(f"{name} sidecar must align with batch/time")
    return value.detach(), {
        "name": name,
        "diagnostic_only": True,
        "transmitted_source": False,
        "included_in_representation_views": False,
        "uses_next_byte_targets": False,
        "construction": construction,
    }


def _byte_embedding_states(
    byte_reference: nn.Module | torch.Tensor,
    input_ids: torch.Tensor,
) -> tuple[torch.Tensor, dict[str, Any]]:
    if isinstance(byte_reference, torch.Tensor):
        states = byte_reference
        metadata = {
            "reference_kind": "provided-frozen-tensor",
            "embedding_lookup_only": True,
            "state_fingerprint": tensor_fingerprint(states),
        }
    else:
        frontend = getattr(byte_reference, "frontend", byte_reference)
        embedding = frontend if isinstance(frontend, nn.Embedding) else getattr(frontend, "embedding", None)
        if not isinstance(embedding, nn.Embedding):
            raise TypeError("byte_reference must be a byte embedding, ByteFrontend-like module, or frozen tensor")
        with torch.no_grad():
            states = embedding(input_ids).detach()
        metadata = {
            "reference_kind": frontend.__class__.__name__,
            "embedding_lookup_only": True,
            "position_added": False,
            "embedding_weight_fingerprint": tensor_fingerprint(embedding.weight),
        }
    if states.ndim != 3 or tuple(states.shape[:2]) != tuple(input_ids.shape):
        raise ValueError("byte reference states must be [batch, time, dimension]")
    return states.detach(), metadata


def _view(
    name: str,
    states: torch.Tensor,
    slot_mask: torch.Tensor,
    time_mask: torch.Tensor,
    **metadata: Any,
) -> RepresentationView:
    return RepresentationView(
        name=name,
        states=states.detach(),
        slot_mask=slot_mask.detach(),
        time_mask=time_mask.detach(),
        metadata={
            "schema_version": "representation-view/v1",
            "condition_name": name,
            "causal": True,
            "uses_next_byte_targets": False,
            "transmitted_source_names": ["orthographic"],
            **metadata,
        },
    )


def build_representation_bundle(
    batch: TextBatch,
    *,
    spectral_frontend: nn.Module,
    learned_matched_receiver: ReceiverAnalysisBank,
    byte_reference: nn.Module | torch.Tensor,
    phonology_sidecar: torch.Tensor | None = None,
    position_sidecar: torch.Tensor | None = None,
) -> RepresentationBundle:
    """Build the fixed six-condition representation interface for #122/#123.

    The byte and spectral tensors are derived only from ``batch.input_ids``.
    ``batch.targets`` remains available to a downstream LM benchmark, but this
    extraction path never reads it as a source-recovery label.
    """
    if batch.input_ids.ndim != 2 or tuple(batch.valid.shape) != tuple(batch.input_ids.shape):
        raise ValueError("representation bundles require a valid [batch, time] TextBatch")
    if learned_matched_receiver.mode != "learned-matched":
        raise ValueError("the fixed Phase-1 learned-matched receiver is required")

    # The public handoff fingerprints the spectral frontend itself, even when
    # callers pass the owning FrontendLM.  Use that identical module/hash
    # domain so a runner can join bundle provenance to the sealed checkpoint
    # metadata without translating a tensor-only diagnostic fingerprint.
    transmitter_module = getattr(spectral_frontend, "frontend", spectral_frontend)
    if not isinstance(transmitter_module, nn.Module):
        raise TypeError("spectral_frontend must be a module or own a frontend module")

    spectral_state = freeze_spectral_window_state(
        spectral_frontend,
        batch.input_ids,
        document_positions=batch.document_positions,
        document_lengths=batch.document_lengths,
    )
    precomposition = spectral_state.precomposition
    if precomposition is None:  # pragma: no cover - all public frozen states now provide it
        raise RuntimeError("frozen spectral state lacks the pre-composition analysis view")
    if (
        learned_matched_receiver.window_length != spectral_state.window_length
        or learned_matched_receiver.dimension != spectral_state.dimension
    ):
        raise ValueError("learned-matched receiver shape does not match the frozen spectral transmitter")

    byte_states, byte_metadata = _byte_embedding_states(byte_reference, batch.input_ids)
    if byte_states.size(-1) != spectral_state.dimension:
        raise ValueError("byte and spectral reference dimensions must match")
    with torch.no_grad():
        matched_aggregate = learned_matched_receiver(spectral_state).detach()
        matched_slots = learned_matched_receiver.analyze(spectral_state).detach()

    role_labels, role_valid, role_offsets, local_role_positions, _ = _role_source_variables(
        batch, spectral_state.window_length,
    )
    current_valid = batch.valid & batch.input_ids.ne(0)
    current_labels = torch.where(
        current_valid, batch.input_ids - 1, torch.full_like(batch.input_ids, -1),
    )
    document_positions, document_lengths = _document_coordinates(batch)
    document_role_positions = document_positions[..., None] - 1 - role_offsets[None, None, :]
    document_role_positions = torch.where(
        role_valid, document_role_positions, torch.full_like(document_role_positions, -1),
    )

    sidecars: dict[str, torch.Tensor] = {}
    sidecar_metadata: dict[str, Mapping[str, Any]] = {}
    phonology, phonology_metadata = _sidecar(
        "phonology", phonology_sidecar, batch,
        construction="caller-supplied causal phonology; diagnostic variable only",
    )
    if phonology is not None and phonology_metadata is not None:
        sidecars["phonology"], sidecar_metadata["phonology"] = phonology, phonology_metadata
    if position_sidecar is None and batch.document_positions is not None and batch.document_lengths is not None:
        position_sidecar = torch.stack((document_positions, document_lengths), dim=-1).to(torch.float32)
        position_construction = "TextBatch document position/length coordinate pair"
    else:
        position_construction = "caller-supplied causal position diagnostic"
    position, position_metadata = _sidecar(
        "position", position_sidecar, batch, construction=position_construction,
    )
    if position is not None and position_metadata is not None:
        sidecars["position"], sidecar_metadata["position"] = position, position_metadata

    sources = SourceVariables(
        causal_input_symbol_labels=current_labels.detach(),
        causal_input_symbol_valid=current_valid.detach(),
        role_input_symbol_labels=role_labels.detach(),
        role_input_symbol_valid=role_valid.detach(),
        role_offsets=role_offsets.detach(),
        local_role_positions=local_role_positions.detach(),
        document_role_positions=document_role_positions.detach(),
        document_positions=document_positions,
        document_lengths=document_lengths,
        diagnostic_sidecars=sidecars,
        sidecar_metadata=sidecar_metadata,
    )

    time_mask = batch.valid.bool()
    aggregate_slot_mask = (time_mask & role_valid.any(dim=-1))[..., None]
    views = {
        "byte_embedding": _view(
            "byte_embedding", byte_states[:, :, None], time_mask[..., None], time_mask,
            representation_stage="source-reference",
            composition="none",
            oracle_exposure=False,
            **byte_metadata,
        ),
        "spectral_current_uncomposed": _view(
            "spectral_current_uncomposed", precomposition.current_symbols[:, :, None],
            current_valid[..., None], time_mask,
            representation_stage="source-representation-before-composition",
            composition="none",
            oracle_exposure=True,
            scaling="before-mean-and-l2",
        ),
        "spectral_roles_uncomposed": _view(
            "spectral_roles_uncomposed", precomposition.role_slots, role_valid, time_mask,
            representation_stage="explicit-source-role-slots-before-composition",
            composition="none",
            oracle_exposure=True,
            scaling="before-mean-and-l2",
        ),
        "spectral_composite_raw": _view(
            "spectral_composite_raw", spectral_state.composite[:, :, None],
            aggregate_slot_mask, time_mask,
            representation_stage="transmitted-composite",
            composition=spectral_state.transmitter_config,
            oracle_exposure=False,
            state_fingerprint=spectral_state.state_fingerprint,
        ),
        "spectral_composite_learned_matched": _view(
            "spectral_composite_learned_matched", matched_aggregate[:, :, None],
            aggregate_slot_mask, time_mask,
            representation_stage="fixed-receiver-aggregate",
            composition=spectral_state.transmitter_config,
            receiver="learned-matched",
            oracle_exposure=False,
        ),
        "spectral_roles_demultiplexed": _view(
            "spectral_roles_demultiplexed", matched_slots, role_valid, time_mask,
            representation_stage="fixed-receiver-explicit-role-slots",
            composition=spectral_state.transmitter_config,
            receiver="learned-matched",
            receiver_is_non_oracle=True,
            slot_exposure="diagnostic-explicit",
            oracle_exposure=False,
        ),
    }
    metadata = {
        "schema_version": REPRESENTATION_BUNDLE_SCHEMA,
        "condition_names": list(REPRESENTATION_CONDITION_NAMES),
        "source_label_contract": "causal input symbol from input_ids; invalid=-1; never next-byte target",
        "uses_next_byte_targets_for_source_labels": False,
        "transmitter_kind": spectral_state.transmitter_kind,
        "transmitter_config": spectral_state.transmitter_config,
        "transmitter_module_fingerprint": module_state_fingerprint(transmitter_module),
        "receiver": "learned-matched",
        "receiver_module_fingerprint": module_state_fingerprint(learned_matched_receiver),
        # Preserve the established tensor-only diagnostic identity separately
        # from the full-module provenance identity above.
        "receiver_state_fingerprint": tensor_fingerprint(learned_matched_receiver.analysis),
        "diagnostic_sidecars_are_transmitted": False,
        "diagnostic_sidecar_names": list(sidecars),
    }
    return RepresentationBundle(views, sources, spectral_state, metadata)
