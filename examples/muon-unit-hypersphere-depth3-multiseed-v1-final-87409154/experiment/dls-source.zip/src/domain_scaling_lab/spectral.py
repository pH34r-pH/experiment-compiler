"""Controlled, byte-normalized Gate-A harness for spectral text frontends.

The decoder always predicts the next UTF-8 byte.  Tokenizers may consume more
than one byte, but a token is exposed only after its final byte; this avoids
leaking a character/BPE token's future bytes into a causal byte prediction.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
from bisect import bisect_right
from statistics import mean
import subprocess
from typing import Any, Literal, Mapping, Protocol, Sequence, runtime_checkable

import torch
from torch import nn
from torch.nn import functional as F

from .advanced import ByteBPE


@dataclass(frozen=True)
class RepresentationMetadata:
    name: str
    version: str
    alphabet_size: int
    dimension: int
    positional_scheme: str


@dataclass(frozen=True)
class TextBatch:
    input_ids: torch.Tensor
    targets: torch.Tensor
    valid: torch.Tensor
    byte_count: int
    document_ids: tuple[str, ...] = ()
    document_positions: torch.Tensor | None = None
    document_lengths: torch.Tensor | None = None
    # Optional byte-timeline states for representations whose causal expansion
    # cannot be expressed as one discrete ID per byte (for example, aligned
    # phonological features).  The decoder consumes these directly while the
    # objective remains the original UTF-8 byte target.
    frontend_features: torch.Tensor | None = None

    @property
    def loss_mask(self) -> torch.Tensor:
        """Objective mask: valid original UTF-8-byte targets only."""
        return self.valid

    @property
    def attention_mask(self) -> torch.Tensor:
        """Attention mask aligned with the causal frontend input timeline."""
        return self.valid

    @property
    def sequence_lengths(self) -> torch.Tensor:
        """Per-row count of valid (non-padding) positions."""
        return self.valid.sum(dim=-1)


@dataclass(frozen=True)
class DocumentText:
    """A UTF-8-safe document chunk with coordinates in its original source row."""
    text: str
    document_id: str
    byte_offset: int
    document_length: int

    def __post_init__(self) -> None:
        width = len(self.text.encode("utf-8"))
        if not self.text or self.byte_offset < 0 or self.document_length < self.byte_offset + width:
            raise ValueError("document chunks need nonempty text and valid full-document byte coordinates")


@dataclass(frozen=True)
class TokenBatch:
    """Native tokenizer LM batch; byte_count keeps cross-tokenizer scoring fair."""
    input_ids: torch.Tensor
    targets: torch.Tensor
    valid: torch.Tensor
    byte_count: int

    @property
    def loss_mask(self) -> torch.Tensor:
        """Objective mask for native-token targets."""
        return self.valid

    @property
    def attention_mask(self) -> torch.Tensor:
        """Attention mask aligned with native-token inputs."""
        return self.valid

    @property
    def sequence_lengths(self) -> torch.Tensor:
        """Per-row count of valid (non-padding) tokens."""
        return self.valid.sum(dim=-1)


@runtime_checkable
class TextRepresentation(Protocol):
    """Interchangeable frontend contract, including explicit batch/mask semantics."""

    metadata: RepresentationMetadata
    window_length: int

    def encode(self, text: str) -> list[int]: ...
    def decode(self, ids: list[int]) -> str: ...
    def token_byte_lengths(self, text: str) -> list[int]: ...
    def causal_input_ids(self, text: str, length: int | None = None) -> list[int]: ...
    def causal_input_ids_bytes(self, raw: bytes, length: int | None = None) -> list[int]: ...
    def batch(self, texts: list[str], device: torch.device | None = None) -> TextBatch: ...
    def batch_documents(self, documents: Sequence[DocumentText], device: torch.device | None = None) -> TextBatch: ...
    def native_batch(self, texts: list[str], device: torch.device | None = None) -> TokenBatch: ...
    def forward(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None) -> torch.Tensor: ...
    def checkpoint_config(self) -> dict: ...


def _sinusoidal_positions(length: int, dimension: int, device: torch.device) -> torch.Tensor:
    """Conventional position supplied by the frontend, never secretly by the LM."""
    half = dimension // 2
    frequencies = torch.exp(torch.arange(half, device=device) * (-math.log(10_000.0) / max(half, 1)))
    angles = torch.arange(length, device=device)[:, None] * frequencies[None, :]
    out = torch.cat((angles.sin(), angles.cos()), dim=-1)
    return F.pad(out, (0, dimension - out.size(-1)))


def compose_spectral_windows(vectors: torch.Tensor, window_length: int, operator: str = "mean", normalization: str = "l2") -> torch.Tensor:
    """Causally bind the most recent ``window_length`` complex symbol states.

    The operation is deliberately explicit and shared by the two spectral
    frontends.  A sum/mean binds a local sequence by superposition; optional
    L2 normalization controls scale as the load grows.
    """
    if window_length < 1: raise ValueError("window_length must be positive")
    if operator not in {"sum", "mean"}: raise ValueError("operator must be 'sum' or 'mean'")
    if normalization not in {"none", "l2"}: raise ValueError("normalization must be 'none' or 'l2'")
    if window_length == 1: composed = vectors
    else:
        values = vectors.transpose(1, 2)
        padded = F.pad(values, (window_length - 1, 0))
        cumulative = F.pad(padded.cumsum(-1), (1, 0))
        composed = (cumulative[..., window_length:] - cumulative[..., :-window_length]).transpose(1, 2)
    if operator == "mean":
        counts = torch.arange(1, vectors.size(1) + 1, device=vectors.device).clamp(max=window_length)
        composed = composed / counts[None, :, None]
    return F.normalize(composed, dim=-1) if normalization == "l2" else composed


class _Frontend(nn.Module):
    """Common causal expansion. ID zero is BOS/padding, lexical IDs start at one."""

    # Discrete baselines have a one-step causal window; composed frontends
    # override this in their constructors and expose it through the protocol.
    window_length = 1

    def causal_input_ids(self, text: str, length: int | None = None) -> list[int]:
        ids, widths = self.encode(text), self.token_byte_lengths(text)
        raw_length = len(text.encode("utf-8"))
        output = [0] * (raw_length if length is None else length)
        offset = 0
        for token, width in zip(ids, widths):
            offset += width
            if offset < len(output): output[offset] = token + 1
        return output

    def causal_input_ids_bytes(self, raw: bytes, length: int | None = None) -> list[int]:
        """Tokenize only the valid UTF-8 prefix; incomplete trailing bytes stay hidden.

        This preserves raw-byte generation state without inventing replacement
        characters between bytes of a multi-byte code point.
        """
        complete = raw.decode("utf-8", errors="ignore")
        return self.causal_input_ids(complete, len(raw) if length is None else length)

    def batch(self, texts: list[str], device: torch.device | None = None) -> TextBatch:
        return self.batch_documents([DocumentText(text, f"inline:{index}", 0, len(text.encode("utf-8"))) for index, text in enumerate(texts)], device)

    def batch_documents(self, documents: Sequence[DocumentText], device: torch.device | None = None) -> TextBatch:
        """Batch chunks while retaining full-source byte positions for frontends."""
        byte_rows = [list(document.text.encode("utf-8")) for document in documents]
        if not byte_rows or any(not row for row in byte_rows): raise ValueError("Gate-A batches require non-empty texts")
        width = max(map(len, byte_rows))
        inputs = [self.causal_input_ids(document.text, width) for document in documents]
        targets = [row + [0] * (width - len(row)) for row in byte_rows]
        valid = [[True] * len(row) + [False] * (width - len(row)) for row in byte_rows]
        positions = [[document.byte_offset + index for index in range(len(row))] + [0] * (width - len(row)) for document, row in zip(documents, byte_rows, strict=True)]
        lengths = [[document.document_length] * len(row) + [1] * (width - len(row)) for document, row in zip(documents, byte_rows, strict=True)]
        return TextBatch(torch.tensor(inputs, dtype=torch.long, device=device), torch.tensor(targets, dtype=torch.long, device=device), torch.tensor(valid, dtype=torch.bool, device=device), sum(map(len, byte_rows)), tuple(document.document_id for document in documents), torch.tensor(positions, dtype=torch.long, device=device), torch.tensor(lengths, dtype=torch.long, device=device))

    def native_batch(self, texts: list[str], device: torch.device | None = None) -> TokenBatch:
        """Native next-token targets for discrete baselines, normalized by UTF-8 bytes."""
        tokens = [self.encode(text) for text in texts]
        if not tokens or any(not row for row in tokens): raise ValueError("native batches require non-empty texts")
        width = max(map(len, tokens))
        inputs = [[0] + [token + 1 for token in row[:-1]] + [0] * (width - len(row)) for row in tokens]
        targets = [row + [0] * (width - len(row)) for row in tokens]
        valid = [[True] * len(row) + [False] * (width - len(row)) for row in tokens]
        return TokenBatch(torch.tensor(inputs, dtype=torch.long, device=device), torch.tensor(targets, dtype=torch.long, device=device), torch.tensor(valid, dtype=torch.bool, device=device), sum(len(text.encode("utf-8")) for text in texts))

    def _absolute_forward(self, token_ids: torch.Tensor, embedding: nn.Embedding) -> torch.Tensor:
        z = embedding(token_ids)
        return z + _sinusoidal_positions(token_ids.size(1), z.size(-1), token_ids.device)[None]


class ByteFrontend(_Frontend):
    """Byte baseline with an explicit conventional-position frontend contract."""
    def __init__(self, dimension: int):
        super().__init__(); self.embedding = nn.Embedding(257, dimension)
        self.metadata = RepresentationMetadata("byte", "2", 256, dimension, "frontend_sinusoidal")
    def encode(self, text: str) -> list[int]: return list(text.encode("utf-8"))
    def decode(self, ids: list[int]) -> str: return bytes(ids).decode("utf-8", errors="replace")
    def token_byte_lengths(self, text: str) -> list[int]: return [1] * len(text.encode("utf-8"))
    def causal_input_ids_bytes(self, raw: bytes, length: int | None = None) -> list[int]:
        output = [0] * (len(raw) if length is None else length)
        for index, byte in enumerate(raw):
            if index + 1 < len(output): output[index + 1] = byte + 1
        return output
    def forward(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None) -> torch.Tensor: return self._absolute_forward(token_ids, self.embedding)
    def checkpoint_config(self) -> dict: return {"metadata": asdict(self.metadata), "vocabulary": "utf8-bytes-0..255", "position": "frontend_sinusoidal"}


class CharacterFrontend(_Frontend):
    """Character frontend; Unicode characters expand causally to their UTF-8 width."""
    def __init__(self, alphabet: list[str], dimension: int):
        super().__init__(); self.alphabet = tuple(sorted(set(alphabet))); self.stoi = {char: index for index, char in enumerate(self.alphabet)}; self.itos = dict(enumerate(self.alphabet)); self.unknown_id = len(self.alphabet)
        self.embedding = nn.Embedding(len(self.alphabet) + 2, dimension)
        self.metadata = RepresentationMetadata("character", "2", len(self.alphabet) + 1, dimension, "frontend_sinusoidal")
    def encode(self, text: str) -> list[int]: return [self.stoi.get(char, self.unknown_id) for char in text]
    def decode(self, ids: list[int]) -> str: return "".join(self.itos.get(index, "?") for index in ids)
    def token_byte_lengths(self, text: str) -> list[int]: return [len(char.encode("utf-8")) for char in text]
    def forward(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None) -> torch.Tensor: return self._absolute_forward(token_ids, self.embedding)
    def checkpoint_config(self) -> dict: return {"metadata": asdict(self.metadata), "alphabet": list(self.alphabet), "unknown_id": self.unknown_id, "position": "frontend_sinusoidal"}


class BPEFrontend(_Frontend):
    """Small deterministic byte-BPE baseline, causally delayed to token completion."""
    def __init__(self, bpe: ByteBPE, dimension: int):
        super().__init__(); self.bpe = bpe; self.embedding = nn.Embedding(257 + len(bpe.merges), dimension)
        self.metadata = RepresentationMetadata("byte-bpe", "2", 256 + len(bpe.merges), dimension, "frontend_sinusoidal")
    @classmethod
    def fit(cls, texts: list[str], dimension: int, merges: int = 16) -> "BPEFrontend": return cls(ByteBPE().fit(texts, merges), dimension)
    def encode(self, text: str) -> list[int]: return self.bpe.encode(text)
    def decode(self, ids: list[int]) -> str: return self.bpe.decode(ids)
    def _expand(self, token: int) -> list[int]:
        if token < 256: return [token]
        left, right = self.bpe.merges[token - 256]
        return self._expand(left) + self._expand(right)
    def token_byte_lengths(self, text: str) -> list[int]: return [len(self._expand(token)) for token in self.encode(text)]
    def forward(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None) -> torch.Tensor: return self._absolute_forward(token_ids, self.embedding)
    def checkpoint_config(self) -> dict: return {"metadata": asdict(self.metadata), "merges": [list(pair) for pair in self.bpe.merges], "position": "frontend_sinusoidal"}


class LearnedSpectrumFrontend(_Frontend):
    """Learned complex byte basis with configurable causal window superposition."""
    def __init__(self, dimension: int, window_length: int = 4, operator: str = "mean", normalization: str = "l2"):
        super().__init__()
        if dimension % 2: raise ValueError("spectrum dimension must be even")
        self.window_length, self.operator, self.normalization = window_length, operator, normalization
        # padding/BOS is a genuine zero contribution to a composed window.
        self.real, self.imag = nn.Embedding(257, dimension // 2, padding_idx=0), nn.Embedding(257, dimension // 2, padding_idx=0)
        self.metadata = RepresentationMetadata("learned-spectrum", "3", 256, dimension, "phase_rotation_window_composition")
    def encode(self, text: str) -> list[int]: return list(text.encode("utf-8"))
    def decode(self, ids: list[int]) -> str: return bytes(ids).decode("utf-8", errors="replace")
    def token_byte_lengths(self, text: str) -> list[int]: return [1] * len(text.encode("utf-8"))
    def causal_input_ids_bytes(self, raw: bytes, length: int | None = None) -> list[int]:
        return ByteFrontend.causal_input_ids_bytes(self, raw, length)
    def forward(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None) -> torch.Tensor:
        n = self.real.embedding_dim; positions = torch.arange(token_ids.size(1), device=token_ids.device)[None, :, None]; inv = 10_000.0 ** (-torch.arange(n, device=token_ids.device) / max(n, 1)); angle = positions * inv[None, None]
        real, imag = self.real(token_ids), self.imag(token_ids)
        vectors = torch.cat((real * angle.cos() - imag * angle.sin(), real * angle.sin() + imag * angle.cos()), -1)
        return compose_spectral_windows(vectors, self.window_length, self.operator, self.normalization)
    def checkpoint_config(self) -> dict: return {"metadata": asdict(self.metadata), "vocabulary": "utf8-bytes-0..255", "position": "phase_rotation_window_composition", "phase_base": 10_000.0, "window_length": self.window_length, "composition_operator": self.operator, "composition_normalization": self.normalization}


class OscillatorFrontend(_Frontend):
    """Oscillator bank with explicit fixed/partial/full learnability and frequencies in [0, pi]."""
    REGIMES = {"fixed", "partial", "learned"}
    def __init__(self, dimension: int, regime: str = "learned", window_length: int = 4, operator: str = "mean", normalization: str = "l2"):
        super().__init__()
        if dimension % 2: raise ValueError("oscillator dimension must be even")
        if regime not in self.REGIMES: raise ValueError(f"unknown oscillator regime {regime}")
        n = dimension // 2; self.regime, self.window_length, self.operator, self.normalization = regime, window_length, operator, normalization; self.amplitude, self.phase = nn.Embedding(257, n, padding_idx=0), nn.Embedding(257, n, padding_idx=0); self.raw_frequency = nn.Parameter(torch.linspace(-2.0, 2.0, n), requires_grad=regime == "learned")
        if regime == "fixed": self.amplitude.weight.requires_grad_(False); self.phase.weight.requires_grad_(False)
        elif regime == "partial": self.phase.weight.requires_grad_(False)
        self.metadata = RepresentationMetadata("constrained-oscillator", "2", 256, dimension, "oscillator_phase_only")
    @property
    def frequency(self) -> torch.Tensor: return math.pi * torch.sigmoid(self.raw_frequency)
    def encode(self, text: str) -> list[int]: return list(text.encode("utf-8"))
    def decode(self, ids: list[int]) -> str: return bytes(ids).decode("utf-8", errors="replace")
    def token_byte_lengths(self, text: str) -> list[int]: return [1] * len(text.encode("utf-8"))
    def causal_input_ids_bytes(self, raw: bytes, length: int | None = None) -> list[int]:
        return ByteFrontend.causal_input_ids_bytes(self, raw, length)
    def forward(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None) -> torch.Tensor:
        positions = torch.arange(token_ids.size(1), device=token_ids.device)[None, :, None]; amplitude = F.softplus(self.amplitude(token_ids)); angle = self.phase(token_ids) + positions * self.frequency[None, None]
        vectors = torch.cat((amplitude * angle.cos(), amplitude * angle.sin()), -1)
        vectors = vectors.masked_fill(token_ids[..., None].eq(0), 0.0)
        return compose_spectral_windows(vectors, self.window_length, self.operator, self.normalization)
    def checkpoint_config(self) -> dict: return {"metadata": asdict(self.metadata), "vocabulary": "utf8-bytes-0..255", "position": "oscillator_phase_window_composition", "frequency_constraint": "pi*sigmoid(raw_frequency)", "frequency_range": [0.0, math.pi], "regime": self.regime, "window_length": self.window_length, "composition_operator": self.operator, "composition_normalization": self.normalization, "learnable": {"amplitude": self.amplitude.weight.requires_grad, "phase": self.phase.weight.requires_grad, "frequency": self.raw_frequency.requires_grad}}


GLOBAL_POSITION_VARIANTS = (
    "local-only", "sine-only", "cosine-only", "tangent-only",
    "radial-raw", "radial-sqrt", "radial-log", "radial-bounded", "spiral",
    "multiphase-log", "multiphase-incommensurate",
    "rotation-global-local", "rotation-local-global", "quaternion-global-local",
)
RADIAL_BOUND_C = 1_024.0
MULTIPHASE_LOG_PERIODS = (32.0, 128.0, 512.0, 2_048.0)
MULTIPHASE_INCOMMENSURATE_PERIODS = (31.0, 127.0, 509.0, 2_039.0)


def normalized_document_phase(positions: torch.Tensor, lengths: torch.Tensor) -> torch.Tensor:
    """`2πp/(L-1)` in the original document coordinate; singleton docs map to zero."""
    if positions.shape != lengths.shape:
        raise ValueError("document positions and lengths must have the same shape")
    denominator = (lengths.to(dtype=torch.float64) - 1.0).clamp_min(1.0)
    phase = 2.0 * math.pi * positions.to(dtype=torch.float64) / denominator
    return torch.where(lengths.le(1), torch.zeros_like(phase), phase)


class GlobalPositionFrontend(_Frontend):
    """Spectral frontend with an explicit full-document position binding.

    Each candidate keeps the lexical basis and local window fixed.  The global
    signal is a deterministic, parameter-free binding so its information and
    numerical behavior can be screened without a capacity confound.
    """
    def __init__(self, dimension: int, variant: str, *, basis: Literal["learned-spectrum", "constrained-oscillator"] = "learned-spectrum", window_length: int = 4, operator: str = "mean", normalization: str = "l2"):
        super().__init__()
        if dimension < 4 or dimension % 2:
            raise ValueError("global spectral dimension must be even and at least four")
        if variant not in GLOBAL_POSITION_VARIANTS:
            raise ValueError(f"unknown global-position variant {variant!r}")
        if basis not in {"learned-spectrum", "constrained-oscillator"}:
            raise ValueError(f"unknown global-position basis {basis!r}")
        self.dimension, self.variant, self.basis = dimension, variant, basis
        self.window_length, self.operator, self.normalization = window_length, operator, normalization
        channels = dimension // 2
        if basis == "learned-spectrum":
            self.real, self.imag = nn.Embedding(257, channels, padding_idx=0), nn.Embedding(257, channels, padding_idx=0)
        else:
            self.amplitude, self.phase = nn.Embedding(257, channels, padding_idx=0), nn.Embedding(257, channels, padding_idx=0)
            self.raw_frequency = nn.Parameter(torch.linspace(-2.0, 2.0, channels), requires_grad=True)
        coordinates = torch.arange(1, dimension + 1, dtype=torch.float64)
        direction = F.normalize(torch.sin(coordinates * 1.61803398875), dim=0)
        phase_directions = torch.stack([F.normalize(torch.cos(coordinates * (index + 1.0)), dim=0) for index in range(4)])
        self.register_buffer("direction", direction.float(), persistent=False)
        self.register_buffer("phase_directions", phase_directions.float(), persistent=False)
        self.metadata = RepresentationMetadata(f"{basis}+{variant}", "1", 256, dimension, "local-window-plus-full-document-global-position")

    @property
    def frequency(self) -> torch.Tensor:
        if self.basis != "constrained-oscillator":
            raise AttributeError("learned-spectrum basis has no constrained oscillator frequency")
        return math.pi * torch.sigmoid(self.raw_frequency)

    def encode(self, text: str) -> list[int]: return list(text.encode("utf-8"))
    def decode(self, ids: list[int]) -> str: return bytes(ids).decode("utf-8", errors="replace")
    def token_byte_lengths(self, text: str) -> list[int]: return [1] * len(text.encode("utf-8"))
    def causal_input_ids_bytes(self, raw: bytes, length: int | None = None) -> list[int]: return ByteFrontend.causal_input_ids_bytes(self, raw, length)

    def _coordinates(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None, document_lengths: torch.Tensor | None) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        batch, time = token_ids.shape
        if document_positions is None:
            document_positions = torch.arange(time, device=token_ids.device).expand(batch, time)
        if document_lengths is None:
            document_lengths = torch.full_like(document_positions, time)
        if document_positions.shape != token_ids.shape or document_lengths.shape != token_ids.shape:
            raise ValueError("global-position metadata must align with frontend token IDs")
        phase = normalized_document_phase(document_positions, document_lengths).to(device=token_ids.device, dtype=self.direction.dtype)
        return document_positions.to(device=token_ids.device), document_lengths.to(device=token_ids.device), phase

    def _local_vectors(self, token_ids: torch.Tensor) -> torch.Tensor:
        channels = self.dimension // 2
        local = torch.arange(token_ids.size(1), device=token_ids.device, dtype=torch.get_default_dtype())[None, :, None]
        if self.basis == "learned-spectrum":
            inv = 10_000.0 ** (-torch.arange(channels, device=token_ids.device, dtype=torch.get_default_dtype()) / channels)
            angle = local * inv[None, None]
            real, imag = self.real(token_ids), self.imag(token_ids)
            return torch.cat((real * angle.cos() - imag * angle.sin(), real * angle.sin() + imag * angle.cos()), -1)
        amplitude = F.softplus(self.amplitude(token_ids))
        angle = self.phase(token_ids) + local * self.frequency.to(dtype=local.dtype)[None, None]
        return torch.cat((amplitude * angle.cos(), amplitude * angle.sin()), -1)

    def global_values(self, document_positions: torch.Tensor, document_lengths: torch.Tensor) -> torch.Tensor:
        """Expose the raw candidate signal for alias and precision diagnostics."""
        phase = normalized_document_phase(document_positions, document_lengths).to(device=document_positions.device, dtype=self.direction.dtype)
        progress = torch.where(document_lengths.gt(1), document_positions.to(phase.dtype) / (document_lengths.to(phase.dtype) - 1.0), torch.zeros_like(phase))
        if self.variant == "sine-only": return phase.sin()
        if self.variant == "cosine-only": return phase.cos()
        if self.variant == "tangent-only": return phase.tan()
        if self.variant == "radial-raw": return document_positions.to(phase.dtype)
        if self.variant == "radial-sqrt": return torch.sqrt(1.0 + document_positions.to(phase.dtype))
        if self.variant == "radial-log": return torch.log1p(document_positions.to(phase.dtype))
        if self.variant == "radial-bounded": return document_positions.to(phase.dtype) / (document_positions.to(phase.dtype) + RADIAL_BOUND_C)
        if self.variant == "spiral": return progress
        if self.variant == "multiphase-log":
            periods = torch.tensor(MULTIPHASE_LOG_PERIODS, device=phase.device, dtype=phase.dtype)
            return torch.sin(2.0 * math.pi * document_positions.to(phase.dtype)[..., None] / periods)
        if self.variant == "multiphase-incommensurate":
            periods = torch.tensor(MULTIPHASE_INCOMMENSURATE_PERIODS, device=phase.device, dtype=phase.dtype)
            return torch.sin(2.0 * math.pi * document_positions.to(phase.dtype)[..., None] / periods)
        return phase

    @staticmethod
    def _rotate3(vectors: torch.Tensor, angle: torch.Tensor, axis: torch.Tensor) -> torch.Tensor:
        usable = (vectors.size(-1) // 3) * 3
        if not usable: return vectors
        blocks = vectors[..., :usable].reshape(*vectors.shape[:-1], -1, 3)
        axis = axis.to(device=vectors.device, dtype=vectors.dtype); axis = axis / axis.norm()
        c, s = angle.to(dtype=vectors.dtype).cos()[..., None, None], angle.to(dtype=vectors.dtype).sin()[..., None, None]
        rotated = blocks * c + torch.cross(axis.expand_as(blocks), blocks, dim=-1) * s + axis * (blocks * axis).sum(-1, keepdim=True) * (1.0 - c)
        return torch.cat((rotated.reshape(*vectors.shape[:-1], usable), vectors[..., usable:]), -1)

    @staticmethod
    def _quaternion_rotate(vectors: torch.Tensor, local: torch.Tensor, global_: torch.Tensor) -> torch.Tensor:
        usable = (vectors.size(-1) // 3) * 3
        if not usable: return vectors
        blocks = vectors[..., :usable].reshape(*vectors.shape[:-1], -1, 3)
        def quaternion(angle: torch.Tensor, axis: tuple[float, float, float]) -> tuple[torch.Tensor, torch.Tensor]:
            scalar = (angle / 2.0).cos(); vector = (angle / 2.0).sin()[..., None] * torch.tensor(axis, device=angle.device, dtype=angle.dtype)
            return scalar, vector
        lw, lv = quaternion(local, (1.0, 0.0, 0.0)); gw, gv = quaternion(global_, (0.0, 0.0, 1.0))
        # q_global * q_local: the vector part records the deliberately noncommutative hierarchy.
        weight = gw * lw - (gv * lv).sum(-1); vector = gw[..., None] * lv + lw[..., None] * gv + torch.cross(gv, lv, dim=-1)
        rotated = blocks + 2.0 * torch.cross(vector[..., None, :].expand_as(blocks), torch.cross(vector[..., None, :].expand_as(blocks), blocks, dim=-1) + weight[..., None, None] * blocks, dim=-1)
        return torch.cat((rotated.reshape(*vectors.shape[:-1], usable), vectors[..., usable:]), -1)

    def _bind_global(self, vectors: torch.Tensor, positions: torch.Tensor, lengths: torch.Tensor, phase: torch.Tensor) -> torch.Tensor:
        values = self.global_values(positions, lengths)
        if self.variant == "local-only": return vectors
        if self.variant in {"sine-only", "cosine-only", "tangent-only", "radial-raw", "radial-sqrt", "radial-log", "radial-bounded"}:
            return vectors + values[..., None] * self.direction.to(dtype=vectors.dtype)
        if self.variant == "spiral":
            spiral_direction = phase.cos()[..., None] * self.phase_directions[0].to(dtype=vectors.dtype) + phase.sin()[..., None] * self.phase_directions[1].to(dtype=vectors.dtype)
            return vectors + values[..., None] * spiral_direction
        if self.variant.startswith("multiphase"):
            return vectors + torch.einsum("btk,kd->btd", values, self.phase_directions.to(dtype=vectors.dtype))
        local = 2.0 * math.pi * (torch.arange(vectors.size(1), device=vectors.device, dtype=vectors.dtype)[None, :] % self.window_length) / self.window_length
        if self.variant == "rotation-global-local": return self._rotate3(self._rotate3(vectors, local, torch.tensor((1.0, 0.0, 0.0))), phase, torch.tensor((0.0, 0.0, 1.0)))
        if self.variant == "rotation-local-global": return self._rotate3(self._rotate3(vectors, phase, torch.tensor((0.0, 0.0, 1.0))), local, torch.tensor((1.0, 0.0, 0.0)))
        return self._quaternion_rotate(vectors, local, phase)

    def forward(self, token_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None) -> torch.Tensor:
        positions, lengths, phase = self._coordinates(token_ids, document_positions, document_lengths)
        vectors = self._bind_global(self._local_vectors(token_ids), positions, lengths, phase)
        vectors = vectors.masked_fill(token_ids[..., None].eq(0), 0.0)
        return compose_spectral_windows(vectors, self.window_length, self.operator, self.normalization)

    def checkpoint_config(self) -> dict:
        period_bank = MULTIPHASE_LOG_PERIODS if self.variant == "multiphase-log" else MULTIPHASE_INCOMMENSURATE_PERIODS if self.variant == "multiphase-incommensurate" else None
        return {"metadata": asdict(self.metadata), "vocabulary": "utf8-bytes-0..255", "basis": self.basis, "global_position_variant": self.variant, "global_coordinate": "theta=2*pi*p/(L-1); L<=1=>0; full-document UTF-8 byte position", "window_length": self.window_length, "composition_operator": self.operator, "composition_normalization": self.normalization, "radial_bounded_c": RADIAL_BOUND_C if self.variant == "radial-bounded" else None, "multiphase_periods": period_bank, "rotation_order": self.variant if "rotation" in self.variant or "quaternion" in self.variant else None, "raw_tangent": self.variant == "tangent-only"}


class FrontendLM(nn.Module):
    """One causal decoder and one byte-level objective for every representation."""
    def __init__(self, frontend: _Frontend, dimension: int, heads: int = 2, layers: int = 1):
        super().__init__(); self.frontend, self.dimension, self.heads, self.layers = frontend, dimension, heads, layers; block = nn.TransformerEncoderLayer(dimension, heads, 4 * dimension, batch_first=True, dropout=0.0); self.decoder, self.head = nn.TransformerEncoder(block, layers), nn.Linear(dimension, 256)
    def model_config(self) -> dict: return {"dimension": self.dimension, "heads": self.heads, "layers": self.layers, "decoder": "TransformerEncoder(causal,dropout=0)"}
    def forward(self, input_ids: torch.Tensor, document_positions: torch.Tensor | None = None, document_lengths: torch.Tensor | None = None, frontend_features: torch.Tensor | None = None) -> torch.Tensor:
        time = input_ids.size(1); causal = torch.ones(time, time, device=input_ids.device, dtype=torch.bool).triu(1)
        states = frontend_features if frontend_features is not None else self.frontend(input_ids, document_positions=document_positions, document_lengths=document_lengths)
        if states.shape[:2] != input_ids.shape or states.size(-1) != self.dimension:
            raise ValueError("frontend features must be [batch, time, model_dimension]")
        return self.head(self.decoder(states, mask=causal))
    def loss_details(self, batch: TextBatch) -> dict[str, torch.Tensor]:
        nll = F.cross_entropy(self(batch.input_ids, document_positions=batch.document_positions, document_lengths=batch.document_lengths, frontend_features=batch.frontend_features).transpose(1, 2), batch.targets, reduction="none"); total = (nll * batch.valid).sum()
        return {"total_nll": total, "byte_count": torch.tensor(batch.byte_count, device=total.device), "normalized_byte_loss": total / batch.byte_count}
    def loss(self, batch: TextBatch) -> torch.Tensor: return self.loss_details(batch)["normalized_byte_loss"]
    @torch.no_grad()
    def generate_bytes(self, prefix: str | bytes, max_new_bytes: int = 12) -> bytes:
        raw = prefix.encode("utf-8") if isinstance(prefix, str) else bytes(prefix)
        for _ in range(max_new_bytes):
            ids = torch.tensor([self.frontend.causal_input_ids_bytes(raw, len(raw) + 1)], device=next(self.parameters()).device)
            raw += bytes([int(self(ids)[0, -1].argmax())])
        return raw
    @torch.no_grad()
    def generate(self, prefix: str | bytes, max_new_bytes: int = 12) -> str:
        return self.generate_bytes(prefix, max_new_bytes).decode("utf-8", errors="replace")


class NativeFrontendLM(FrontendLM):
    """Conventional native-token decoder for byte/character/BPE baselines."""
    def __init__(self, frontend: _Frontend, dimension: int, heads: int = 2, layers: int = 1):
        super().__init__(frontend, dimension, heads, layers)
        self.vocabulary_size = frontend.metadata.alphabet_size
        self.head = nn.Linear(dimension, self.vocabulary_size)
    def model_config(self) -> dict:
        return super().model_config() | {"objective": "native_next_token", "vocabulary_size": self.vocabulary_size}
    def loss_details(self, batch: TokenBatch) -> dict[str, torch.Tensor]:
        nll = F.cross_entropy(self(batch.input_ids).transpose(1, 2), batch.targets, reduction="none")
        total = (nll * batch.valid).sum()
        return {"total_nll": total, "byte_count": torch.tensor(batch.byte_count, device=total.device), "normalized_byte_loss": total / batch.byte_count}
    def loss(self, batch: TokenBatch) -> torch.Tensor: return self.loss_details(batch)["normalized_byte_loss"]
    @torch.no_grad()
    def generate_native(self, prefix: str, max_new_tokens: int = 12) -> str:
        tokens = self.frontend.encode(prefix)
        for _ in range(max_new_tokens):
            inputs = [0] + [token + 1 for token in tokens]
            next_token = int(self(torch.tensor([inputs], device=next(self.parameters()).device))[0, -1].argmax())
            tokens.append(next_token)
        try: return self.frontend.decode(tokens)
        except UnicodeDecodeError:
            # BPE can emit an incomplete UTF-8 suffix; preserve raw bytes and
            # decode only for display instead of aborting qualitative evidence.
            if isinstance(self.frontend, BPEFrontend):
                raw = bytes(byte for token in tokens for byte in self.frontend._expand(token))
                return raw.decode("utf-8", errors="replace")
            raise


@dataclass(frozen=True)
class RunManifest:
    run_id: str; seed: int; dataset_hash: str; split_hash: str; split_membership: dict; representation: dict; model: dict; optimizer: dict; precision: str; git_commit: str; torch_version: str; platform: str; device: str; hardware: dict; package_versions: dict; artifacts: dict; training_steps: int | None = None; checkpoint_receipt: dict | None = None
    def save(self, path: Path) -> None: path.write_text(json.dumps(asdict(self), sort_keys=True, indent=2))
    @classmethod
    def load(cls, path: Path) -> "RunManifest": return cls(**json.loads(path.read_text()))


def git_commit() -> str:
    """Return the source commit, including connector-published checkouts.

    Some controlled runners receive a source snapshot without its .git
    directory.  They must bind artifacts to the immutable commit published by
    the connector rather than silently emitting the non-auditable
    "unavailable" sentinel.  Accept only a full Git object ID so a label or
    truncated revision cannot be mistaken for provenance.
    """
    override = os.environ.get("DOMAIN_SCALING_LAB_SOURCE_COMMIT")
    if override is not None:
        normalized = override.strip().lower()
        if len(normalized) != 40 or any(character not in "0123456789abcdef" for character in normalized):
            raise ValueError("DOMAIN_SCALING_LAB_SOURCE_COMMIT must be a full 40-character hexadecimal Git commit")
        return normalized
    try: return subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    except (OSError, subprocess.CalledProcessError): return "unavailable"
def runtime_provenance(device: str = "cpu") -> dict:
    packages = {name: importlib.metadata.version(name) for name in ("torch", "pytest") if importlib.metadata.packages_distributions().get(name)}
    return {"platform": platform.platform(), "device": device, "hardware": {"processor": platform.processor(), "machine": platform.machine(), "cuda": torch.cuda.get_device_name(0) if device.startswith("cuda") and torch.cuda.is_available() else None}, "package_versions": packages}


@dataclass(frozen=True)
class FrozenSplit:
    train: list[str]; validation: list[str]; test: list[str]; dataset_hash: str; split_hash: str; boundaries: dict
    def manifest(self) -> dict: return asdict(self)
def frozen_split(texts: list[str], split_seed: int = 17) -> FrozenSplit:
    if len(texts) < 3: raise ValueError("a frozen train/validation/test split needs at least three texts")
    dataset_hash = sha256(json.dumps(sorted(texts), ensure_ascii=False).encode()).hexdigest(); ordered = sorted(texts, key=lambda text: sha256(f"{split_seed}:{text}".encode()).hexdigest()); n = len(ordered); train_end = max(1, int(.70 * n)); validation_end = min(max(train_end + 1, int(.85 * n)), n - 1)
    membership = {"split_seed": split_seed, "train": ordered[:train_end], "validation": ordered[train_end:validation_end], "test": ordered[validation_end:], "boundaries": {"train_end": train_end, "validation_end": validation_end, "total": n}}
    split_hash = sha256(json.dumps(membership, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    return FrozenSplit(membership["train"], membership["validation"], membership["test"], dataset_hash, split_hash, membership["boundaries"])


def _edit(text: str, kind: str, value: str, location: int) -> dict: return {"text": value, "type": kind, "location": location, "edit_distance": 1, "source": text}
def perturb(text: str) -> dict[str, dict]:
    """One-edit suite retaining source context, including morphology/code/Unicode cases."""
    point = max(0, len(text) // 2); char = text[point:point + 1] or "x"; word_start = max(text.rfind(" ", 0, point) + 1, 0); word_end = text.find(" ", point); word_end = len(text) if word_end < 0 else word_end
    return {"substitution": _edit(text, "substitution", text[:point] + ("x" if char != "x" else "y") + text[point + 1:], point), "insertion": _edit(text, "insertion", text[:point] + "_" + text[point:], point), "deletion": _edit(text, "deletion", text[:point] + text[point + 1:], point), "transpose": _edit(text, "transpose", text[:point] + text[point + 1:point + 2] + char + text[point + 2:], point), "morphology": _edit(text, "morphology", text + "s", len(text)), "iid_case": _edit(text, "iid_case", text[:point] + char.swapcase() + text[point + 1:], point), "unicode": _edit(text, "unicode", text[:point] + "Δ" + text[point + 1:], point), "identifier": _edit(text, "identifier", text[:word_start] + "identifier_42" + text[word_end:], word_start), "rare": _edit(text, "rare", text[:point] + "Ω" + text[point + 1:], point)}


def _representation_vectors(frontend: _Frontend, text: str, limit: int | None = None) -> torch.Tensor:
    """Encode a bounded causal prefix for diagnostics without materializing a corpus row."""
    ids = frontend.causal_input_ids(text)
    if limit is not None:
        ids = ids[:limit]
    return frontend(torch.tensor([ids], dtype=torch.long))[0]


def _linear_probe(train_x: torch.Tensor, train_y: torch.Tensor, eval_x: torch.Tensor, eval_y: torch.Tensor, classes: int) -> float:
    """Fit on disjoint examples; unlike self-nearest-neighbour this can fail."""
    if not len(train_x) or not len(eval_x) or classes < 2: return float("nan")
    one_hot = F.one_hot(train_y, classes).float()
    design = torch.cat((train_x, torch.ones(len(train_x), 1)), dim=1)
    # A fixed ridge solve is deterministic even when this tiny probe design is
    # rank-deficient; least-squares driver choices otherwise vary across runs.
    gram = design.T @ design + 1e-4 * torch.eye(design.size(1), device=design.device)
    weights = torch.linalg.solve(gram, design.T @ one_hot)
    heldout = torch.cat((eval_x, torch.ones(len(eval_x), 1)), dim=1) @ weights
    return float(heldout.argmax(-1).eq(eval_y).float().mean())


def _probe_data(frontend: _Frontend, texts: list[str], max_position: int, *, offset: int = 0, heldout_fold: int = 0, folds: int = 2) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, dict]:
    """Create source-disjoint recovery examples from composed window states."""
    features, labels, source = [], [], []
    for source_id, text in enumerate(texts):
        ids = torch.tensor(frontend.causal_input_ids(text), dtype=torch.long)
        vectors = frontend(ids[None])[0]
        for position in range(offset, len(ids)):
            target = int(ids[position - offset])
            if target: features.append(vectors[position].detach()); labels.append(target); source.append(source_id)
    if not features: return (torch.empty(0, 1), torch.empty(0, dtype=torch.long), torch.empty(0, 1), torch.empty(0, dtype=torch.long), {"train_sources": 0, "evaluation_sources": 0, "train_examples": 0, "evaluation_examples": 0, "classes": 0, "chance_accuracy": float("nan")})
    x, y, source_ids = torch.stack(features), torch.tensor(labels), torch.tensor(source)
    values = sorted(set(y.tolist())); remap = {value: index for index, value in enumerate(values)}; y = torch.tensor([remap[int(value)] for value in y])
    # Hold out complete source documents, never random windows from the same row.
    heldout = source_ids.remainder(folds).eq(heldout_fold); train = ~heldout
    support = {"train_sources": len(set(source_ids[train].tolist())), "evaluation_sources": len(set(source_ids[heldout].tolist())), "train_examples": int(train.sum()), "evaluation_examples": int(heldout.sum()), "classes": len(values), "chance_accuracy": 1.0 / max(len(values), 1)}
    return x[train], y[train], x[heldout], y[heldout], support


def representation_diagnostics(frontend: _Frontend, texts: list[str], window: int = 12, folds: int = 5) -> dict:
    if len(texts) < 4: raise ValueError("diagnostics require at least four source texts for source-level validation")
    source_folds = min(folds, len(texts))
    diagnostic_limit = window + getattr(frontend, "window_length", 1)
    rows = [_representation_vectors(frontend, text, diagnostic_limit)[:window] for text in texts]
    z = torch.cat(rows, dim=0).detach(); norms = z.norm(dim=-1); distances = torch.cdist(z, z)
    off_diagonal = ~torch.eye(len(z), dtype=torch.bool); collisions = distances.lt(1e-6) & off_diagonal
    composition_window = getattr(frontend, "window_length", 1)
    recoveries, probe_support = [], []
    for offset in range(composition_window):
        scores, offset_support = [], []
        for fold in range(source_folds):
            train_x, train_y, eval_x, eval_y, support = _probe_data(frontend, texts, window, offset=offset, heldout_fold=fold, folds=source_folds)
            score = _linear_probe(train_x, train_y, eval_x, eval_y, int(torch.cat((train_y, eval_y)).max()) + 1) if len(train_y) and len(eval_y) else float("nan")
            support |= {"fold": fold, "accuracy": score}; offset_support.append(support)
            if not math.isnan(score): scores.append(score)
        recoveries.append(sum(scores) / len(scores) if scores else float("nan"))
        probe_support.append({"offset": offset, "folds": offset_support, "chance_accuracy": mean(item["chance_accuracy"] for item in offset_support if not math.isnan(item["chance_accuracy"]))})
    valid_recoveries = [score for score in recoveries if not math.isnan(score)]
    local_recoverability = sum(valid_recoveries) / max(len(valid_recoveries), 1)
    # The oldest component is the one most exposed to superposition interference.
    interference_error = 1.0 - (valid_recoveries[-1] if valid_recoveries else 0.0)
    position_features, position_labels, source = [], [], []
    for source_id, text in enumerate(texts):
        vectors = _representation_vectors(frontend, text, diagnostic_limit)[:window].detach()
        position_features.extend(vectors); position_labels.extend(range(len(vectors))); source.extend([source_id] * len(vectors))
    px, py, ps = torch.stack(position_features), torch.tensor(position_labels), torch.tensor(source)
    positional_scores, position_support = [], []
    for fold in range(source_folds):
        heldout, train = ps.remainder(source_folds).eq(fold), ps.remainder(source_folds).ne(fold)
        score = _linear_probe(px[train], py[train], px[heldout], py[heldout], int(py.max()) + 1)
        position_support.append({"fold": fold, "train_sources": len(set(ps[train].tolist())), "evaluation_sources": len(set(ps[heldout].tolist())), "train_examples": int(train.sum()), "evaluation_examples": int(heldout.sum()), "classes": int(py.max()) + 1, "chance_accuracy": 1.0 / (int(py.max()) + 1), "accuracy": score})
        if not math.isnan(score): positional_scores.append(score)
    positional_recoverability = sum(positional_scores) / max(len(positional_scores), 1)
    continuity, unrelated = [], []
    base_means = [_representation_vectors(frontend, text, diagnostic_limit).mean(0).detach() for text in texts]
    for index, text in enumerate(texts):
        for item in perturb(text).values():
            continuity.append(float((base_means[index] - _representation_vectors(frontend, item["text"], diagnostic_limit).mean(0).detach()).norm() / item["edit_distance"]))
        unrelated.extend(float((base_means[index] - other).norm()) for other_index, other in enumerate(base_means) if other_index != index)
    edit_drift = sum(continuity) / max(len(continuity), 1); edit_drift_ratio = edit_drift / max(sum(unrelated) / max(len(unrelated), 1), 1e-12)
    # A chance-calibrated minimum and relative edit criterion can meaningfully fail.
    class_count = max(2, len({token for text in texts for token in frontend.encode(text[:window * 4])}))
    local_chance = max(item["chance_accuracy"] for item in probe_support)
    position_chance = max(item["chance_accuracy"] for item in position_support)
    thresholds = {"finite": 1.0, "collision_rate_max": 0.10, "local_recoverability_min": max(2.0 / class_count, 2.0 * local_chance), "positional_recoverability_min": max(2.0 / max(2, min(window, max(len(row) for row in rows))), 2.0 * position_chance), "interference_error_max": 0.90, "edit_drift_ratio_max": 1.0, "position_variance_min": 1e-4}
    result: dict[str, float | list | dict] = {"collision_rate": float(collisions[off_diagonal].float().mean()), "effective_rank": float(torch.linalg.matrix_rank(z)), "finite": float(torch.isfinite(z).all()), "position_variance": float(z.var(dim=0).mean()), "local_recoverability": local_recoverability, "window_recoverability": recoveries, "positional_recoverability": positional_recoverability, "superposition_interference_error": interference_error, "edit_continuity_mean": edit_drift, "edit_drift_ratio": edit_drift_ratio, "min_vector_norm": float(norms.min()), "source_folds": source_folds, "probe_support": {"window_offsets": probe_support, "position": position_support}, "thresholds": thresholds}
    result["threshold_pass"] = {"finite": result["finite"] >= thresholds["finite"], "collision_rate": result["collision_rate"] <= thresholds["collision_rate_max"], "local_recoverability": result["local_recoverability"] >= thresholds["local_recoverability_min"], "positional_recoverability": result["positional_recoverability"] >= thresholds["positional_recoverability_min"], "interference_error": result["superposition_interference_error"] <= thresholds["interference_error_max"], "edit_continuity": result["edit_drift_ratio"] <= thresholds["edit_drift_ratio_max"], "position_variance": result["position_variance"] >= thresholds["position_variance_min"]}
    if isinstance(frontend, OscillatorFrontend): result.update({"frequency_min": float(frontend.frequency.min().detach()), "frequency_max": float(frontend.frequency.max().detach()), "frequency_mean": float(frontend.frequency.mean().detach()), "phase_mean": float(frontend.phase.weight.mean().detach()), "phase_std": float(frontend.phase.weight.std().detach()), "amplitude_mean": float(F.softplus(frontend.amplitude.weight).mean().detach())})
    return result


def _source_disjoint_probe(features: torch.Tensor, labels: torch.Tensor, sources: torch.Tensor, folds: int = 4) -> dict:
    """Linear probe summary with whole documents held out at every fold."""
    source_folds = min(folds, len(set(sources.tolist())))
    if len(features) == 0 or len(set(labels.tolist())) < 2:
        return {"accuracy": float("nan"), "chance_accuracy": float("nan"), "folds": [], "source_folds": source_folds}
    # Joint symbol/local/global labels are intentionally sparse.  Compact
    # their observed values before one-hot encoding, otherwise a single
    # high-valued byte label turns a small deterministic probe into a huge
    # mostly-empty classifier matrix.
    _, labels = torch.unique(labels, sorted=True, return_inverse=True)
    classes = int(labels.max()) + 1
    scores, support = [], []
    for fold in range(source_folds):
        heldout = sources.remainder(source_folds).eq(fold); train = ~heldout
        score = _linear_probe(features[train], labels[train], features[heldout], labels[heldout], classes) if train.any() and heldout.any() else float("nan")
        support.append({"fold": fold, "train_documents": len(set(sources[train].tolist())), "evaluation_documents": len(set(sources[heldout].tolist())), "train_examples": int(train.sum()), "evaluation_examples": int(heldout.sum()), "accuracy": score})
        if not math.isnan(score): scores.append(score)
    return {"accuracy": sum(scores) / len(scores) if scores else float("nan"), "chance_accuracy": 1.0 / classes, "folds": support, "source_folds": source_folds}


def _position_alias_metrics(frontend: GlobalPositionFrontend, length: int, maximum_samples: int = 1_024) -> dict:
    sample_count = min(length, maximum_samples)
    positions = torch.linspace(0, max(length - 1, 0), sample_count, dtype=torch.float64).round().to(torch.long)[None]
    lengths = torch.full_like(positions, length)
    values = frontend.global_values(positions, lengths).reshape(sample_count, -1).detach().double()
    finite = torch.isfinite(values).all(-1)
    if finite.any():
        usable = values[finite]; distances = torch.cdist(usable, usable); off_diagonal = ~torch.eye(len(usable), dtype=torch.bool)
        collisions = distances.lt(1e-8) & off_diagonal
        collision_rate = float(collisions[off_diagonal].float().mean()) if len(usable) > 1 else 0.0
    else:
        collision_rate = 1.0
    magnitude = values.abs()
    return {"length": length, "sample_count": sample_count, "collision_rate": collision_rate, "finite_fraction": float(finite.float().mean()), "max_abs": float(torch.nan_to_num(magnitude, nan=float("inf"), posinf=float("inf")).max()), "extreme_fraction": float((magnitude.gt(1e4) | ~torch.isfinite(values)).any(-1).float().mean())}


def _pearson(x: torch.Tensor, y: torch.Tensor) -> float:
    x, y = x.float(), y.float()
    if len(x) < 2 or float(x.std()) == 0.0 or float(y.std()) == 0.0: return 0.0
    return float(torch.corrcoef(torch.stack((x, y)))[0, 1])


def _sample_document_segments(document: DocumentText, maximum_bytes: int, spans: int = 4) -> list[DocumentText]:
    """Select UTF-8-safe prefix/middle/end spans without changing source coordinates."""
    raw = document.text.encode("utf-8")
    if not raw: return []
    boundaries = [0]
    offset = 0
    for character in document.text:
        offset += len(character.encode("utf-8")); boundaries.append(offset)
    span_count = min(spans, max(1, len(raw) // 8))
    budget = max(1, maximum_bytes // span_count)
    latest_start = max(0, len(raw) - budget)
    starts = sorted({min(latest_start, round(index * latest_start / max(span_count - 1, 1))) for index in range(span_count)})
    output = []
    for requested in starts:
        start = boundaries[bisect_right(boundaries, requested) - 1]
        end = boundaries[bisect_right(boundaries, min(len(raw), start + budget)) - 1]
        if end > start:
            output.append(DocumentText(raw[start:end].decode("utf-8"), document.document_id, document.byte_offset + start, document.document_length))
    return output


def global_position_diagnostics(frontend: GlobalPositionFrontend, documents: Sequence[DocumentText], *, global_bins: int = 8, training_max_length: int | None = None, max_bytes_per_document: int = 128) -> dict:
    """Screen global-position candidates on source-disjoint, long-document probes.

    This diagnostic intentionally measures the global binding separately from
    language-model loss. It also exposes raw tangent failure modes instead of
    filtering or bounding them.
    """
    if len(documents) < 4: raise ValueError("global-position diagnostics require four source documents")
    features, symbols, local_offsets, global_labels, joints, sources, all_positions, norms, raw_norms = [], [], [], [], [], [], [], [], []
    for source_index, document in enumerate(documents):
        for diagnostic_document in _sample_document_segments(document, max_bytes_per_document):
            raw = diagnostic_document.text.encode("utf-8")
            batch = frontend.batch_documents([diagnostic_document])
            vectors = frontend(batch.input_ids, batch.document_positions, batch.document_lengths)[0].detach()
            positions, lengths, phase = frontend._coordinates(batch.input_ids, batch.document_positions, batch.document_lengths)
            uncomposed = frontend._bind_global(frontend._local_vectors(batch.input_ids), positions, lengths, phase)[0].detach()
            width = min(len(raw), vectors.size(0))
            for index in range(width):
                position, length = int(batch.document_positions[0, index]), int(batch.document_lengths[0, index])
                symbol = int(raw[index]); local = index % frontend.window_length; global_bin = min(global_bins - 1, int(global_bins * position / max(length, 1)))
                features.append(vectors[index]); symbols.append(symbol); local_offsets.append(local); global_labels.append(global_bin); joints.append((symbol * frontend.window_length + local) * global_bins + global_bin); sources.append(source_index); all_positions.append(position); norms.append(float(vectors[index].norm())); raw_norms.append(float(uncomposed[index].norm()))
    x, source_ids = torch.stack(features), torch.tensor(sources)
    symbol_probe = _source_disjoint_probe(x, torch.tensor(symbols), source_ids)
    chunk_phase_probe = _source_disjoint_probe(x, torch.tensor(local_offsets), source_ids)
    # The established local-window diagnostic probes recoverability of each
    # causal superposition offset, rather than treating chunk phase alone as
    # the local-position target. Keep that scientific control as the gate.
    local_reference = representation_diagnostics(frontend, [document.text for document in documents])
    local_probe = {"accuracy": local_reference["local_recoverability"], "chance_accuracy": max(item["chance_accuracy"] for item in local_reference["probe_support"]["window_offsets"]), "folds": local_reference["probe_support"]["window_offsets"], "source_folds": local_reference["source_folds"], "reference_threshold_pass": local_reference["threshold_pass"]["local_recoverability"]}
    global_probe = _source_disjoint_probe(x, torch.tensor(global_labels), source_ids)
    joint_probe = _source_disjoint_probe(x, torch.tensor(joints), source_ids)
    training_max_length = training_max_length or max(document.document_length for document in documents)
    alias_by_length = [_position_alias_metrics(frontend, length) for length in (max(32, training_max_length), max(64, training_max_length * 2))]
    repeated_length = max(32, training_max_length)
    repeated_positions = torch.linspace(0, repeated_length - 1, min(256, repeated_length), dtype=torch.float64).round().to(torch.long)[None]
    repeated_ids = torch.full_like(repeated_positions, ord("a") + 1)
    repeated_lengths = torch.full_like(repeated_positions, repeated_length)
    repeated_vectors = frontend(repeated_ids, repeated_positions, repeated_lengths)[0].detach()
    distances = torch.cdist(repeated_vectors, repeated_vectors)
    index = torch.arange(len(repeated_vectors)); separation = (index[:, None] - index[None, :]).abs()
    near = distances[(separation.gt(0)) & separation.le(2)]; far = distances[separation.ge(max(8, len(repeated_vectors) // 2))]
    copied = __import__("copy").deepcopy(frontend).double()
    double_vectors = copied(repeated_ids, repeated_positions, repeated_lengths).float().detach()
    fp_error = float((repeated_vectors - double_vectors).abs().max())
    rotation_order_sensitivity = 0.0
    norm_preservation_error = None
    if frontend.variant in {"rotation-global-local", "rotation-local-global", "quaternion-global-local"}:
        positions, lengths, phase = frontend._coordinates(repeated_ids, repeated_positions, repeated_lengths)
        base = frontend._local_vectors(repeated_ids)
        local = 2.0 * math.pi * (torch.arange(base.size(1), device=base.device, dtype=base.dtype)[None, :] % frontend.window_length) / frontend.window_length
        global_then_local = frontend._rotate3(frontend._rotate3(base, phase, torch.tensor((0.0, 0.0, 1.0))), local, torch.tensor((1.0, 0.0, 0.0)))
        local_then_global = frontend._rotate3(frontend._rotate3(base, local, torch.tensor((1.0, 0.0, 0.0))), phase, torch.tensor((0.0, 0.0, 1.0)))
        rotation_order_sensitivity = float((global_then_local - local_then_global).norm(dim=-1).mean().detach())
        bound = frontend._bind_global(base, positions, lengths, phase)
        norm_preservation_error = float((base.norm(dim=-1) - bound.norm(dim=-1)).abs().max().detach())
    period_bank = MULTIPHASE_LOG_PERIODS if frontend.variant == "multiphase-log" else MULTIPHASE_INCOMMENSURATE_PERIODS if frontend.variant == "multiphase-incommensurate" else None
    effective_alias_period = math.lcm(*(int(period) for period in period_bank)) if period_bank else None
    thresholds = {"finite_fraction_min": 1.0, "symbol_recoverability_min": 2.0 * symbol_probe["chance_accuracy"], "local_offset_recoverability_min": 2.0 * local_probe["chance_accuracy"], "global_position_recoverability_min": 1.25 * global_probe["chance_accuracy"], "joint_recoverability_min": 1.1 * joint_probe["chance_accuracy"], "alias_rate_max": 0.10, "extreme_value_fraction_max": 0.0, "fp32_fp64_max_abs_error": 1e-3}
    latest_alias = alias_by_length[-1]
    passes = {"finite": latest_alias["finite_fraction"] >= thresholds["finite_fraction_min"], "symbol": symbol_probe["accuracy"] >= thresholds["symbol_recoverability_min"], "local": local_probe["reference_threshold_pass"] and local_probe["accuracy"] >= thresholds["local_offset_recoverability_min"], "global": global_probe["accuracy"] >= thresholds["global_position_recoverability_min"], "joint": joint_probe["accuracy"] >= thresholds["joint_recoverability_min"], "alias": latest_alias["collision_rate"] <= thresholds["alias_rate_max"], "extremes": latest_alias["extreme_fraction"] <= thresholds["extreme_value_fraction_max"], "precision": fp_error <= thresholds["fp32_fp64_max_abs_error"]}
    phase_symmetry = None
    if frontend.variant in {"sine-only", "cosine-only", "tangent-only"}:
        # Use an odd length so half-cycle partners have exact byte positions.
        probe_length = max(33, training_max_length | 1)
        probe_positions = torch.arange((probe_length - 1) // 2 + 1)[None]
        if frontend.variant == "sine-only":
            mirrored = (probe_length - 1) // 2 - probe_positions
            symmetry = "sin(theta)=sin(pi-theta)"
        elif frontend.variant == "cosine-only":
            mirrored = probe_length - 1 - probe_positions
            symmetry = "cos(theta)=cos(2*pi-theta)"
        else:
            mirrored = (probe_positions + (probe_length - 1) // 2) % (probe_length - 1)
            symmetry = "tan(theta)=tan(theta+pi)"
        probe_lengths = torch.full_like(probe_positions, probe_length)
        phase_symmetry = {"identity": symmetry, "alias_partner_max_abs_difference": float((frontend.global_values(probe_positions, probe_lengths) - frontend.global_values(mirrored, probe_lengths)).abs().nan_to_num(posinf=float("inf")).max()), "declared_period": "2*pi" if frontend.variant != "tangent-only" else "pi"}
    radial_growth = None
    if frontend.variant.startswith("radial") or frontend.variant == "spiral":
        samples = torch.tensor([[0, training_max_length, training_max_length * 2, training_max_length * 16]], dtype=torch.long)
        sample_lengths = torch.full_like(samples, max(2, training_max_length * 16 + 1))
        radial_growth = {"positions": samples.flatten().tolist(), "values": frontend.global_values(samples, sample_lengths).detach().flatten().tolist(), "precomposition_norm_position_correlation": _pearson(torch.tensor(raw_norms), torch.tensor(all_positions)), "postcomposition_norm_position_correlation": _pearson(torch.tensor(norms), torch.tensor(all_positions))}
    tangent_behavior = None
    if frontend.variant == "tangent-only":
        probe_length = max(32, training_max_length)
        probe_positions = torch.arange(probe_length)[None]
        probe_lengths = torch.full_like(probe_positions, probe_length)
        phase = normalized_document_phase(probe_positions, probe_lengths)
        derivative = phase.cos().pow(-2)
        values = frontend.global_values(probe_positions, probe_lengths)
        edges = [round(index * probe_length / 4) for index in range(5)]
        tangent_behavior = latest_alias | {
            "max_phase_derivative": float(derivative.max()),
            "gradient_spike_fraction": float(derivative.gt(1e4).float().mean()),
            "quartile_max_abs": [float(values[:, edges[index]:edges[index + 1]].abs().max()) for index in range(4)],
        }
    return {"symbol_recoverability": symbol_probe, "local_window_offset_recoverability": local_probe, "chunk_phase_offset_recoverability": chunk_phase_probe, "global_position_bin_recoverability": global_probe, "joint_symbol_local_global_recoverability": joint_probe, "global_local_interaction": {"joint_to_factorized_accuracy_ratio": joint_probe["accuracy"] / max(symbol_probe["accuracy"] * local_probe["accuracy"] * global_probe["accuracy"], 1e-12), "local_control_threshold_pass": local_probe["reference_threshold_pass"]}, "alias_by_document_length": alias_by_length, "near_position_distance": float(near.mean()) if len(near) else 0.0, "far_position_distance": float(far.mean()) if len(far) else 0.0, "norm_position_correlation": _pearson(torch.tensor(norms), torch.tensor(all_positions)), "extrapolation_length": max(64, training_max_length * 2), "fp32_fp64_max_abs_error": fp_error, "rotation_order_sensitivity": rotation_order_sensitivity, "norm_preservation_error": norm_preservation_error, "effective_combined_alias_period": effective_alias_period, "single_function_phase_symmetry": phase_symmetry, "radial_scaling": radial_growth, "tangent_raw_behavior": tangent_behavior, "thresholds": thresholds, "threshold_pass": passes, "screen_eligible": all(passes.values())}


def normalized_byte_loss(total_nll: float | torch.Tensor, original_utf8_bytes: int) -> float | torch.Tensor:
    if original_utf8_bytes <= 0: raise ValueError("normalization requires at least one original UTF-8 byte")
    return total_nll / original_utf8_bytes


CHECKPOINT_FORMAT = "spectral-gate-a-checkpoint/v2"
CHECKPOINT_RECEIPT_SCHEMA = "gate-a-checkpoint-receipt/v1"


def _canonical_json_hash(value: Any) -> str:
    """Digest protocol values with one stable, language-independent encoding."""
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def tensor_state_fingerprint(value: torch.Tensor) -> str:
    """Fingerprint a tensor's shape, dtype, and exact CPU values."""
    detached = value.detach().cpu().contiguous()
    digest = sha256()
    digest.update(str(tuple(detached.shape)).encode("ascii"))
    digest.update(str(detached.dtype).encode("ascii"))
    digest.update(detached.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def module_state_fingerprint(module: nn.Module) -> str:
    """One state identity for any trainable/frozen module."""
    digest = sha256()
    for name, value in sorted(module.state_dict().items()):
        digest.update(name.encode("utf-8"))
        digest.update(tensor_state_fingerprint(value).encode("ascii"))
    return digest.hexdigest()


def decoder_head_state_fingerprint(model: FrontendLM) -> str:
    """One SHA-256 identity for the entire fixed downstream decoder path."""
    return _canonical_json_hash({
        "decoder": module_state_fingerprint(model.decoder),
        "head": module_state_fingerprint(model.head),
    })


def checkpoint_state_fingerprints(model: FrontendLM) -> dict[str, str]:
    """State identities recorded inside a Gate-A checkpoint envelope."""
    return {
        "frontend_state_fingerprint": module_state_fingerprint(model.frontend),
        "decoder_state_fingerprint": decoder_head_state_fingerprint(model),
        "model_state_fingerprint": module_state_fingerprint(model),
    }


def dataset_manifest_hash(dataset_manifest: Mapping[str, Any]) -> str:
    """Derive the frozen corpus identity from a checkpoint membership envelope.

    Gate-A checkpoints carry the full selection-membership object.  When it
    wraps a public dataset manifest, use that manifest's precomputed digest so
    downstream receiver work can bind directly to the same immutable corpus.
    Other callers retain a deterministic hash of the supplied envelope.
    """
    nested = dataset_manifest.get("dataset_manifest")
    if isinstance(nested, Mapping) and isinstance(nested.get("manifest_hash"), str):
        return nested["manifest_hash"]
    return _canonical_json_hash(dict(dataset_manifest))


def checkpoint_config_hash(
    *,
    format: str,
    dataset_manifest: Mapping[str, Any],
    representation: Mapping[str, Any],
    model_config: Mapping[str, Any],
) -> str:
    """Hash exactly the non-weight compatibility contract of a checkpoint."""
    return _canonical_json_hash({
        "format": format,
        "dataset_manifest": dict(dataset_manifest),
        "representation": dict(representation),
        "model_config": dict(model_config),
    })


def checkpoint_envelope(
    model: FrontendLM,
    dataset_manifest: dict,
    software_version: str = "domain-scaling-lab",
) -> dict:
    """Create a self-describing Gate-A checkpoint with state provenance.

    The file hash belongs in the surrounding RunManifest receipt because it
    cannot be placed inside the file without self-reference.  The envelope
    still carries every non-file identity needed to prove that a loaded model
    matches that receipt.
    """
    representation = model.frontend.checkpoint_config()
    model_config = model.model_config()
    envelope = {
        "format": CHECKPOINT_FORMAT,
        "representation": representation,
        "dataset_manifest": dataset_manifest,
        "dataset_manifest_hash": dataset_manifest_hash(dataset_manifest),
        "model_config": model_config,
        "software_version": software_version,
        # ``torch.__version__`` is a TorchVersion subclass in recent PyTorch
        # releases.  Persist the primitive string so decision-bound envelopes
        # remain loadable with ``weights_only=True`` without allowlisting a
        # pickle global.
        "torch_version": str(torch.__version__),
        "state_fingerprints": checkpoint_state_fingerprints(model),
        "state_dict": model.state_dict(),
    }
    envelope["checkpoint_config_hash"] = checkpoint_config_hash(
        format=envelope["format"],
        dataset_manifest=dataset_manifest,
        representation=representation,
        model_config=model_config,
    )
    return envelope


def _is_sha256(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(character in "0123456789abcdef" for character in value.lower())


def _require_checkpoint_envelope_provenance(
    checkpoint: Mapping[str, Any],
    model: FrontendLM,
    dataset_manifest: Mapping[str, Any],
) -> None:
    """Verify envelope fingerprints/config after its state has been loaded."""
    expected_config_hash = checkpoint_config_hash(
        format=checkpoint.get("format"),
        dataset_manifest=checkpoint.get("dataset_manifest", {}),
        representation=checkpoint.get("representation", {}),
        model_config=checkpoint.get("model_config", {}),
    )
    if checkpoint.get("checkpoint_config_hash") != expected_config_hash:
        raise ValueError("checkpoint compatibility-contract hash does not match its envelope")
    if checkpoint.get("dataset_manifest_hash") != dataset_manifest_hash(dataset_manifest):
        raise ValueError("checkpoint dataset manifest hash does not match frozen membership")
    expected_fingerprints = checkpoint_state_fingerprints(model)
    fingerprints = checkpoint.get("state_fingerprints")
    if not isinstance(fingerprints, Mapping) or any(
        fingerprints.get(name) != value
        for name, value in expected_fingerprints.items()
    ):
        raise ValueError("checkpoint state fingerprints do not match loaded model")


def checkpoint_receipt(
    path: Path,
    *,
    envelope: Mapping[str, Any],
    path_reference: str | None = None,
) -> dict[str, Any]:
    """Return the hash-bound RunManifest receipt for one checkpoint file."""
    fingerprints = envelope.get("state_fingerprints")
    if not isinstance(fingerprints, Mapping):
        raise ValueError("checkpoint envelope lacks state fingerprints")
    receipt = {
        "schema_version": CHECKPOINT_RECEIPT_SCHEMA,
        "path": str(path if path_reference is None else path_reference),
        "sha256": _file_sha256(path),
        "dataset_manifest_hash": envelope.get("dataset_manifest_hash"),
        "frontend_state_fingerprint": fingerprints.get("frontend_state_fingerprint"),
        "decoder_state_fingerprint": fingerprints.get("decoder_state_fingerprint"),
        "model_state_fingerprint": fingerprints.get("model_state_fingerprint"),
        "checkpoint_config_hash": envelope.get("checkpoint_config_hash"),
    }
    if any(not _is_sha256(receipt[name]) for name in (
        "sha256", "dataset_manifest_hash", "frontend_state_fingerprint",
        "decoder_state_fingerprint", "model_state_fingerprint", "checkpoint_config_hash",
    )):
        raise ValueError("checkpoint envelope cannot form a complete hash-bound receipt")
    return receipt


def validate_checkpoint_receipt(
    path: Path,
    model: FrontendLM,
    dataset_manifest: Mapping[str, Any],
    receipt: Mapping[str, Any],
    *,
    envelope: Mapping[str, Any] | None = None,
) -> None:
    """Validate a persisted RunManifest receipt against file, envelope, and model.

    ``path`` is already resolved by the RunManifest reader, so receipt paths
    can remain portable references relative to the manifest file.
    """
    if receipt.get("schema_version") != CHECKPOINT_RECEIPT_SCHEMA:
        raise ValueError("checkpoint receipt has an unsupported schema")
    if not isinstance(receipt.get("path"), str) or not receipt["path"]:
        raise ValueError("checkpoint receipt has no path")
    if receipt.get("sha256") != _file_sha256(path):
        raise ValueError("checkpoint receipt SHA-256 does not match checkpoint file")
    loaded = envelope
    if loaded is None:
        # Receipt-bound Gate-A files contain only tensors and plain data.  Do
        # not execute pickle constructors while validating decision evidence.
        loaded_value = torch.load(path, map_location="cpu", weights_only=True)
        if not isinstance(loaded_value, Mapping):
            raise ValueError("checkpoint file is not an envelope mapping")
        loaded = loaded_value
    _require_checkpoint_envelope_provenance(loaded, model, dataset_manifest)
    expected = checkpoint_receipt(path, envelope=loaded, path_reference=receipt["path"])
    for name, value in expected.items():
        if receipt.get(name) != value:
            raise ValueError(f"checkpoint receipt {name} does not match loaded checkpoint")


def compatible_checkpoint(checkpoint: dict, frontend: _Frontend, dataset_manifest: dict | None = None, model_config: dict | None = None, software_version: str = "domain-scaling-lab") -> None:
    if checkpoint.get("format") != CHECKPOINT_FORMAT or checkpoint.get("representation") != frontend.checkpoint_config(): raise ValueError("incompatible representation definition")
    if checkpoint.get("software_version") != software_version: raise ValueError("incompatible software version")
    if dataset_manifest is not None and checkpoint.get("dataset_manifest") != dataset_manifest: raise ValueError("incompatible dataset manifest")
    if model_config is not None and checkpoint.get("model_config") != model_config: raise ValueError("incompatible model configuration")


def save_checkpoint(path: Path, model: FrontendLM, dataset_manifest: dict, software_version: str = "domain-scaling-lab") -> dict:
    """Persist a self-validating checkpoint and return its in-file envelope."""
    envelope = checkpoint_envelope(model, dataset_manifest, software_version)
    torch.save(envelope, path)
    return envelope


def load_checkpoint(
    path: Path,
    model: FrontendLM,
    dataset_manifest: dict,
    software_version: str = "domain-scaling-lab",
    *,
    require_receipt: bool = False,
) -> dict:
    # An externally supplied Phase-1 transmitter is decision-bound only when
    # it uses the tensor/plain-data envelope.  Exploratory legacy loads retain
    # the old behaviour unless callers request a hash-bound receipt.
    checkpoint = torch.load(path, map_location="cpu", weights_only=require_receipt)
    if not isinstance(checkpoint, Mapping):
        raise ValueError("checkpoint file is not an envelope mapping")
    compatible_checkpoint(checkpoint, model.frontend, dataset_manifest, model.model_config(), software_version)
    model.load_state_dict(checkpoint["state_dict"])
    # New checkpoints always validate their internal provenance.  The opt-in
    # requirement lets existing exploratory v2 checkpoints remain loadable,
    # while decision-bound receiver work rejects them unless they carry it.
    if require_receipt or "checkpoint_config_hash" in checkpoint or "state_fingerprints" in checkpoint:
        _require_checkpoint_envelope_provenance(checkpoint, model, dataset_manifest)
    return checkpoint
