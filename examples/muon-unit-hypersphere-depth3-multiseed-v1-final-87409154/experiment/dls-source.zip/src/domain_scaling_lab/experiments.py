"""Small, deterministic curriculum experiments with inspectable metrics."""
from __future__ import annotations
from collections import Counter, defaultdict
import math
import torch
from torch import nn
from torch.nn import functional as F


def manual_cross_entropy(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    shifted = logits - logits.max(dim=-1, keepdim=True).values
    log_probs = shifted - shifted.exp().sum(dim=-1, keepdim=True).log()
    return -log_probs.gather(-1, targets[..., None]).squeeze(-1).mean()


def diagnostic_scores(seed: int = 7) -> dict[str, float]:
    torch.manual_seed(seed)
    logits = torch.randn(8, 5, requires_grad=True); targets = torch.randint(0, 5, (8,))
    manual = manual_cross_entropy(logits, targets); builtin = F.cross_entropy(logits, targets)
    manual.backward(); gradient_norm = float(logits.grad.norm())
    linear = nn.Linear(3, 1); optimizer = torch.optim.SGD(linear.parameters(), lr=0.1)
    x, y = torch.ones(4, 3), torch.zeros(4, 1)
    before = float(F.mse_loss(linear(x), y).detach())
    optimizer.zero_grad(); (F.mse_loss(linear(x[:2]), y[:2]) / 2).backward(); (F.mse_loss(linear(x[2:]), y[2:]) / 2).backward(); optimizer.step()
    after = float(F.mse_loss(linear(x), y).detach())
    dropout = nn.Dropout(0.8); probe = torch.ones(32)
    dropout.train(); train_std = float(torch.stack([dropout(probe) for _ in range(4)]).std())
    dropout.eval(); eval_std = float(torch.stack([dropout(probe) for _ in range(4)]).std())
    return {"manual_builtin_gap": float((manual - builtin).abs().detach()), "gradient_norm": gradient_norm, "loss_before": before, "loss_after": after, "dropout_train_std": train_std, "dropout_eval_std": eval_std}


class CountBigramLM:
    def __init__(self, vocab_size: int, smoothing: float = 1.0):
        self.vocab_size, self.smoothing = vocab_size, smoothing
        self.counts: dict[int, Counter[int]] = defaultdict(Counter)

    def fit(self, sequences: list[list[int]]) -> "CountBigramLM":
        for sequence in sequences:
            for left, right in zip(sequence, sequence[1:]): self.counts[left][right] += 1
        return self

    def probability(self, left: int, right: int) -> float:
        row = self.counts[left]
        return (row[right] + self.smoothing) / (sum(row.values()) + self.smoothing * self.vocab_size)

    def nll(self, sequences: list[list[int]]) -> float:
        pairs = [(a, b) for seq in sequences for a, b in zip(seq, seq[1:])]
        return -sum(math.log(self.probability(a, b)) for a, b in pairs) / len(pairs)

    def generate(self, start: int, length: int) -> list[int]:
        tokens = [start]
        for _ in range(length - 1): tokens.append(max(range(self.vocab_size), key=lambda i: self.probability(tokens[-1], i)))
        return tokens


class NeuralBigramLM(nn.Module):
    def __init__(self, vocab_size: int): super().__init__(); self.table = nn.Embedding(vocab_size, vocab_size)
    def forward(self, tokens: torch.Tensor) -> torch.Tensor: return self.table(tokens)
    def loss(self, sequences: list[list[int]]) -> torch.Tensor:
        pairs = [(a, b) for seq in sequences for a, b in zip(seq, seq[1:])]
        x, y = torch.tensor([a for a, _ in pairs]), torch.tensor([b for _, b in pairs])
        return F.cross_entropy(self(x), y)
    @torch.no_grad()
    def generate(self, start: int, length: int) -> list[int]:
        out=[start]
        for _ in range(length - 1): out.append(int(self(torch.tensor([out[-1]])).argmax()))
        return out


def train_neural_bigram(model: NeuralBigramLM, sequences: list[list[int]], *, steps: int = 100, lr: float = 0.1) -> list[float]:
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr); losses=[]
    for _ in range(steps): optimizer.zero_grad(); loss=model.loss(sequences); loss.backward(); optimizer.step(); losses.append(float(loss.detach()))
    return losses


def perplexity(nll: float) -> float: return math.exp(nll)

