"""Issue #162: minimal log-polar downstream falsification benchmark.

This module deliberately leaves the frozen Gate-A spectral transmitter alone.
It exposes the exact current-symbol, pre-composition state used by issue #123,
adds a parameter-free log-polar coordinate control, and changes only the
attention score in the polar-native arm.  Spherical shells and spectral
composition are outside this module's scope.
"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
import math
import resource
import sys
import time
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F

from .oracle_no_composition import (
    CausalTransformerNextBytePredictor,
    PredictorOutput,
    _fixed_sinusoid,
    parameter_count,
)
from .oracle_no_composition_stats import integer_draw_sha256
from .receivers import freeze_spectral_precomposition_state
from .spectral import TextBatch, module_state_fingerprint, tensor_state_fingerprint


ISSUE_NUMBER = 162
SCHEMA_VERSION = "log-polar-no-composition/v1"
CONFIG_SCHEMA = "log-polar-no-composition-config/v1"
CONDITIONS = (
    "byte_cartesian",
    "spectral_cartesian",
    "spectral_coordinate_cartesian",
    "spectral_polar",
)
PRIMARY_CONDITIONS = CONDITIONS[:2] + CONDITIONS[3:]
CHECKPOINT_STEPS = (0, 8, 16, 32, 64, 96, 128)
BUDGET_FRACTIONS = (0.0, 1 / 16, 1 / 8, 1 / 4, 1 / 2, 3 / 4, 1.0)
DOWNSTREAM_SEEDS = (17, 31, 47)
OUTCOMES = ("final", "aulc")
CONTRAST_DEFINITIONS: Mapping[str, tuple[tuple[str, float], ...]] = {
    "representation_gap": (("spectral_cartesian", 1.0), ("byte_cartesian", -1.0)),
    "polar_gain": (("spectral_polar", 1.0), ("spectral_cartesian", -1.0)),
    "remaining_byte_gap": (("spectral_polar", 1.0), ("byte_cartesian", -1.0)),
    "coordinate_gain": (("spectral_coordinate_cartesian", 1.0), ("spectral_cartesian", -1.0)),
    "polar_native_vs_coordinate": (("spectral_polar", 1.0), ("spectral_coordinate_cartesian", -1.0)),
}
BOOTSTRAP_SAMPLES = 65_536
BOOTSTRAP_SEED = 12_365_536
BOOTSTRAP_DRAW_SHA256 = "66ae49f1c3cad563b9d3a7c064975c7c06ace812a187be3358163557e80c8a24"
FAMILYWISE_ALPHA = 0.05
DECISION_FAMILY_SIZE = len(CONTRAST_DEFINITIONS) * len(OUTCOMES)


def _jsonable(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


def canonical_json(value: Any) -> str:
    return json.dumps(_jsonable(value), sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value: Any) -> str:
    return sha256(canonical_json(value).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class LogPolarConfig:
    """Frozen #162 architecture, budget, statistics, and advance policy."""

    schema_version: str = CONFIG_SCHEMA
    profile: str = "qualifying"
    dimension: int = 32
    window_length: int = 4
    transmitter_seed: int = 7
    canonical_width: int = 128
    heads: int = 4
    layers: int = 1
    downstream_seeds: tuple[int, ...] = DOWNSTREAM_SEEDS
    updates: int = 128
    checkpoint_steps: tuple[int, ...] = CHECKPOINT_STEPS
    learning_rate: float = 1e-3
    weight_decay: float = 1e-2
    gradient_clip_norm: float = 1.0
    rms_epsilon: float = 1e-8
    log_radius_epsilon: float = 1e-6
    angular_norm_epsilon: float = 1e-6
    material_nll_threshold: float = 0.01
    equivalence_nll_margin: float = 0.005
    bootstrap_samples: int = BOOTSTRAP_SAMPLES
    bootstrap_seed: int = BOOTSTRAP_SEED
    expected_calibration_documents: int = 8
    expected_evaluation_documents: int = 8
    expected_calibration_bytes: int = 1_792
    expected_evaluation_bytes: int = 1_677
    max_polar_elementwise_overhead_fraction: float = 0.01

    def validate(self) -> None:
        if self.schema_version != CONFIG_SCHEMA:
            raise ValueError("unsupported #162 config schema")
        if self.profile not in {"qualifying", "fixture"}:
            raise ValueError("profile must be qualifying or fixture")
        if (self.dimension, self.window_length, self.transmitter_seed) != (32, 4, 7):
            raise ValueError("#162 must inherit the frozen D32/W4/seed7 transmitter")
        if self.canonical_width != 128 or self.heads != 4 or self.layers != 1:
            raise ValueError("#162 must inherit #123's width/depth envelope")
        if tuple(self.downstream_seeds) != DOWNSTREAM_SEEDS:
            raise ValueError("#162 downstream seeds drifted")
        if tuple(self.checkpoint_steps) != CHECKPOINT_STEPS or self.updates != self.checkpoint_steps[-1]:
            if self.profile == "qualifying":
                raise ValueError("#162 qualifying budget/checkpoints drifted")
        if not 0 < self.learning_rate <= 0.1 or not 0 <= self.weight_decay <= 0.1:
            raise ValueError("invalid optimizer policy")
        if min(self.gradient_clip_norm, self.rms_epsilon, self.log_radius_epsilon, self.angular_norm_epsilon) <= 0:
            raise ValueError("numerical epsilons and clipping must be positive")
        if (self.material_nll_threshold, self.equivalence_nll_margin) != (0.01, 0.005):
            raise ValueError("#123 materiality/equivalence scale drifted")
        if (self.bootstrap_samples, self.bootstrap_seed) != (BOOTSTRAP_SAMPLES, BOOTSTRAP_SEED):
            raise ValueError("paired bootstrap policy drifted")
        if not 0 < self.max_polar_elementwise_overhead_fraction <= 0.01:
            raise ValueError("polar overhead ceiling must be at most one percent")


DEFAULT_CONFIG = LogPolarConfig()


def fixture_config() -> LogPolarConfig:
    config = replace(
        DEFAULT_CONFIG,
        profile="fixture",
        updates=2,
        checkpoint_steps=(0, 1, 2),
        expected_calibration_documents=2,
        expected_evaluation_documents=2,
        expected_calibration_bytes=10,
        expected_evaluation_bytes=10,
    )
    config.validate()
    return config


def config_wire(config: LogPolarConfig = DEFAULT_CONFIG) -> dict[str, Any]:
    config.validate()
    return _jsonable(asdict(config))


def config_digest(config: LogPolarConfig = DEFAULT_CONFIG) -> str:
    return digest(config_wire(config))


def complex_to_log_polar(
    packed: torch.Tensor,
    *,
    epsilon: float = DEFAULT_CONFIG.log_radius_epsilon,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Convert packed ``[real...,imag...]`` values to rho and canonical theta.

    The canonical interval is ``[-pi, pi)``.  Exact zero uses theta=0 while
    retaining rho=log(epsilon).  Replacing zero inputs before sqrt/atan2 keeps
    their gradients finite and exactly zero after the final selection.
    """

    if packed.size(-1) % 2:
        raise ValueError("packed complex features require an even final dimension")
    if epsilon <= 0:
        raise ValueError("log-radius epsilon must be positive")
    real, imag = packed.chunk(2, dim=-1)
    active = real.ne(0) | imag.ne(0)
    safe_real = torch.where(active, real, torch.ones_like(real))
    safe_imag = torch.where(active, imag, torch.zeros_like(imag))
    magnitude = torch.sqrt(safe_real.square() + safe_imag.square())
    rho_active = torch.log(magnitude + epsilon)
    rho = torch.where(active, rho_active, torch.full_like(rho_active, math.log(epsilon)))
    raw_theta = torch.atan2(safe_imag, safe_real)
    theta = torch.remainder(raw_theta + math.pi, 2 * math.pi) - math.pi
    theta = torch.where(active, theta, torch.zeros_like(theta))
    if not torch.isfinite(rho).all() or not torch.isfinite(theta).all():
        raise FloatingPointError("non-finite log-polar coordinates")
    return rho, theta


def log_polar_to_complex(
    rho: torch.Tensor,
    theta: torch.Tensor,
    *,
    epsilon: float = DEFAULT_CONFIG.log_radius_epsilon,
) -> torch.Tensor:
    if rho.shape != theta.shape:
        raise ValueError("rho and theta must have identical shapes")
    magnitude = (rho.exp() - epsilon).clamp_min(0.0)
    packed = torch.cat((magnitude * theta.cos(), magnitude * theta.sin()), dim=-1)
    if not torch.isfinite(packed).all():
        raise FloatingPointError("non-finite log-polar reconstruction")
    return packed


def log_polar_features(
    packed: torch.Tensor,
    active_mask: torch.Tensor,
    *,
    width: int = 128,
    epsilon: float = DEFAULT_CONFIG.log_radius_epsilon,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    """Parameter-free coordinate map used by both coordinate and native arms.

    Layout is 16 log radii, 16 cosines, 16 sines, then structural zeros.  The
    map is invertible for nonzero values before right padding.  BOS/padding is
    kept at the all-zero structural sentinel instead of becoming log(epsilon).
    """

    if packed.ndim != 3 or tuple(active_mask.shape) != tuple(packed.shape[:2]):
        raise ValueError("log-polar inputs must be [batch,time,complex-width] plus [batch,time] mask")
    rho, theta = complex_to_log_polar(packed, epsilon=epsilon)
    active = active_mask[..., None] & (packed.chunk(2, dim=-1)[0].ne(0) | packed.chunk(2, dim=-1)[1].ne(0))
    rho_feature = torch.where(active, rho, torch.zeros_like(rho))
    cosine = torch.where(active, theta.cos(), torch.zeros_like(theta))
    sine = torch.where(active, theta.sin(), torch.zeros_like(theta))
    compact = torch.cat((rho_feature, cosine, sine), dim=-1)
    if compact.size(-1) > width:
        raise ValueError("log-polar coordinate map exceeds canonical width")
    states = F.pad(compact, (0, width - compact.size(-1)))
    states = states.masked_fill(~active_mask[..., None], 0.0).contiguous()
    if not torch.isfinite(states).all():
        raise FloatingPointError("non-finite log-polar features")
    return states, {"rho": rho, "theta": theta, "complex_active": active.squeeze(-1)}


def fit_scalar_rms(states: torch.Tensor, time_mask: torch.Tensor, epsilon: float = 1e-8) -> float:
    if states.ndim != 3 or tuple(time_mask.shape) != tuple(states.shape[:2]):
        raise ValueError("RMS inputs are misaligned")
    count = int(time_mask.sum().item()) * states.size(-1)
    if count < 1:
        raise ValueError("cannot calibrate an empty representation")
    masked = states.masked_fill(~time_mask[..., None], 0.0)
    value = math.sqrt(float(masked.square().sum(dtype=torch.float64).item()) / count)
    if not math.isfinite(value) or value <= epsilon:
        raise ValueError("invalid instrumentation: RMS is non-finite or degenerate")
    return value


def canonicalize(states: torch.Tensor, time_mask: torch.Tensor, scalar_rms: float) -> torch.Tensor:
    value = (states / scalar_rms).masked_fill(~time_mask[..., None], 0.0).contiguous()
    if value.size(-1) != 128 or not torch.isfinite(value).all():
        raise FloatingPointError("invalid canonical representation")
    return value


class PhaseAwareCausalTransformer(CausalTransformerNextBytePredictor):
    """Parameter-matched one-layer Transformer with a phase-aware Q/K score.

    Q/K heads are split into equal radial and angular latent halves.  Angular
    coordinates are paired, normalized to radius sqrt(2), and compared with a
    real Hermitian score.  Values, output projection, residuals, layer norms,
    feed-forward block, positional signal, and byte head are unchanged.
    """

    architecture = "log-polar-phase-aware-transformer"

    def __init__(self, width: int = 128, heads: int = 4, layers: int = 1, angular_epsilon: float = 1e-6):
        if layers != 1:
            raise ValueError("#162 freezes the minimal polar block to one layer")
        super().__init__(width=width, heads=heads, layers=layers)
        self.angular_epsilon = float(angular_epsilon)
        self.heads = int(heads)

    def _phase_attention(self, x: torch.Tensor, time_mask: torch.Tensor) -> torch.Tensor:
        attention = self.backbone.decoder.layers[0].self_attn
        batch, time_steps, width = x.shape
        head_width = width // self.heads
        if head_width % 4 or width % self.heads:
            raise ValueError("each #162 head needs an even angular half")
        qkv = F.linear(x, attention.in_proj_weight, attention.in_proj_bias)
        query, key, value = qkv.chunk(3, dim=-1)

        def heads(tensor: torch.Tensor) -> torch.Tensor:
            return tensor.reshape(batch, time_steps, self.heads, head_width).transpose(1, 2)

        query, key, value = heads(query), heads(key), heads(value)
        radial_width = head_width // 2

        def preserve_phase(tensor: torch.Tensor) -> torch.Tensor:
            radial, angular = tensor.split((radial_width, head_width - radial_width), dim=-1)
            pairs = angular.reshape(*angular.shape[:-1], -1, 2)
            norm = torch.sqrt(pairs.square().sum(dim=-1, keepdim=True) + self.angular_epsilon ** 2)
            unit = math.sqrt(2.0) * pairs / norm
            return torch.cat((radial, unit.flatten(start_dim=-2)), dim=-1)

        query, key = preserve_phase(query), preserve_phase(key)
        scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(head_width)
        causal = torch.ones(time_steps, time_steps, device=x.device, dtype=torch.bool).triu(1)
        scores = scores.masked_fill(causal[None, None], float("-inf"))
        scores = scores.masked_fill(~time_mask[:, None, None, :], float("-inf"))
        weights = torch.softmax(scores, dim=-1)
        context = torch.matmul(weights, value).transpose(1, 2).contiguous().reshape(batch, time_steps, width)
        output = F.linear(context, attention.out_proj.weight, attention.out_proj.bias)
        if not torch.isfinite(output).all():
            raise FloatingPointError("non-finite polar attention output")
        return output

    def forward(self, states: torch.Tensor, time_mask: torch.Tensor) -> PredictorOutput:
        if states.ndim != 3 or tuple(time_mask.shape) != tuple(states.shape[:2]) or states.size(-1) != self.width:
            raise ValueError("predictor inputs drifted")
        if not torch.isfinite(states).all():
            raise FloatingPointError("non-finite polar predictor input")
        position = _fixed_sinusoid(
            states.size(1), self.width, device=states.device, dtype=states.dtype,
        )[None]
        x = states.masked_fill(~time_mask[..., None], 0.0) + position
        layer = self.backbone.decoder.layers[0]
        x = layer.norm1(x + layer.dropout1(self._phase_attention(x, time_mask)))
        feed_forward = layer.linear2(layer.dropout(layer.activation(layer.linear1(x))))
        hidden = layer.norm2(x + layer.dropout2(feed_forward))
        hidden = hidden.masked_fill(~time_mask[..., None], 0.0)
        logits = self.backbone.head(hidden).masked_fill(~time_mask[..., None], 0.0)
        if not torch.isfinite(hidden).all() or not torch.isfinite(logits).all():
            raise FloatingPointError("non-finite polar Transformer output")
        return PredictorOutput(logits=logits, hidden=hidden)


def build_matched_predictor(
    condition: str,
    seed: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> nn.Module:
    config.validate()
    if condition not in CONDITIONS:
        raise ValueError(f"unknown #162 condition {condition!r}")
    if seed not in config.downstream_seeds:
        raise ValueError("non-preregistered downstream seed")
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed)
        if condition == "spectral_polar":
            model: nn.Module = PhaseAwareCausalTransformer(
                config.canonical_width, config.heads, config.layers, config.angular_norm_epsilon,
            )
        else:
            model = CausalTransformerNextBytePredictor(
                config.canonical_width, config.heads, config.layers,
            )
    return model


def dense_forward_flops(batch: int, time_steps: int, config: LogPolarConfig = DEFAULT_CONFIG) -> int:
    """Reuse #123's dense Transformer multiply/add accounting exactly."""

    d, vocab = config.canonical_width, 256
    layer = 8 * time_steps * d * d + 4 * time_steps * time_steps * d + 16 * time_steps * d * d
    return int(batch * (config.layers * layer + 2 * time_steps * d * vocab))


def polar_elementwise_operations(batch: int, time_steps: int, config: LogPolarConfig = DEFAULT_CONFIG) -> int:
    """Separate estimate for Q/K pair norms (includes sqrt/div as scalar ops)."""

    head_width = config.canonical_width // config.heads
    angular_pairs = (head_width // 2) // 2
    # Each pair: 2 squares + add + sqrt + 2 divides + 2 scales = 8; Q and K.
    return int(batch * time_steps * config.heads * angular_pairs * 16)


@dataclass(frozen=True)
class PreparedCondition:
    name: str
    train_states: torch.Tensor
    evaluation_states: torch.Tensor
    train_mask: torch.Tensor
    evaluation_mask: torch.Tensor
    scalar_rms: float
    raw_train_fingerprint: str
    raw_evaluation_fingerprint: str
    canonical_train_fingerprint: str
    canonical_evaluation_fingerprint: str
    polar_auxiliary_train: Mapping[str, torch.Tensor] | None = None
    polar_auxiliary_evaluation: Mapping[str, torch.Tensor] | None = None


def prepare_conditions(
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    *,
    spectral_frontend: nn.Module,
    byte_frontend: nn.Module,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> dict[str, PreparedCondition]:
    """Extract the exact #123 current-symbol views and the shared polar map."""

    config.validate()
    if calibration_batch.input_ids.shape != calibration_batch.valid.shape:
        raise ValueError("calibration batch is misaligned")
    if evaluation_batch.input_ids.shape != evaluation_batch.valid.shape:
        raise ValueError("evaluation batch is misaligned")
    byte_embedding = getattr(byte_frontend, "embedding", None)
    if not isinstance(byte_embedding, nn.Embedding):
        raise TypeError("byte reference must expose its frozen embedding")

    def raw(batch: TextBatch) -> tuple[dict[str, torch.Tensor], dict[str, Mapping[str, torch.Tensor]]]:
        with torch.no_grad():
            byte = byte_embedding(batch.input_ids).detach()
            precomposition = freeze_spectral_precomposition_state(spectral_frontend, batch.input_ids)
            spectral = precomposition.current_symbols.detach()
        current_valid = batch.valid & batch.input_ids.ne(0)
        spectral = spectral.masked_fill(~current_valid[..., None], 0.0)
        byte = byte.masked_fill(~batch.valid[..., None], 0.0)
        byte = F.pad(byte, (0, config.canonical_width - byte.size(-1)))
        spectral = F.pad(spectral, (0, config.canonical_width - spectral.size(-1)))
        compact_spectral = precomposition.current_symbols.detach().masked_fill(~current_valid[..., None], 0.0)
        polar, auxiliary = log_polar_features(
            compact_spectral, current_valid, width=config.canonical_width,
            epsilon=config.log_radius_epsilon,
        )
        return {
            "byte_cartesian": byte,
            "spectral_cartesian": spectral,
            "spectral_coordinate_cartesian": polar,
            "spectral_polar": polar.clone(),
        }, {
            "spectral_coordinate_cartesian": auxiliary,
            "spectral_polar": {key: value.clone() for key, value in auxiliary.items()},
        }

    train_raw, train_aux = raw(calibration_batch)
    evaluation_raw, evaluation_aux = raw(evaluation_batch)
    output: dict[str, PreparedCondition] = {}
    for condition in CONDITIONS:
        rms = fit_scalar_rms(train_raw[condition], calibration_batch.valid, config.rms_epsilon)
        train = canonicalize(train_raw[condition], calibration_batch.valid, rms)
        evaluation = canonicalize(evaluation_raw[condition], evaluation_batch.valid, rms)
        output[condition] = PreparedCondition(
            name=condition,
            train_states=train,
            evaluation_states=evaluation,
            train_mask=calibration_batch.valid.detach().bool(),
            evaluation_mask=evaluation_batch.valid.detach().bool(),
            scalar_rms=rms,
            raw_train_fingerprint=tensor_state_fingerprint(train_raw[condition]),
            raw_evaluation_fingerprint=tensor_state_fingerprint(evaluation_raw[condition]),
            canonical_train_fingerprint=tensor_state_fingerprint(train),
            canonical_evaluation_fingerprint=tensor_state_fingerprint(evaluation),
            polar_auxiliary_train=train_aux.get(condition),
            polar_auxiliary_evaluation=evaluation_aux.get(condition),
        )
    if not torch.equal(
        output["spectral_coordinate_cartesian"].train_states,
        output["spectral_polar"].train_states,
    ) or not torch.equal(
        output["spectral_coordinate_cartesian"].evaluation_states,
        output["spectral_polar"].evaluation_states,
    ):
        raise RuntimeError("coordinate-only and polar arms do not share identical inputs")
    return output


def _rss_bytes() -> int:
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value if sys.platform == "darwin" else value * 1024


def _device_batch(batch: TextBatch, device: torch.device) -> TextBatch:
    return TextBatch(
        input_ids=batch.input_ids.to(device),
        targets=batch.targets.to(device),
        valid=batch.valid.to(device),
        byte_count=batch.byte_count,
        document_ids=batch.document_ids,
    )


def _document_rows(
    output: PredictorOutput,
    batch: TextBatch,
    *,
    condition: str,
    seed: int,
    step: int,
    cumulative_bytes: int,
    cumulative_dense_flops: int,
    cumulative_polar_operations: int,
) -> list[dict[str, Any]]:
    nll = F.cross_entropy(output.logits.transpose(1, 2), batch.targets, reduction="none")
    rows: list[dict[str, Any]] = []
    for index, document_id in enumerate(batch.document_ids):
        count = int(batch.valid[index].sum().item())
        total = float((nll[index] * batch.valid[index]).sum(dtype=torch.float64).item())
        rows.append({
            "condition": condition,
            "architecture": "vanilla-transformer" if condition != "spectral_polar" else "log-polar-phase-aware-transformer",
            "seed": seed,
            "document_id": document_id,
            "checkpoint_step": step,
            "total_nll": total,
            "original_byte_count": count,
            "byte_normalized_nll": total / count,
            "cumulative_training_original_bytes": cumulative_bytes,
            "cumulative_training_dense_flops_estimate": cumulative_dense_flops,
            "cumulative_training_polar_elementwise_operations_estimate": cumulative_polar_operations,
        })
    return rows


def _summarize(values: Sequence[float]) -> dict[str, float]:
    if not values or any(not math.isfinite(value) for value in values):
        raise ValueError("cannot summarize empty/non-finite values")
    return {
        "minimum": min(values),
        "maximum": max(values),
        "mean": math.fsum(values) / len(values),
    }


def fit_condition(
    prepared: PreparedCondition,
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    *,
    seed: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
    device: str | torch.device = "cpu",
) -> dict[str, Any]:
    """Fit one frozen-budget cell and emit per-document byte NLL evidence."""

    config.validate()
    requested = torch.device(device)
    if requested.type != "cpu" and not torch.cuda.is_available():
        raise ValueError("requested accelerator is unavailable")
    model = build_matched_predictor(prepared.name, seed, config).to(requested)
    initial_sha = module_state_fingerprint(model)
    track_coordinate_gradients = prepared.polar_auxiliary_train is not None
    # Preserve the exact #123 Cartesian execution path for the inherited
    # baselines.  Input gradients are requested only for the two coordinate-
    # identical log-polar arms where rho/theta diagnostics are required.
    train_states = prepared.train_states.to(requested).detach().requires_grad_(track_coordinate_gradients)
    evaluation_states = prepared.evaluation_states.to(requested)
    train_mask = prepared.train_mask.to(requested)
    evaluation_mask = prepared.evaluation_mask.to(requested)
    train_batch = _device_batch(calibration_batch, requested)
    evaluation_batch_device = _device_batch(evaluation_batch, requested)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    train_forward = dense_forward_flops(train_states.size(0), train_states.size(1), config)
    eval_forward = dense_forward_flops(evaluation_states.size(0), evaluation_states.size(1), config)
    train_polar = polar_elementwise_operations(train_states.size(0), train_states.size(1), config) if prepared.name == "spectral_polar" else 0
    eval_polar = polar_elementwise_operations(evaluation_states.size(0), evaluation_states.size(1), config) if prepared.name == "spectral_polar" else 0
    trace: list[dict[str, Any]] = []
    train_curve: list[dict[str, Any]] = []
    checkpoint_ledger: list[dict[str, Any]] = []
    gradient_norms: list[float] = []
    update_norms: list[float] = []
    radial_gradients: list[float] = []
    angular_gradients: list[float] = []
    initial_rss = _rss_bytes()
    training_elapsed = 0.0
    total_started = time.perf_counter()

    def evaluate(step: int) -> None:
        model.eval()
        started = time.perf_counter()
        with torch.no_grad():
            output = model(evaluation_states, evaluation_mask)
            rows = _document_rows(
                output,
                evaluation_batch_device,
                condition=prepared.name,
                seed=seed,
                step=step,
                cumulative_bytes=calibration_batch.byte_count * step,
                cumulative_dense_flops=3 * train_forward * step,
                cumulative_polar_operations=3 * train_polar * step,
            )
        elapsed = max(time.perf_counter() - started, 1e-12)
        trace.extend(rows)
        total = math.fsum(row["total_nll"] for row in rows)
        count = sum(row["original_byte_count"] for row in rows)
        checkpoint_ledger.append({
            "checkpoint_step": step,
            "total_nll": total,
            "original_byte_count": count,
            "byte_normalized_nll": total / count,
            "elapsed_seconds": elapsed,
            "original_bytes_per_second": count / elapsed,
            "model_state_sha256": module_state_fingerprint(model),
        })

    evaluate(0)
    for step in range(1, config.updates + 1):
        started = time.perf_counter()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        if track_coordinate_gradients:
            train_states.grad = None
        output = model(train_states, train_mask)
        nll = F.cross_entropy(output.logits.transpose(1, 2), train_batch.targets, reduction="none")
        total_nll = (nll * train_batch.valid).sum()
        loss = total_nll / train_batch.byte_count
        if not torch.isfinite(loss):
            raise RuntimeError("non-finite #162 training loss")
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip_norm)
        norm_value = float(norm.detach().cpu().item())
        if not math.isfinite(norm_value):
            raise RuntimeError("non-finite #162 gradient")
        if track_coordinate_gradients and (
            train_states.grad is None or not torch.isfinite(train_states.grad).all()
        ):
            raise RuntimeError("non-finite #162 coordinate gradient")
        gradient_norms.append(norm_value)
        if prepared.polar_auxiliary_train is not None:
            auxiliary = prepared.polar_auxiliary_train
            theta = auxiliary["theta"].to(requested)
            active = auxiliary["complex_active"].to(requested) & train_mask[..., None]
            channels = theta.size(-1)
            state_gradient = train_states.grad
            rho_gradient = state_gradient[..., :channels] / prepared.scalar_rms
            cosine_gradient = state_gradient[..., channels:2 * channels] / prepared.scalar_rms
            sine_gradient = state_gradient[..., 2 * channels:3 * channels] / prepared.scalar_rms
            theta_gradient = -theta.sin() * cosine_gradient + theta.cos() * sine_gradient
            selected_rho = rho_gradient[active]
            selected_theta = theta_gradient[active]
            radial_gradients.append(float(selected_rho.square().mean().sqrt().item()))
            angular_gradients.append(float(selected_theta.square().mean().sqrt().item()))
        before = [parameter.detach().clone() for parameter in model.parameters()]
        optimizer.step()
        update_norm = math.sqrt(math.fsum(
            float((parameter.detach() - old).square().sum(dtype=torch.float64).item())
            for old, parameter in zip(before, model.parameters(), strict=True)
        ))
        if not math.isfinite(update_norm) or any(not torch.isfinite(parameter).all() for parameter in model.parameters()):
            raise RuntimeError("non-finite #162 parameter update")
        update_norms.append(update_norm)
        training_elapsed += time.perf_counter() - started
        train_curve.append({
            "step": step,
            "total_nll": float(total_nll.detach().cpu().item()),
            "original_byte_count": train_batch.byte_count,
            "byte_normalized_nll": float(loss.detach().cpu().item()),
            "preclip_gradient_l2_norm": norm_value,
            "parameter_update_l2_norm": update_norm,
            "parameters_finite": True,
            "cumulative_training_original_bytes": train_batch.byte_count * step,
            "cumulative_training_dense_flops_estimate": 3 * train_forward * step,
            "cumulative_training_polar_elementwise_operations_estimate": 3 * train_polar * step,
        })
        if step in config.checkpoint_steps:
            evaluate(step)

    total_elapsed = max(time.perf_counter() - total_started, 1e-12)
    training_elapsed = max(training_elapsed, 1e-12)
    final_rows = [row for row in trace if row["checkpoint_step"] == config.updates]
    final_total = math.fsum(row["total_nll"] for row in final_rows)
    final_count = sum(row["original_byte_count"] for row in final_rows)
    parameters = parameter_count(model)
    parameter_bytes = sum(parameter.numel() * parameter.element_size() for parameter in model.parameters())
    elementwise_fraction = train_polar / train_forward if train_forward else 0.0
    return {
        "schema_version": "log-polar-no-composition-cell/v1",
        "issue": ISSUE_NUMBER,
        "condition": prepared.name,
        "seed": seed,
        "config_sha256": config_digest(config),
        "rms_calibration": {
            "scalar_rms": prepared.scalar_rms,
            "epsilon": config.rms_epsilon,
            "valid_time_count": int(prepared.train_mask.sum().item()),
            "canonical_element_count": int(prepared.train_mask.sum().item()) * config.canonical_width,
        },
        "representation_provenance": {
            "raw_train_fingerprint": prepared.raw_train_fingerprint,
            "raw_evaluation_fingerprint": prepared.raw_evaluation_fingerprint,
            "canonical_train_fingerprint": prepared.canonical_train_fingerprint,
            "canonical_evaluation_fingerprint": prepared.canonical_evaluation_fingerprint,
            "coordinate_map_parameter_count": 0,
            "composition": "none",
        },
        "initial_model_state_sha256": initial_sha,
        "final_model_state_sha256": module_state_fingerprint(model),
        "train_curve": train_curve,
        "validation_learning_curve": trace,
        "final_evaluation": {
            "total_nll": final_total,
            "original_byte_count": final_count,
            "byte_normalized_nll": final_total / final_count,
            "documents": final_rows,
        },
        "parameter_ledger": {
            "total_parameters": parameters,
            "trainable_parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
            "parameter_bytes": parameter_bytes,
        },
        "flop_ledger": {
            "estimation": "#123 deterministic dense multiply/add ledger plus separate polar scalar-operation estimate",
            "dense_forward_flops_per_calibration_batch": train_forward,
            "dense_training_flops_estimate": 3 * train_forward * config.updates,
            "dense_checkpoint_evaluation_flops_estimate": eval_forward * len(config.checkpoint_steps),
            "dense_total_flops_estimate": 3 * train_forward * config.updates + eval_forward * len(config.checkpoint_steps),
            "polar_elementwise_operations_per_calibration_batch": train_polar,
            "polar_training_elementwise_operations_estimate": 3 * train_polar * config.updates,
            "polar_checkpoint_evaluation_elementwise_operations_estimate": eval_polar * len(config.checkpoint_steps),
            "polar_elementwise_overhead_fraction_of_dense_forward": elementwise_fraction,
        },
        "performance_ledger": {
            "training_elapsed_seconds": training_elapsed,
            "cell_total_wall_elapsed_seconds": total_elapsed,
            "training_original_bytes_processed": train_batch.byte_count * config.updates,
            "training_original_bytes_per_second": train_batch.byte_count * config.updates / training_elapsed,
            "checkpoint_ledger": checkpoint_ledger,
            "peak_process_rss_bytes": _rss_bytes(),
            "initial_process_peak_rss_bytes": initial_rss,
        },
        "gradient_ledger": {
            "parameter_preclip_l2": _summarize(gradient_norms),
            "parameter_update_l2": _summarize(update_norms),
            "radial_rho_rms": _summarize(radial_gradients) if radial_gradients else None,
            "angular_theta_rms": _summarize(angular_gradients) if angular_gradients else None,
            "all_finite": True,
        },
        "test_split": {"status": "sealed-not-read", "accessed": False},
    }


def aggregate_outcomes(rows: Sequence[Mapping[str, Any]]) -> tuple[dict[str, dict[str, float]], list[dict[str, Any]]]:
    """Average fixed seeds within documents, then byte-pool and integrate."""

    cells: dict[tuple[str, int, str, int], tuple[float, int]] = {}
    documents: set[str] = set()
    for row in rows:
        condition, seed = str(row["condition"]), int(row["seed"])
        document, step = str(row["document_id"]), int(row["checkpoint_step"])
        if condition not in CONDITIONS or seed not in DOWNSTREAM_SEEDS or step not in CHECKPOINT_STEPS:
            raise ValueError("trace contains a non-preregistered cell")
        key = (condition, seed, document, step)
        if key in cells:
            raise ValueError("duplicate trace row")
        total, count = float(row["total_nll"]), int(row["original_byte_count"])
        if count < 1 or not math.isfinite(total) or not math.isclose(float(row["byte_normalized_nll"]), total / count, rel_tol=1e-9, abs_tol=1e-11):
            raise ValueError("invalid byte-normalized trace row")
        cells[key] = (total, count)
        documents.add(document)
    document_ids = sorted(documents)
    expected = {
        (condition, seed, document, step)
        for condition in CONDITIONS for seed in DOWNSTREAM_SEEDS
        for document in document_ids for step in CHECKPOINT_STEPS
    }
    if len(document_ids) != 8 or set(cells) != expected:
        raise ValueError("trace does not cover the frozen four-by-three-by-eight-by-seven grid")
    aggregated: list[dict[str, Any]] = []
    for condition in CONDITIONS:
        for document in document_ids:
            for step in CHECKPOINT_STEPS:
                values = [cells[(condition, seed, document, step)] for seed in DOWNSTREAM_SEEDS]
                if len({count for _, count in values}) != 1:
                    raise ValueError("paired document byte counts drifted")
                aggregated.append({
                    "condition": condition,
                    "document_id": document,
                    "checkpoint_step": step,
                    "mean_total_nll": math.fsum(total for total, _ in values) / len(values),
                    "original_byte_count": values[0][1],
                })
    index: dict[tuple[str, int], list[Mapping[str, Any]]] = defaultdict(list)
    for row in aggregated:
        index[(str(row["condition"]), int(row["checkpoint_step"]))].append(row)
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    outcomes: dict[str, dict[str, float]] = {}
    for condition in CONDITIONS:
        curve = []
        for step in CHECKPOINT_STEPS:
            group = index[(condition, step)]
            curve.append(
                math.fsum(float(row["mean_total_nll"]) for row in group)
                / sum(int(row["original_byte_count"]) for row in group)
            )
        values = torch.tensor(curve, dtype=torch.float64)
        outcomes[condition] = {
            "final": float(values[-1]),
            "aulc": float(torch.trapezoid(values, fractions)),
        }
    return outcomes, aggregated


def paired_document_bootstrap(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    outcomes, aggregated = aggregate_outcomes(rows)
    documents = sorted({str(row["document_id"]) for row in aggregated})
    lookup = {(row["condition"], row["checkpoint_step"], row["document_id"]): row for row in aggregated}
    generator = torch.Generator(device="cpu").manual_seed(BOOTSTRAP_SEED)
    draws = torch.randint(len(documents), (BOOTSTRAP_SAMPLES, len(documents)), generator=generator, dtype=torch.int64)
    draw_hash = integer_draw_sha256(draws)
    if draw_hash != BOOTSTRAP_DRAW_SHA256:
        raise RuntimeError("#123 paired bootstrap integer schedule drifted")
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    replicates: dict[str, dict[str, torch.Tensor]] = {condition: {} for condition in CONDITIONS}
    for condition in CONDITIONS:
        curve = []
        for step in CHECKPOINT_STEPS:
            totals = torch.tensor([float(lookup[(condition, step, doc)]["mean_total_nll"]) for doc in documents], dtype=torch.float64)
            counts = torch.tensor([int(lookup[(condition, step, doc)]["original_byte_count"]) for doc in documents], dtype=torch.float64)
            curve.append(totals[draws].sum(1) / counts[draws].sum(1))
        values = torch.stack(curve, dim=1)
        replicates[condition] = {"final": values[:, -1], "aulc": torch.trapezoid(values, fractions, dim=1)}
    point: dict[str, dict[str, float]] = {outcome: {} for outcome in OUTCOMES}
    intervals: dict[str, dict[str, Any]] = {outcome: {} for outcome in OUTCOMES}
    per_alpha = FAMILYWISE_ALPHA / DECISION_FAMILY_SIZE
    quantiles = torch.tensor((per_alpha / 2, 1 - per_alpha / 2), dtype=torch.float64)
    for outcome in OUTCOMES:
        for name, terms in CONTRAST_DEFINITIONS.items():
            point[outcome][name] = math.fsum(coefficient * outcomes[condition][outcome] for condition, coefficient in terms)
            values = sum(coefficient * replicates[condition][outcome] for condition, coefficient in terms)
            lower, upper = torch.quantile(values, quantiles)
            intervals[outcome][name] = {
                "point": point[outcome][name],
                "lower": float(lower),
                "upper": float(upper),
                "confidence": 1 - per_alpha,
                "familywise_confidence": 1 - FAMILYWISE_ALPHA,
                "resampling_unit": "source-document",
                "seed_aggregation": "within-document fixed-seed mean",
                "bootstrap_samples": BOOTSTRAP_SAMPLES,
            }
    return {
        "schema_version": "log-polar-no-composition-statistics/v1",
        "issue": ISSUE_NUMBER,
        "condition_outcomes": outcomes,
        "contrast_definitions": {
            name: [{"condition": condition, "coefficient": coefficient} for condition, coefficient in terms]
            for name, terms in CONTRAST_DEFINITIONS.items()
        },
        "contrasts": intervals,
        "bootstrap": {
            "method": "paired percentile source-document block bootstrap; fixed seeds averaged within document; shared draws across conditions/checkpoints",
            "samples": BOOTSTRAP_SAMPLES,
            "seed": BOOTSTRAP_SEED,
            "draws_sha256": draw_hash,
            "familywise_alpha": FAMILYWISE_ALPHA,
            "decision_family_size": DECISION_FAMILY_SIZE,
            "per_interval_two_sided_alpha": per_alpha,
        },
        "thresholds": {
            "material_nats_per_original_byte": DEFAULT_CONFIG.material_nll_threshold,
            "equivalence_nats_per_original_byte": DEFAULT_CONFIG.equivalence_nll_margin,
        },
    }


def seed_contrasts(cells: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, float]]:
    by_key = {(str(cell["condition"]), int(cell["seed"])): float(cell["final_evaluation"]["byte_normalized_nll"]) for cell in cells}
    output: dict[str, dict[str, float]] = {}
    for seed in DOWNSTREAM_SEEDS:
        output[str(seed)] = {
            name: math.fsum(coefficient * by_key[(condition, seed)] for condition, coefficient in terms)
            for name, terms in CONTRAST_DEFINITIONS.items()
        }
    return output


def classify(
    statistics: Mapping[str, Any],
    cells: Sequence[Mapping[str, Any]],
    *,
    instrumentation_passed: bool,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> dict[str, Any]:
    """Apply the preregistered issue #162 ADVANCE/STOP/INVALID rule."""

    if not instrumentation_passed:
        return {
            "disposition": "INVALID-INSTRUMENTATION",
            "advance_issue_163": False,
            "reason": "one or more fail-closed instrumentation gates failed; language outcomes are not scientific observations",
        }
    final = statistics["contrasts"]["final"]
    per_seed = seed_contrasts(cells)
    parameter_counts = {int(cell["parameter_ledger"]["total_parameters"]) for cell in cells}
    dense_flops = {int(cell["flop_ledger"]["dense_training_flops_estimate"]) for cell in cells}
    overhead = max(float(cell["flop_ledger"]["polar_elementwise_overhead_fraction_of_dense_forward"]) for cell in cells)
    pooled_material = (
        float(final["polar_gain"]["upper"]) <= -config.material_nll_threshold
        and float(final["polar_native_vs_coordinate"]["upper"]) <= -config.material_nll_threshold
    )
    seed_consistent = all(
        values["polar_gain"] <= -config.material_nll_threshold
        and values["polar_native_vs_coordinate"] <= -config.material_nll_threshold
        for values in per_seed.values()
    )
    cost_matched = len(parameter_counts) == 1 and len(dense_flops) == 1 and overhead <= config.max_polar_elementwise_overhead_fraction
    advance = pooled_material and seed_consistent and cost_matched
    return {
        "disposition": "ADVANCE" if advance else "STOP",
        "advance_issue_163": advance,
        "reason": (
            "polar-native gain is material, seed-consistent, parameter/compute matched, and remains material versus the coordinate-only control"
            if advance else
            "the polar-native arm did not satisfy every preregistered materiality, seed-consistency, coordinate-control, and cost-matching gate"
        ),
        "gates": {
            "pooled_material_vs_spectral_cartesian": float(final["polar_gain"]["upper"]) <= -config.material_nll_threshold,
            "pooled_material_vs_coordinate_control": float(final["polar_native_vs_coordinate"]["upper"]) <= -config.material_nll_threshold,
            "every_seed_material_on_both_contrasts": seed_consistent,
            "equal_parameter_counts": len(parameter_counts) == 1,
            "equal_dense_training_flops": len(dense_flops) == 1,
            "polar_elementwise_overhead_within_one_percent": overhead <= config.max_polar_elementwise_overhead_fraction,
        },
        "per_seed_contrasts": per_seed,
        "observed_parameter_counts": sorted(parameter_counts),
        "observed_dense_training_flops": sorted(dense_flops),
        "maximum_polar_elementwise_overhead_fraction": overhead,
    }


def distribution_summary(auxiliary: Mapping[str, torch.Tensor], time_mask: torch.Tensor) -> dict[str, Any]:
    active = auxiliary["complex_active"] & time_mask[..., None]
    rho = auxiliary["rho"][active].to(torch.float64)
    theta = auxiliary["theta"][active].to(torch.float64)
    if rho.numel() < 1:
        raise ValueError("polar distribution is empty")
    quantiles = torch.tensor((0.0, 0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99, 1.0), dtype=torch.float64)
    phase_bins = torch.linspace(-math.pi, math.pi, 17, dtype=torch.float64)
    return {
        "active_complex_values": int(rho.numel()),
        "log_radius_quantiles": {str(float(q)): float(value) for q, value in zip(quantiles, torch.quantile(rho, quantiles), strict=True)},
        "phase_quantiles": {str(float(q)): float(value) for q, value in zip(quantiles, torch.quantile(theta, quantiles), strict=True)},
        "phase_histogram_16_bins": torch.histogram(theta, bins=phase_bins).hist.to(torch.int64).tolist(),
        "phase_bin_edges": phase_bins.tolist(),
        "phase_minimum": float(theta.min()),
        "phase_maximum": float(theta.max()),
        "canonical_interval": "[-pi,pi)",
        "values_at_negative_pi": int(torch.isclose(theta, torch.tensor(-math.pi, dtype=torch.float64), atol=1e-7).sum()),
        "values_at_positive_pi": int(torch.isclose(theta, torch.tensor(math.pi, dtype=torch.float64), atol=1e-7).sum()),
    }


def run_synthetic_controls(config: LogPolarConfig = DEFAULT_CONFIG) -> dict[str, Any]:
    """Cheap fail-closed checks that must pass before qualifying LM training."""

    config.validate()
    generator = torch.Generator().manual_seed(162_001)
    packed = torch.randn(5, 7, config.dimension, generator=generator, dtype=torch.float64)
    packed[0, 0] = 0
    packed[0, 1] = 0
    packed[0, 1, 0] = 1e-12
    packed.requires_grad_(True)
    rho, theta = complex_to_log_polar(packed, epsilon=config.log_radius_epsilon)
    reconstruction = log_polar_to_complex(rho, theta, epsilon=config.log_radius_epsilon)
    roundtrip = float((reconstruction - packed).abs().max().detach().item())
    loss = rho.square().mean() + theta.sin().square().mean()
    loss.backward()
    finite_coordinate_gradients = packed.grad is not None and bool(torch.isfinite(packed.grad).all().item())

    boundary = torch.tensor(
        [[-1.0, -1.0, 1e-9, -1e-9]], dtype=torch.float64,
    )
    boundary_rho, boundary_theta = complex_to_log_polar(boundary, epsilon=config.log_radius_epsilon)
    del boundary_rho
    wrap_distance = float(abs(
        math.atan2(
            math.sin(float(boundary_theta[0, 0] - boundary_theta[0, 1])),
            math.cos(float(boundary_theta[0, 0] - boundary_theta[0, 1])),
        )
    ))

    mask = torch.ones(2, 9, dtype=torch.bool)
    states = torch.randn(2, 9, config.canonical_width, generator=generator)
    altered = states.clone()
    altered[:, 6:] = torch.randn(2, 3, config.canonical_width, generator=generator)
    cartesian = build_matched_predictor("spectral_coordinate_cartesian", 17, config)
    polar = build_matched_predictor("spectral_polar", 17, config)
    equal_parameters = parameter_count(cartesian) == parameter_count(polar)
    matched_initialization = module_state_fingerprint(cartesian) == module_state_fingerprint(polar)
    cartesian.eval()
    polar.eval()
    with torch.no_grad():
        prefix_left = polar(states, mask).logits[:, :6]
        prefix_right = polar(altered, mask).logits[:, :6]
    prefix_max = float((prefix_left - prefix_right).abs().max().item())

    differentiable = states.clone().requires_grad_(True)
    early_logit = polar(differentiable, mask).logits[:, 4].sum()
    future_gradient = torch.autograd.grad(early_logit, differentiable)[0][:, 5:]
    future_gradient_max = float(future_gradient.abs().max().item())
    finite_representative = bool(torch.isfinite(polar(states, mask).logits).all().item())
    overhead_fraction = polar_elementwise_operations(2, 9, config) / dense_forward_flops(2, 9, config)
    passed = (
        roundtrip <= 1e-9
        and finite_coordinate_gradients
        and wrap_distance <= 3e-9
        and prefix_max <= 1e-6
        and future_gradient_max <= 1e-10
        and equal_parameters
        and matched_initialization
        and finite_representative
        and overhead_fraction <= config.max_polar_elementwise_overhead_fraction
    )
    return {
        "schema_version": "log-polar-synthetic-controls/v1",
        "passed": passed,
        "roundtrip_max_absolute_error": roundtrip,
        "finite_coordinate_gradients": finite_coordinate_gradients,
        "zero_rho": float(rho[0, 0, 0].detach()),
        "zero_theta": float(theta[0, 0, 0].detach()),
        "near_zero_rho": float(rho[0, 1, 0].detach()),
        "near_zero_theta": float(theta[0, 1, 0].detach()),
        "canonical_theta_minimum": float(theta.min().detach()),
        "canonical_theta_maximum": float(theta.max().detach()),
        "boundary_circular_distance": wrap_distance,
        "causal_prefix_max_absolute_difference": prefix_max,
        "future_gradient_max_absolute": future_gradient_max,
        "equal_parameter_counts": equal_parameters,
        "matched_initialization": matched_initialization,
        "finite_representative_logits": finite_representative,
        "polar_elementwise_overhead_fraction": overhead_fraction,
    }


__all__ = [
    "BOOTSTRAP_DRAW_SHA256", "CHECKPOINT_STEPS", "CONDITIONS", "CONTRAST_DEFINITIONS",
    "DEFAULT_CONFIG", "DOWNSTREAM_SEEDS", "LogPolarConfig", "PhaseAwareCausalTransformer",
    "PreparedCondition", "aggregate_outcomes", "build_matched_predictor", "canonical_json",
    "canonicalize", "classify", "complex_to_log_polar", "config_digest", "config_wire",
    "dense_forward_flops", "digest", "distribution_summary", "fit_condition", "fit_scalar_rms",
    "fixture_config", "log_polar_features", "log_polar_to_complex", "paired_document_bootstrap",
    "parameter_count", "polar_elementwise_operations", "prepare_conditions", "run_synthetic_controls",
    "seed_contrasts",
]
