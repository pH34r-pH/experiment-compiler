"""Data quality, provenance, tokenization, packing, and masking primitives."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
import re
import unicodedata
from typing import Iterable


@dataclass(frozen=True)
class CorpusRecord:
    text: str
    source: str
    weight: float = 1.0

    @property
    def fingerprint(self) -> str:
        return sha256(normalize_text(self.text).encode()).hexdigest()


@dataclass(frozen=True)
class Rejection:
    fingerprint: str
    source: str
    reason: str


@dataclass(frozen=True)
class DatasetManifest:
    """Versioned, auditable description of a materialized training dataset."""
    version: str
    records: tuple[CorpusRecord, ...]
    rejections: tuple[Rejection, ...] = ()

    @property
    def digest(self) -> str:
        payload = "\n".join(f"{r.source}\t{r.weight}\t{r.fingerprint}" for r in self.records)
        return sha256((self.version + "\n" + payload).encode()).hexdigest()


def normalize_text(text: str) -> str:
    """Canonicalize Unicode and whitespace; preserves meaningful characters."""
    return " ".join(unicodedata.normalize("NFKC", text).split())


def filter_and_deduplicate(records: list[CorpusRecord], *, min_chars: int = 1) -> list[CorpusRecord]:
    seen: set[str] = set()
    clean: list[CorpusRecord] = []
    for record in records:
        text = normalize_text(record.text)
        if len(text) < min_chars or text in seen:
            continue
        seen.add(text)
        clean.append(CorpusRecord(text, record.source, record.weight))
    return clean


def _word_shingles(text: str, width: int = 2) -> set[tuple[str, ...]]:
    words = re.findall(r"\w+", normalize_text(text).lower())
    return {tuple(words[i:i + width]) for i in range(max(0, len(words) - width + 1))} or {tuple(words)}


def near_duplicate(a: str, b: str, *, threshold: float = 0.8) -> bool:
    """Deterministic word-shingle Jaccard check suitable for a tiny-lab baseline."""
    left, right = _word_shingles(a), _word_shingles(b)
    return len(left & right) / len(left | right) >= threshold


def build_manifest(records: Iterable[CorpusRecord], *, version: str, min_chars: int = 8, near_threshold: float = 0.8) -> DatasetManifest:
    accepted: list[CorpusRecord] = []
    rejected: list[Rejection] = []
    exact: set[str] = set()
    for record in records:
        text = normalize_text(record.text)
        fingerprint = sha256(text.encode()).hexdigest()
        if len(text) < min_chars:
            rejected.append(Rejection(fingerprint, record.source, "too_short")); continue
        if text in exact:
            rejected.append(Rejection(fingerprint, record.source, "exact_duplicate")); continue
        if any(near_duplicate(text, prior.text, threshold=near_threshold) for prior in accepted):
            rejected.append(Rejection(fingerprint, record.source, "near_duplicate")); continue
        exact.add(text); accepted.append(CorpusRecord(text, record.source, record.weight))
    return DatasetManifest(version, tuple(accepted), tuple(rejected))


def mix_records(records: list[CorpusRecord]) -> list[CorpusRecord]:
    """Deterministic weighted interleaving, retaining source provenance."""
    return sorted(filter_and_deduplicate(records), key=lambda r: (-r.weight, r.source, r.fingerprint))


def sample_mixture(records: list[CorpusRecord], n: int, *, seed: int = 0) -> tuple[list[CorpusRecord], dict[str, float]]:
    """Weighted sampling with replacement and a realized-source audit trail."""
    import random
    if not records or n < 1: raise ValueError("records and n must be non-empty")
    rng = random.Random(seed)
    sample = rng.choices(records, weights=[r.weight for r in records], k=n)
    counts = Counter(r.source for r in sample)
    return sample, {source: count / n for source, count in sorted(counts.items())}


def contamination_hits(train: Iterable[CorpusRecord], evaluation: Iterable[CorpusRecord]) -> set[str]:
    train_fingerprints = {r.fingerprint for r in train}
    return {r.fingerprint for r in evaluation if r.fingerprint in train_fingerprints}


class DeterministicCharTokenizer:
    """A deliberately transparent character baseline with stable special IDs."""
    pad_id, bos_id, eos_id, unk_id = range(4)

    def __init__(self, vocab: dict[str, int]):
        self.vocab = vocab
        self.inverse_vocab = {v: k for k, v in vocab.items()}

    @classmethod
    def fit(cls, texts: list[str]) -> "DeterministicCharTokenizer":
        chars = sorted(set("".join(normalize_text(text) for text in texts)))
        return cls({char: i + 4 for i, char in enumerate(chars)})

    @property
    def vocab_size(self) -> int:
        return len(self.vocab) + 4

    def encode(self, text: str, *, add_special_tokens: bool = True) -> list[int]:
        ids = [self.vocab.get(c, self.unk_id) for c in normalize_text(text)]
        return ([self.bos_id] + ids + [self.eos_id]) if add_special_tokens else ids

    def decode(self, ids: list[int]) -> str:
        return "".join(self.inverse_vocab.get(i, "") for i in ids if i >= 4)


def pack_token_sequences(sequences: list[list[int]], block_size: int, pad_id: int = 0) -> tuple[list[list[int]], list[list[bool]]]:
    if block_size < 2:
        raise ValueError("block_size must be at least 2")
    tokens = [token for sequence in sequences for token in sequence]
    blocks, masks = [], []
    for start in range(0, len(tokens), block_size):
        block = tokens[start:start + block_size]
        valid = [True] * len(block)
        if len(block) < block_size:
            block += [pad_id] * (block_size - len(block))
            valid += [False] * (block_size - len(valid))
        blocks.append(block); masks.append(valid)
    return blocks, masks


def bpe_pair_counts(words: list[tuple[str, ...]]) -> Counter[tuple[str, str]]:
    return Counter(pair for word in words for pair in zip(word, word[1:]))

