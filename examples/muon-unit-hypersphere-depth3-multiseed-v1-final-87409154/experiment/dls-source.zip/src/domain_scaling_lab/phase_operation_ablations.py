"""Issue #163: phase-preserving operation ablations around the frozen #162 LM.

The qualifying #162 model changed exactly one scientific operation: its Q/K
attention score.  Values, residuals, normalization, feed-forward computation,
and the byte head remained Cartesian.  This module keeps that model as the
phase-attention-only arm, adds an unfused Cartesian recomposition control, and
tests parameter-free residual and explicit-log-radius operations without
changing the transmitter, input map, optimizer, data, width, depth, or budget.
"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import replace
import math
import resource
import sys
import time
from typing import Any, Literal

import torch
from torch import nn
from torch.nn import functional as F

from .log_polar_no_composition import (
    BOOTSTRAP_DRAW_SHA256,
    CHECKPOINT_STEPS,
    DEFAULT_CONFIG,
    DOWNSTREAM_SEEDS,
    BUDGET_FRACTIONS,
    LogPolarConfig,
    PhaseAwareCausalTransformer,
    PreparedCondition,
    canonical_json,
    dense_forward_flops,
    digest,
    polar_elementwise_operations,
    prepare_conditions,
)
from .oracle_no_composition import (
    CausalTransformerNextBytePredictor,
    PredictorOutput,
    _fixed_sinusoid,
    parameter_count,
)
from .oracle_no_composition_stats import integer_draw_sha256
from .spectral import TextBatch, module_state_fingerprint


ISSUE_NUMBER = 163
SCHEMA_VERSION = "phase-operation-ablations/v1"
TRAINED_CONDITIONS = (
    "spectral_coordinate_cartesian",
    "spectral_manual_cartesian",
    "spectral_phase_attention_only",
    "spectral_phase_residual_only",
    "spectral_log_radius_only",
)
STATISTICAL_CONDITIONS = ("spectral_cartesian",) + TRAINED_CONDITIONS
ATTENTION_ONLY = "spectral_phase_attention_only"
FULL_162_CONDITION = ATTENTION_ONLY
COORDINATE_CONTROL = "spectral_coordinate_cartesian"
MANUAL_CONTROL = "spectral_manual_cartesian"
RESIDUAL_ONLY = "spectral_phase_residual_only"
LOG_RADIUS_ONLY = "spectral_log_radius_only"
OUTCOMES = ("final", "aulc")
MATERIAL_NLL = 0.01
EQUIVALENCE_NLL = 0.005
FAMILYWISE_ALPHA = 0.05
BOOTSTRAP_SAMPLES = 65_536
BOOTSTRAP_SEED = 12_365_536
RESIDUAL_EPSILON = 1e-6
COLLAPSE_RADIUS = 1e-6
EXPLOSION_RADIUS = 1e3
EXPLOSION_RATIO = 100.0
RECOMPOSITION_TOLERANCE = 1e-7
QUALIFYING_REPLAY_NLL_TOLERANCE = 1e-7
MAX_NONDENSE_OVERHEAD_FRACTION = 0.01


# Negative means the first/named operation has lower (better) NLL.  The
# manual-path contrasts are an additional fail-closed bundling control.
CONTRAST_DEFINITIONS: Mapping[str, tuple[tuple[str, float], ...]] = {
    "manual_path_vs_coordinate": ((MANUAL_CONTROL, 1.0), (COORDINATE_CONTROL, -1.0)),
    "attention_vs_coordinate": ((ATTENTION_ONLY, 1.0), (COORDINATE_CONTROL, -1.0)),
    "residual_vs_coordinate": ((RESIDUAL_ONLY, 1.0), (COORDINATE_CONTROL, -1.0)),
    "log_radius_vs_coordinate": ((LOG_RADIUS_ONLY, 1.0), (COORDINATE_CONTROL, -1.0)),
    "attention_vs_manual": ((ATTENTION_ONLY, 1.0), (MANUAL_CONTROL, -1.0)),
    "residual_vs_manual": ((RESIDUAL_ONLY, 1.0), (MANUAL_CONTROL, -1.0)),
    "log_radius_vs_manual": ((LOG_RADIUS_ONLY, 1.0), (MANUAL_CONTROL, -1.0)),
    "attention_vs_spectral": ((ATTENTION_ONLY, 1.0), ("spectral_cartesian", -1.0)),
    "residual_vs_spectral": ((RESIDUAL_ONLY, 1.0), ("spectral_cartesian", -1.0)),
    "log_radius_vs_spectral": ((LOG_RADIUS_ONLY, 1.0), ("spectral_cartesian", -1.0)),
    "full_162_vs_residual": ((FULL_162_CONDITION, 1.0), (RESIDUAL_ONLY, -1.0)),
    "full_162_vs_log_radius": ((FULL_162_CONDITION, 1.0), (LOG_RADIUS_ONLY, -1.0)),
}
DECISION_FAMILY_SIZE = len(CONTRAST_DEFINITIONS) * len(OUTCOMES)


def condition_operation_config(condition: str) -> dict[str, Any]:
    matrix = {
        COORDINATE_CONTROL: {
            "attention": "torch-transformer-cartesian",
            "attention_residual": "cartesian",
            "log_radius_update": "ordinary-hidden-state",
            "execution_path": "exact-162-coordinate-control",
        },
        MANUAL_CONTROL: {
            "attention": "manual-cartesian-dot",
            "attention_residual": "cartesian",
            "log_radius_update": "ordinary-hidden-state",
            "execution_path": "unfused-162-matched",
        },
        ATTENTION_ONLY: {
            "attention": "162-radial-plus-real-hermitian-angular",
            "attention_residual": "cartesian",
            "log_radius_update": "ordinary-hidden-state",
            "execution_path": "exact-recomposition-of-full-162",
        },
        RESIDUAL_ONLY: {
            "attention": "manual-cartesian-dot",
            "attention_residual": "separate-radial-angular-geodesic",
            "log_radius_update": "ordinary-hidden-state",
            "execution_path": "unfused-162-matched",
        },
        LOG_RADIUS_ONLY: {
            "attention": "manual-cartesian-dot",
            "attention_residual": "cartesian",
            "log_radius_update": "explicit-additive-rho-channels-0-15",
            "execution_path": "unfused-162-matched",
        },
    }
    if condition not in matrix:
        raise ValueError(f"unknown #163 condition {condition!r}")
    return matrix[condition]


def minimal_block_wire(condition: str) -> dict[str, Any]:
    if condition not in (ATTENTION_ONLY, RESIDUAL_ONLY, LOG_RADIUS_ONLY):
        raise ValueError("minimal block must be one isolated operation arm")
    return {
        "schema_version": "minimal-polar-block/v1",
        "source_issue": 163,
        "condition": condition,
        "input": "exact #162 [rho,cos(theta),sin(theta),zero-pad] tensor",
        "width": 128,
        "depth": 1,
        "heads": 4,
        "operation": condition_operation_config(condition),
        "trainable_adapter": False,
        "parameter_delta_vs_162": 0,
        "spectral_composition": False,
        "spherical_shells": False,
    }


def minimal_block_digest(condition: str) -> str:
    return digest(minimal_block_wire(condition))


def _split_complex_direction(states: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    if states.size(-1) != 128:
        raise ValueError("#163 residual semantics require frozen width 128")
    return states[..., 16:32], states[..., 32:48]


def phase_preserving_residual_pairs(
    real: torch.Tensor,
    imag: torch.Tensor,
    delta_real: torch.Tensor,
    delta_imag: torch.Tensor,
    *,
    epsilon: float = RESIDUAL_EPSILON,
) -> tuple[torch.Tensor, torch.Tensor, dict[str, torch.Tensor]]:
    """Apply a parameter-free radial/angular residual to complex pairs.

    The proposed Cartesian update is decomposed at the current direction.
    Its radial projection changes magnitude; its angular component changes
    direction through the proposed target.  Tangential motion therefore does
    not create second-order magnitude inflation.  At zero/near-zero radius a
    finite canonical direction (1,0) is used.  Negative radial candidates are
    clamped to zero; this rule is preregistered and counted diagnostically.
    """

    if not (real.shape == imag.shape == delta_real.shape == delta_imag.shape):
        raise ValueError("phase residual tensors must share a shape")
    if epsilon <= 0:
        raise ValueError("phase residual epsilon must be positive")
    radius_squared = real.square() + imag.square()
    radius = torch.sqrt(radius_squared.clamp_min(epsilon ** 2))
    active = radius_squared > epsilon ** 2
    unit_real = torch.where(active, real / radius, torch.ones_like(real))
    unit_imag = torch.where(active, imag / radius, torch.zeros_like(imag))

    target_real = real + delta_real
    target_imag = imag + delta_imag
    target_squared = target_real.square() + target_imag.square()
    target_radius = torch.sqrt(target_squared.clamp_min(epsilon ** 2))
    target_active = target_squared > epsilon ** 2
    direction_real = torch.where(target_active, target_real / target_radius, unit_real)
    direction_imag = torch.where(target_active, target_imag / target_radius, unit_imag)

    radial_delta = unit_real * delta_real + unit_imag * delta_imag
    radius_candidate = torch.where(active, radius, torch.zeros_like(radius)) + radial_delta
    new_radius = radius_candidate.clamp_min(0.0)
    new_real = new_radius * direction_real
    new_imag = new_radius * direction_imag

    base_theta = torch.atan2(unit_imag, unit_real)
    new_theta = torch.atan2(direction_imag, direction_real)
    angular_delta = torch.atan2(
        torch.sin(new_theta - base_theta), torch.cos(new_theta - base_theta),
    )
    diagnostics = {
        "base_radius": torch.where(active, radius, torch.zeros_like(radius)),
        "radial_delta": radial_delta,
        "radius_candidate": radius_candidate,
        "new_radius": new_radius,
        "angular_delta": angular_delta,
        "base_theta": base_theta,
        "new_theta": new_theta,
        "base_active": active,
        "target_active": target_active,
        "radius_clamped": radius_candidate < 0,
    }
    if any(not torch.isfinite(value).all() for value in (new_real, new_imag, *diagnostics.values()) if value.dtype != torch.bool):
        raise FloatingPointError("non-finite phase-preserving residual")
    return new_real, new_imag, diagnostics


def explicit_log_radius_residual(states: torch.Tensor, delta: torch.Tensor) -> torch.Tensor:
    """Make the already-additive rho update explicit without another change.

    The exact #162 coordinate tensor stores rho in channels 0..15.  Ordinary
    residual addition is already additive in those values.  This arm spells
    that operation out and concatenates the untouched Cartesian remainder;
    it is expected to be bit-identical to the manual Cartesian control.  A
    difference is an instrumentation defect, not a language observation.
    """

    if states.shape != delta.shape or states.size(-1) != 128:
        raise ValueError("explicit rho residual inputs drifted")
    return torch.cat((states[..., :16] + delta[..., :16], states[..., 16:] + delta[..., 16:]), dim=-1)


class ComposablePolarTransformer(CausalTransformerNextBytePredictor):
    """One-layer matched Transformer with independently selectable operations."""

    def __init__(
        self,
        width: int = 128,
        heads: int = 4,
        layers: int = 1,
        *,
        attention_mode: Literal["manual_cartesian", "hermitian"] = "manual_cartesian",
        residual_mode: Literal["cartesian", "phase_preserving", "log_radius"] = "cartesian",
        angular_epsilon: float = 1e-6,
        residual_epsilon: float = RESIDUAL_EPSILON,
    ):
        if layers != 1 or width != 128 or heads != 4:
            raise ValueError("#163 preserves #162 width 128/depth 1/heads 4")
        if attention_mode not in {"manual_cartesian", "hermitian"}:
            raise ValueError("invalid attention mode")
        if residual_mode not in {"cartesian", "phase_preserving", "log_radius"}:
            raise ValueError("invalid residual mode")
        super().__init__(width=width, heads=heads, layers=layers)
        self.heads = int(heads)
        self.attention_mode = attention_mode
        self.residual_mode = residual_mode
        self.angular_epsilon = float(angular_epsilon)
        self.residual_epsilon = float(residual_epsilon)

    @property
    def architecture(self) -> str:
        return f"composable-polar-{self.attention_mode}-{self.residual_mode}"

    def _attention(
        self,
        x: torch.Tensor,
        time_mask: torch.Tensor,
        *,
        collect: bool = False,
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor] | None]:
        attention = self.backbone.decoder.layers[0].self_attn
        batch, time_steps, width = x.shape
        head_width = width // self.heads
        qkv = F.linear(x, attention.in_proj_weight, attention.in_proj_bias)
        query, key, value = qkv.chunk(3, dim=-1)

        def heads(tensor: torch.Tensor) -> torch.Tensor:
            return tensor.reshape(batch, time_steps, self.heads, head_width).transpose(1, 2)

        query, key, value = heads(query), heads(key), heads(value)
        raw_query, raw_key = query, key
        if self.attention_mode == "hermitian":
            radial_width = head_width // 2

            def preserve_phase(tensor: torch.Tensor) -> torch.Tensor:
                radial, angular = tensor.split((radial_width, head_width - radial_width), dim=-1)
                pairs = angular.reshape(*angular.shape[:-1], -1, 2)
                norm = torch.sqrt(pairs.square().sum(dim=-1, keepdim=True) + self.angular_epsilon ** 2)
                unit = math.sqrt(2.0) * pairs / norm
                return torch.cat((radial, unit.flatten(start_dim=-2)), dim=-1)

            score_query, score_key = preserve_phase(query), preserve_phase(key)
        else:
            score_query, score_key = query, key
        scores = torch.matmul(score_query, score_key.transpose(-2, -1)) / math.sqrt(head_width)
        causal = torch.ones(time_steps, time_steps, device=x.device, dtype=torch.bool).triu(1)
        scores = scores.masked_fill(causal[None, None], float("-inf"))
        scores = scores.masked_fill(~time_mask[:, None, None, :], float("-inf"))
        weights = torch.softmax(scores, dim=-1)
        context = torch.matmul(weights, value).transpose(1, 2).contiguous().reshape(batch, time_steps, width)
        output = F.linear(context, attention.out_proj.weight, attention.out_proj.bias)
        if not torch.isfinite(output).all():
            raise FloatingPointError("non-finite #163 attention output")
        collected = None
        if collect:
            collected = {
                "raw_query": raw_query,
                "raw_key": raw_key,
                "attention_weights": weights,
                "attention_scores": scores,
            }
        return output, collected

    def _attention_residual(
        self,
        x: torch.Tensor,
        delta: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor] | None]:
        if self.residual_mode == "cartesian":
            return x + delta, None
        if self.residual_mode == "log_radius":
            return explicit_log_radius_residual(x, delta), None
        real, imag = _split_complex_direction(x)
        delta_real, delta_imag = _split_complex_direction(delta)
        new_real, new_imag, diagnostics = phase_preserving_residual_pairs(
            real, imag, delta_real, delta_imag, epsilon=self.residual_epsilon,
        )
        residual = torch.cat((
            x[..., :16] + delta[..., :16],
            new_real,
            new_imag,
            x[..., 48:] + delta[..., 48:],
        ), dim=-1)
        return residual, diagnostics

    def _forward_stages(
        self,
        states: torch.Tensor,
        time_mask: torch.Tensor,
        *,
        collect: bool,
    ) -> tuple[PredictorOutput, dict[str, Any]]:
        if states.ndim != 3 or tuple(time_mask.shape) != tuple(states.shape[:2]) or states.size(-1) != self.width:
            raise ValueError("#163 predictor inputs drifted")
        if not torch.isfinite(states).all():
            raise FloatingPointError("non-finite #163 predictor input")
        position = _fixed_sinusoid(states.size(1), self.width, device=states.device, dtype=states.dtype)[None]
        positioned = states.masked_fill(~time_mask[..., None], 0.0) + position
        layer = self.backbone.decoder.layers[0]
        attention_delta, attention = self._attention(positioned, time_mask, collect=collect)
        residual, residual_diagnostics = self._attention_residual(positioned, layer.dropout1(attention_delta))
        post_norm1 = layer.norm1(residual)
        feed_forward = layer.linear2(layer.dropout(layer.activation(layer.linear1(post_norm1))))
        hidden = layer.norm2(post_norm1 + layer.dropout2(feed_forward))
        hidden = hidden.masked_fill(~time_mask[..., None], 0.0)
        logits = self.backbone.head(hidden).masked_fill(~time_mask[..., None], 0.0)
        if not torch.isfinite(hidden).all() or not torch.isfinite(logits).all():
            raise FloatingPointError("non-finite #163 Transformer output")
        stages: dict[str, Any] = {}
        if collect:
            stages = {
                "coordinate_input": states,
                "positioned_input": positioned,
                "attention_delta": attention_delta,
                "post_attention_residual": residual,
                "post_norm1": post_norm1,
                "final_hidden": hidden,
                "attention": attention,
                "residual": residual_diagnostics,
            }
        return PredictorOutput(logits=logits, hidden=hidden), stages

    def forward(self, states: torch.Tensor, time_mask: torch.Tensor) -> PredictorOutput:
        output, _ = self._forward_stages(states, time_mask, collect=False)
        return output


def build_ablation_predictor(
    condition: str,
    seed: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> nn.Module:
    config.validate()
    if condition not in TRAINED_CONDITIONS or seed not in config.downstream_seeds:
        raise ValueError("non-preregistered #163 condition or seed")
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed)
        if condition == COORDINATE_CONTROL:
            model: nn.Module = CausalTransformerNextBytePredictor(
                config.canonical_width, config.heads, config.layers,
            )
        else:
            operation = condition_operation_config(condition)
            attention_mode = "hermitian" if operation["attention"].startswith("162-") else "manual_cartesian"
            residual_mode = {
                MANUAL_CONTROL: "cartesian",
                ATTENTION_ONLY: "cartesian",
                RESIDUAL_ONLY: "phase_preserving",
                LOG_RADIUS_ONLY: "log_radius",
            }[condition]
            model = ComposablePolarTransformer(
                config.canonical_width,
                config.heads,
                config.layers,
                attention_mode=attention_mode,
                residual_mode=residual_mode,
                angular_epsilon=config.angular_norm_epsilon,
                residual_epsilon=RESIDUAL_EPSILON,
            )
    return model


def prepare_ablation_conditions(
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    *,
    spectral_frontend: nn.Module,
    byte_frontend: nn.Module,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> dict[str, PreparedCondition]:
    inherited = prepare_conditions(
        calibration_batch,
        evaluation_batch,
        spectral_frontend=spectral_frontend,
        byte_frontend=byte_frontend,
        config=config,
    )
    coordinate = inherited[COORDINATE_CONTROL]
    output = {condition: replace(coordinate, name=condition) for condition in TRAINED_CONDITIONS}
    train_fingerprints = {item.canonical_train_fingerprint for item in output.values()}
    evaluation_fingerprints = {item.canonical_evaluation_fingerprint for item in output.values()}
    if len(train_fingerprints) != 1 or len(evaluation_fingerprints) != 1:
        raise RuntimeError("#163 operation arms do not share bit-identical coordinate inputs")
    return output


def residual_elementwise_operations(batch: int, time_steps: int) -> int:
    # Sixteen semantic direction pairs.  Count norms, normalizations,
    # projections, clamp, and recomposition; diagnostic reductions are not
    # part of the learned forward estimate.
    return int(batch * time_steps * 16 * 23)


def nondense_operations(condition: str, batch: int, time_steps: int, config: LogPolarConfig = DEFAULT_CONFIG) -> int:
    if condition == ATTENTION_ONLY:
        return polar_elementwise_operations(batch, time_steps, config)
    if condition == RESIDUAL_ONLY:
        return residual_elementwise_operations(batch, time_steps)
    return 0


def _rss_bytes() -> int:
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value if sys.platform == "darwin" else value * 1024


def _device_batch(batch: TextBatch, device: torch.device) -> TextBatch:
    return TextBatch(
        input_ids=batch.input_ids.to(device),
        targets=batch.targets.to(device),
        valid=batch.valid.to(device),
        byte_count=batch.byte_count,
        document_ids=batch.document_ids,
    )


def _summarize(values: Sequence[float]) -> dict[str, float]:
    if not values or any(not math.isfinite(value) for value in values):
        raise ValueError("cannot summarize empty/non-finite values")
    return {"minimum": min(values), "maximum": max(values), "mean": math.fsum(values) / len(values)}


def _quantiles(values: torch.Tensor) -> dict[str, float]:
    flattened = values.detach().to(torch.float64).flatten()
    if flattened.numel() < 1 or not torch.isfinite(flattened).all():
        raise ValueError("diagnostic distribution is empty or non-finite")
    qs = torch.tensor((0.0, 0.01, 0.25, 0.5, 0.75, 0.99, 1.0), dtype=torch.float64)
    return {str(float(q)): float(v) for q, v in zip(qs, torch.quantile(flattened, qs), strict=True)}


def _phase_histogram(theta: torch.Tensor) -> dict[str, Any]:
    values = theta.detach().to(torch.float64).flatten()
    edges = torch.linspace(-math.pi, math.pi, 17, dtype=torch.float64)
    return {
        "canonical_interval": "[-pi,pi)",
        "histogram_16_bins": torch.histogram(values, bins=edges).hist.to(torch.int64).tolist(),
        "bin_edges": edges.tolist(),
        "quantiles": _quantiles(values),
        "minimum": float(values.min()),
        "maximum": float(values.max()),
    }


def _pair_distribution(states: torch.Tensor, time_mask: torch.Tensor) -> dict[str, Any]:
    real, imag = _split_complex_direction(states)
    selected_real = real[time_mask]
    selected_imag = imag[time_mask]
    radius = torch.sqrt(selected_real.square() + selected_imag.square())
    theta = torch.remainder(torch.atan2(selected_imag, selected_real) + math.pi, 2 * math.pi) - math.pi
    log_radius = torch.log(radius + RESIDUAL_EPSILON)
    return {
        "radius_quantiles": _quantiles(radius),
        "log_radius_quantiles": _quantiles(log_radius),
        "phase": _phase_histogram(theta),
        "collapse_fraction": float(radius.le(COLLAPSE_RADIUS).to(torch.float64).mean()),
        "explosion_fraction_absolute": float(radius.ge(EXPLOSION_RADIUS).to(torch.float64).mean()),
        "finite": bool(torch.isfinite(radius).all() and torch.isfinite(log_radius).all() and torch.isfinite(theta).all()),
    }


def _phase_interaction_diagnostics(
    raw_query: torch.Tensor,
    raw_key: torch.Tensor,
    weights: torch.Tensor,
    time_mask: torch.Tensor,
) -> dict[str, Any]:
    head_width = raw_query.size(-1)
    query_pairs = raw_query[..., head_width // 2:].reshape(*raw_query.shape[:-1], -1, 2)
    key_pairs = raw_key[..., head_width // 2:].reshape(*raw_key.shape[:-1], -1, 2)
    query_theta = torch.atan2(query_pairs[..., 1], query_pairs[..., 0])
    key_theta = torch.atan2(key_pairs[..., 1], key_pairs[..., 0])
    difference = query_theta[:, :, :, None, :] - key_theta[:, :, None, :, :]
    difference = torch.remainder(difference + math.pi, 2 * math.pi) - math.pi
    time_steps = time_mask.size(1)
    allowed = (
        time_mask[:, None, :, None]
        & time_mask[:, None, None, :]
        & torch.ones(time_steps, time_steps, device=time_mask.device, dtype=torch.bool).tril()[None, None]
    )
    allowed = allowed.expand(-1, raw_query.size(1), -1, -1)
    selected = difference[allowed[..., None].expand_as(difference)]
    absolute = selected.abs()
    tolerance = math.pi / 8
    aligned = absolute <= tolerance
    opposed = (absolute - math.pi).abs() <= tolerance
    quadrature = (absolute - math.pi / 2).abs() <= tolerance
    pair_count = difference.size(-1)
    weighted = weights[..., None].expand_as(difference)
    allowed_weighted = weighted[allowed[..., None].expand_as(difference)]
    denominator = float(allowed_weighted.sum().item())
    return {
        "phase_difference": _phase_histogram(selected),
        "alignment_fraction": float(aligned.to(torch.float64).mean()),
        "opposition_fraction": float(opposed.to(torch.float64).mean()),
        "quadrature_fraction": float(quadrature.to(torch.float64).mean()),
        "attention_weighted_alignment_fraction": float((allowed_weighted * aligned).sum().item() / denominator),
        "attention_weighted_opposition_fraction": float((allowed_weighted * opposed).sum().item() / denominator),
        "attention_weighted_quadrature_fraction": float((allowed_weighted * quadrature).sum().item() / denominator),
        "valid_query_key_pair_channels": int(selected.numel()),
        "angular_pairs_per_head": pair_count,
        "finite": bool(torch.isfinite(selected).all() and math.isfinite(denominator) and denominator > 0),
    }


def mechanism_diagnostics(
    model: nn.Module,
    states: torch.Tensor,
    time_mask: torch.Tensor,
) -> dict[str, Any]:
    if isinstance(model, ComposablePolarTransformer):
        output, stages = model._forward_stages(states, time_mask, collect=True)
        attention = stages["attention"]
        phase_interactions = _phase_interaction_diagnostics(
            attention["raw_query"], attention["raw_key"], attention["attention_weights"], time_mask,
        )
        proposed_real, proposed_imag = _split_complex_direction(stages["positioned_input"] + stages["attention_delta"])
        base_real, base_imag = _split_complex_direction(stages["positioned_input"])
        applied_real, applied_imag = _split_complex_direction(stages["post_attention_residual"])
        base_radius = torch.sqrt(base_real.square() + base_imag.square())
        applied_radius = torch.sqrt(applied_real.square() + applied_imag.square())
        proposed_theta = torch.atan2(proposed_imag, proposed_real)
        base_theta = torch.atan2(base_imag, base_real)
        applied_theta = torch.atan2(applied_imag, applied_real)
        applied_angular = torch.atan2(torch.sin(applied_theta - base_theta), torch.cos(applied_theta - base_theta))
        base_active = time_mask[..., None] & base_radius.gt(RESIDUAL_EPSILON)
        phase_wrap = (base_theta + applied_angular).ge(math.pi) | (base_theta + applied_angular).lt(-math.pi)
        radial_change = applied_radius - base_radius
        ratio = applied_radius / base_radius.clamp_min(RESIDUAL_EPSILON)
        residual_specific = stages["residual"]
        residual_summary = {
            "radial_update_signed_quantiles": _quantiles(radial_change[time_mask[..., None].expand_as(radial_change)]),
            "radial_update_absolute_quantiles": _quantiles(radial_change.abs()[time_mask[..., None].expand_as(radial_change)]),
            "angular_geodesic_absolute_quantiles": _quantiles(applied_angular.abs()[base_active]),
            "phase_wrap_frequency": float(phase_wrap[base_active].to(torch.float64).mean()),
            "magnitude_collapse_fraction": float(applied_radius[time_mask[..., None].expand_as(applied_radius)].le(COLLAPSE_RADIUS).to(torch.float64).mean()),
            "magnitude_explosion_fraction_absolute": float(applied_radius[time_mask[..., None].expand_as(applied_radius)].ge(EXPLOSION_RADIUS).to(torch.float64).mean()),
            "magnitude_explosion_fraction_ratio": float(ratio[base_active].ge(EXPLOSION_RATIO).to(torch.float64).mean()),
            "radius_clamp_frequency": (
                float(residual_specific["radius_clamped"][time_mask[..., None].expand_as(residual_specific["radius_clamped"])].to(torch.float64).mean())
                if residual_specific is not None else 0.0
            ),
            "proposed_phase": _phase_histogram(proposed_theta[time_mask[..., None].expand_as(proposed_theta)]),
            "applied_phase": _phase_histogram(applied_theta[time_mask[..., None].expand_as(applied_theta)]),
        }
        stage_names = (
            "coordinate_input", "positioned_input", "post_attention_residual", "post_norm1", "final_hidden",
        )
        distributions = {name: _pair_distribution(stages[name], time_mask) for name in stage_names}
        positioned = stages["positioned_input"]
        representation_drift = {}
        for name in stage_names:
            stage = stages[name]
            selected = stage[time_mask]
            reference = positioned[time_mask]
            representation_drift[name] = {
                "state_rms": float(selected.square().mean().sqrt().item()),
                "rms_drift_from_positioned_input": float((selected - reference).square().mean().sqrt().item()),
                "cosine_to_positioned_input": float(F.cosine_similarity(selected, reference, dim=-1).mean().item()),
            }
    else:
        output = model(states, time_mask)
        phase_interactions = None
        residual_summary = None
        distributions = {
            "coordinate_input": _pair_distribution(states, time_mask),
            "final_hidden": _pair_distribution(output.hidden, time_mask),
        }
        selected_input, selected_hidden = states[time_mask], output.hidden[time_mask]
        representation_drift = {
            "coordinate_input": {
                "state_rms": float(selected_input.square().mean().sqrt().item()),
                "rms_drift_from_positioned_input": None,
                "cosine_to_positioned_input": None,
            },
            "final_hidden": {
                "state_rms": float(selected_hidden.square().mean().sqrt().item()),
                "rms_drift_from_positioned_input": None,
                "cosine_to_positioned_input": float(F.cosine_similarity(selected_hidden, selected_input, dim=-1).mean().item()),
            },
        }
    return {
        "qk_phase_interactions": phase_interactions,
        "residual_updates": residual_summary,
        "radial_phase_distributions_by_depth": distributions,
        "representation_drift_by_depth": representation_drift,
        "all_finite": bool(torch.isfinite(output.logits).all() and torch.isfinite(output.hidden).all()),
        "stability_interventions": {
            "residual_epsilon": RESIDUAL_EPSILON,
            "negative_radius_policy": "clamp-to-zero in residual-only arm",
            "post_freeze_clipping_or_retuning": False,
        },
    }


def _document_rows(
    output: PredictorOutput,
    batch: TextBatch,
    *,
    condition: str,
    seed: int,
    step: int,
    cumulative_bytes: int,
    cumulative_dense_flops: int,
    cumulative_nondense_operations: int,
) -> list[dict[str, Any]]:
    nll = F.cross_entropy(output.logits.transpose(1, 2), batch.targets, reduction="none")
    architectures = {
        COORDINATE_CONTROL: "vanilla-transformer",
        MANUAL_CONTROL: "composable-polar-manual_cartesian-cartesian",
        ATTENTION_ONLY: "composable-polar-hermitian-cartesian",
        RESIDUAL_ONLY: "composable-polar-manual_cartesian-phase_preserving",
        LOG_RADIUS_ONLY: "composable-polar-manual_cartesian-log_radius",
    }
    rows = []
    for index, document_id in enumerate(batch.document_ids):
        count = int(batch.valid[index].sum().item())
        total = float((nll[index] * batch.valid[index]).sum(dtype=torch.float64).item())
        rows.append({
            "condition": condition,
            "architecture": architectures[condition],
            "seed": seed,
            "document_id": document_id,
            "checkpoint_step": step,
            "total_nll": total,
            "original_byte_count": count,
            "byte_normalized_nll": total / count,
            "cumulative_training_original_bytes": cumulative_bytes,
            "cumulative_training_dense_flops_estimate": cumulative_dense_flops,
            "cumulative_training_nondense_operations_estimate": cumulative_nondense_operations,
        })
    return rows


def _qk_gradient_groups(model: nn.Module) -> tuple[float, float]:
    attention = model.backbone.decoder.layers[0].self_attn
    gradient = attention.in_proj_weight.grad
    if gradient is None or not torch.isfinite(gradient).all():
        raise RuntimeError("missing/non-finite Q/K projection gradient")
    width = model.width
    heads = 4
    head_width = width // heads
    query, key = gradient[:width], gradient[width:2 * width]
    groups = []
    for value in (query, key):
        shaped = value.reshape(heads, head_width, width)
        groups.append((shaped[:, :head_width // 2], shaped[:, head_width // 2:]))
    radial = torch.cat([item[0].flatten() for item in groups])
    angular = torch.cat([item[1].flatten() for item in groups])
    return float(radial.square().mean().sqrt().item()), float(angular.square().mean().sqrt().item())


def fit_ablation_condition(
    prepared: PreparedCondition,
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    *,
    seed: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
    device: str | torch.device = "cpu",
) -> dict[str, Any]:
    """Fit one frozen-budget #163 cell and retain mechanism diagnostics."""

    config.validate()
    requested = torch.device(device)
    if requested.type != "cpu" and not torch.cuda.is_available():
        raise ValueError("requested accelerator is unavailable")
    model = build_ablation_predictor(prepared.name, seed, config).to(requested)
    initial_sha = module_state_fingerprint(model)
    train_states = prepared.train_states.to(requested).detach().requires_grad_(True)
    evaluation_states = prepared.evaluation_states.to(requested)
    train_mask = prepared.train_mask.to(requested)
    evaluation_mask = prepared.evaluation_mask.to(requested)
    train_batch = _device_batch(calibration_batch, requested)
    evaluation_batch_device = _device_batch(evaluation_batch, requested)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    train_forward = dense_forward_flops(train_states.size(0), train_states.size(1), config)
    eval_forward = dense_forward_flops(evaluation_states.size(0), evaluation_states.size(1), config)
    train_nondense = nondense_operations(prepared.name, train_states.size(0), train_states.size(1), config)
    eval_nondense = nondense_operations(prepared.name, evaluation_states.size(0), evaluation_states.size(1), config)
    trace: list[dict[str, Any]] = []
    train_curve: list[dict[str, Any]] = []
    checkpoint_ledger: list[dict[str, Any]] = []
    gradient_norms: list[float] = []
    update_norms: list[float] = []
    rho_gradients: list[float] = []
    theta_gradients: list[float] = []
    qk_radial_gradients: list[float] = []
    qk_angular_gradients: list[float] = []
    initial_rss = _rss_bytes()
    training_elapsed = 0.0
    total_started = time.perf_counter()

    def evaluate(step: int) -> None:
        model.eval()
        started = time.perf_counter()
        with torch.no_grad():
            output = model(evaluation_states, evaluation_mask)
            rows = _document_rows(
                output,
                evaluation_batch_device,
                condition=prepared.name,
                seed=seed,
                step=step,
                cumulative_bytes=calibration_batch.byte_count * step,
                cumulative_dense_flops=3 * train_forward * step,
                cumulative_nondense_operations=3 * train_nondense * step,
            )
        elapsed = max(time.perf_counter() - started, 1e-12)
        trace.extend(rows)
        total = math.fsum(row["total_nll"] for row in rows)
        count = sum(row["original_byte_count"] for row in rows)
        checkpoint_ledger.append({
            "checkpoint_step": step,
            "total_nll": total,
            "original_byte_count": count,
            "byte_normalized_nll": total / count,
            "elapsed_seconds": elapsed,
            "original_bytes_per_second": count / elapsed,
            "model_state_sha256": module_state_fingerprint(model),
        })

    evaluate(0)
    for step in range(1, config.updates + 1):
        started = time.perf_counter()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        train_states.grad = None
        output = model(train_states, train_mask)
        nll = F.cross_entropy(output.logits.transpose(1, 2), train_batch.targets, reduction="none")
        total_nll = (nll * train_batch.valid).sum()
        loss = total_nll / train_batch.byte_count
        if not torch.isfinite(loss):
            raise RuntimeError("non-finite #163 training loss")
        loss.backward()
        qk_radial, qk_angular = _qk_gradient_groups(model)
        qk_radial_gradients.append(qk_radial)
        qk_angular_gradients.append(qk_angular)
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip_norm)
        norm_value = float(norm.detach().cpu().item())
        if not math.isfinite(norm_value) or train_states.grad is None or not torch.isfinite(train_states.grad).all():
            raise RuntimeError("non-finite #163 gradient")
        gradient_norms.append(norm_value)
        auxiliary = prepared.polar_auxiliary_train
        if auxiliary is None:
            raise RuntimeError("#163 operation arm lacks inherited polar auxiliary values")
        theta = auxiliary["theta"].to(requested)
        active = auxiliary["complex_active"].to(requested) & train_mask[..., None]
        channels = theta.size(-1)
        state_gradient = train_states.grad
        rho_gradient = state_gradient[..., :channels] / prepared.scalar_rms
        cosine_gradient = state_gradient[..., channels:2 * channels] / prepared.scalar_rms
        sine_gradient = state_gradient[..., 2 * channels:3 * channels] / prepared.scalar_rms
        theta_gradient = -theta.sin() * cosine_gradient + theta.cos() * sine_gradient
        rho_gradients.append(float(rho_gradient[active].square().mean().sqrt().item()))
        theta_gradients.append(float(theta_gradient[active].square().mean().sqrt().item()))
        before = [parameter.detach().clone() for parameter in model.parameters()]
        optimizer.step()
        update_norm = math.sqrt(math.fsum(
            float((parameter.detach() - old).square().sum(dtype=torch.float64).item())
            for old, parameter in zip(before, model.parameters(), strict=True)
        ))
        if not math.isfinite(update_norm) or any(not torch.isfinite(parameter).all() for parameter in model.parameters()):
            raise RuntimeError("non-finite #163 parameter update")
        update_norms.append(update_norm)
        training_elapsed += time.perf_counter() - started
        train_curve.append({
            "step": step,
            "total_nll": float(total_nll.detach().cpu().item()),
            "original_byte_count": train_batch.byte_count,
            "byte_normalized_nll": float(loss.detach().cpu().item()),
            "preclip_gradient_l2_norm": norm_value,
            "parameter_update_l2_norm": update_norm,
            "parameters_finite": True,
            "cumulative_training_original_bytes": train_batch.byte_count * step,
            "cumulative_training_dense_flops_estimate": 3 * train_forward * step,
            "cumulative_training_nondense_operations_estimate": 3 * train_nondense * step,
        })
        if step in config.checkpoint_steps:
            evaluate(step)

    model.eval()
    with torch.no_grad():
        diagnostics = mechanism_diagnostics(model, evaluation_states, evaluation_mask)
    total_elapsed = max(time.perf_counter() - total_started, 1e-12)
    training_elapsed = max(training_elapsed, 1e-12)
    final_rows = [row for row in trace if row["checkpoint_step"] == config.updates]
    final_total = math.fsum(row["total_nll"] for row in final_rows)
    final_count = sum(row["original_byte_count"] for row in final_rows)
    parameters = parameter_count(model)
    parameter_bytes = sum(parameter.numel() * parameter.element_size() for parameter in model.parameters())
    overhead_fraction = train_nondense / train_forward if train_forward else 0.0
    return {
        "schema_version": "phase-operation-ablation-cell/v1",
        "issue": ISSUE_NUMBER,
        "condition": prepared.name,
        "operation_config": condition_operation_config(prepared.name),
        "seed": seed,
        "initial_model_state_sha256": initial_sha,
        "final_model_state_sha256": module_state_fingerprint(model),
        "representation_provenance": {
            "raw_train_fingerprint": prepared.raw_train_fingerprint,
            "raw_evaluation_fingerprint": prepared.raw_evaluation_fingerprint,
            "canonical_train_fingerprint": prepared.canonical_train_fingerprint,
            "canonical_evaluation_fingerprint": prepared.canonical_evaluation_fingerprint,
            "coordinate_map_parameter_count": 0,
            "composition": "none",
        },
        "rms_calibration": {
            "scalar_rms": prepared.scalar_rms,
            "epsilon": config.rms_epsilon,
            "valid_time_count": int(prepared.train_mask.sum().item()),
            "canonical_element_count": int(prepared.train_mask.sum().item()) * config.canonical_width,
        },
        "train_curve": train_curve,
        "validation_learning_curve": trace,
        "final_evaluation": {
            "total_nll": final_total,
            "original_byte_count": final_count,
            "byte_normalized_nll": final_total / final_count,
            "documents": final_rows,
        },
        "parameter_ledger": {
            "total_parameters": parameters,
            "trainable_parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
            "parameter_bytes": parameter_bytes,
        },
        "flop_ledger": {
            "estimation": "exact #162 dense multiply/add ledger plus explicit non-dense operation estimate",
            "dense_forward_flops_per_calibration_batch": train_forward,
            "dense_training_flops_estimate": 3 * train_forward * config.updates,
            "dense_checkpoint_evaluation_flops_estimate": eval_forward * len(config.checkpoint_steps),
            "dense_total_flops_estimate": 3 * train_forward * config.updates + eval_forward * len(config.checkpoint_steps),
            "nondense_operations_per_calibration_batch": train_nondense,
            "nondense_training_operations_estimate": 3 * train_nondense * config.updates,
            "nondense_checkpoint_evaluation_operations_estimate": eval_nondense * len(config.checkpoint_steps),
            "nondense_overhead_fraction_of_dense_forward": overhead_fraction,
        },
        "performance_ledger": {
            "training_elapsed_seconds": training_elapsed,
            "cell_total_wall_elapsed_seconds": total_elapsed,
            "training_original_bytes_processed": train_batch.byte_count * config.updates,
            "training_original_bytes_per_second": train_batch.byte_count * config.updates / training_elapsed,
            "checkpoint_ledger": checkpoint_ledger,
            "peak_process_rss_bytes": _rss_bytes(),
            "initial_process_peak_rss_bytes": initial_rss,
        },
        "gradient_ledger": {
            "parameter_preclip_l2": _summarize(gradient_norms),
            "parameter_update_l2": _summarize(update_norms),
            "input_rho_rms": _summarize(rho_gradients),
            "input_theta_rms": _summarize(theta_gradients),
            "qk_projected_radial_parameter_rms": _summarize(qk_radial_gradients),
            "qk_projected_angular_parameter_rms": _summarize(qk_angular_gradients),
            "all_finite": True,
        },
        "mechanism_diagnostics": diagnostics,
        "test_split": {"status": "sealed-not-read", "accessed": False},
    }


def aggregate_outcomes(rows: Sequence[Mapping[str, Any]]) -> tuple[dict[str, dict[str, float]], list[dict[str, Any]]]:
    cells: dict[tuple[str, int, str, int], tuple[float, int]] = {}
    documents: set[str] = set()
    for row in rows:
        condition, seed = str(row["condition"]), int(row["seed"])
        document, step = str(row["document_id"]), int(row["checkpoint_step"])
        if condition not in STATISTICAL_CONDITIONS or seed not in DOWNSTREAM_SEEDS or step not in CHECKPOINT_STEPS:
            raise ValueError("#163 trace contains a non-preregistered cell")
        key = condition, seed, document, step
        if key in cells:
            raise ValueError("duplicate #163 trace row")
        total, count = float(row["total_nll"]), int(row["original_byte_count"])
        if count < 1 or not math.isfinite(total) or not math.isclose(float(row["byte_normalized_nll"]), total / count, rel_tol=1e-9, abs_tol=1e-11):
            raise ValueError("invalid #163 byte-normalized trace row")
        cells[key] = total, count
        documents.add(document)
    document_ids = sorted(documents)
    expected = {
        (condition, seed, document, step)
        for condition in STATISTICAL_CONDITIONS for seed in DOWNSTREAM_SEEDS
        for document in document_ids for step in CHECKPOINT_STEPS
    }
    if len(document_ids) != 8 or set(cells) != expected:
        raise ValueError("trace does not cover the frozen six-by-three-by-eight-by-seven grid")
    aggregated = []
    for condition in STATISTICAL_CONDITIONS:
        for document in document_ids:
            for step in CHECKPOINT_STEPS:
                values = [cells[(condition, seed, document, step)] for seed in DOWNSTREAM_SEEDS]
                if len({count for _, count in values}) != 1:
                    raise ValueError("paired document byte counts drifted")
                aggregated.append({
                    "condition": condition,
                    "document_id": document,
                    "checkpoint_step": step,
                    "mean_total_nll": math.fsum(total for total, _ in values) / len(values),
                    "original_byte_count": values[0][1],
                })
    index: dict[tuple[str, int], list[Mapping[str, Any]]] = defaultdict(list)
    for row in aggregated:
        index[(str(row["condition"]), int(row["checkpoint_step"]))].append(row)
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    outcomes = {}
    for condition in STATISTICAL_CONDITIONS:
        curve = []
        for step in CHECKPOINT_STEPS:
            group = index[(condition, step)]
            curve.append(math.fsum(float(row["mean_total_nll"]) for row in group) / sum(int(row["original_byte_count"]) for row in group))
        values = torch.tensor(curve, dtype=torch.float64)
        outcomes[condition] = {"final": float(values[-1]), "aulc": float(torch.trapezoid(values, fractions))}
    return outcomes, aggregated


def paired_document_bootstrap(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    outcomes, aggregated = aggregate_outcomes(rows)
    documents = sorted({str(row["document_id"]) for row in aggregated})
    lookup = {(row["condition"], row["checkpoint_step"], row["document_id"]): row for row in aggregated}
    generator = torch.Generator(device="cpu").manual_seed(BOOTSTRAP_SEED)
    draws = torch.randint(len(documents), (BOOTSTRAP_SAMPLES, len(documents)), generator=generator, dtype=torch.int64)
    draw_hash = integer_draw_sha256(draws)
    if draw_hash != BOOTSTRAP_DRAW_SHA256:
        raise RuntimeError("#123/#162 paired bootstrap integer schedule drifted")
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    replicates: dict[str, dict[str, torch.Tensor]] = {condition: {} for condition in STATISTICAL_CONDITIONS}
    for condition in STATISTICAL_CONDITIONS:
        curve = []
        for step in CHECKPOINT_STEPS:
            totals = torch.tensor([float(lookup[(condition, step, doc)]["mean_total_nll"]) for doc in documents], dtype=torch.float64)
            counts = torch.tensor([int(lookup[(condition, step, doc)]["original_byte_count"]) for doc in documents], dtype=torch.float64)
            curve.append(totals[draws].sum(1) / counts[draws].sum(1))
        values = torch.stack(curve, dim=1)
        replicates[condition] = {"final": values[:, -1], "aulc": torch.trapezoid(values, fractions, dim=1)}
    per_alpha = FAMILYWISE_ALPHA / DECISION_FAMILY_SIZE
    quantiles = torch.tensor((per_alpha / 2, 1 - per_alpha / 2), dtype=torch.float64)
    intervals: dict[str, dict[str, Any]] = {outcome: {} for outcome in OUTCOMES}
    for outcome in OUTCOMES:
        for name, terms in CONTRAST_DEFINITIONS.items():
            point = math.fsum(coefficient * outcomes[condition][outcome] for condition, coefficient in terms)
            values = sum(coefficient * replicates[condition][outcome] for condition, coefficient in terms)
            lower, upper = torch.quantile(values, quantiles)
            intervals[outcome][name] = {
                "point": point,
                "lower": float(lower),
                "upper": float(upper),
                "confidence": 1 - per_alpha,
                "familywise_confidence": 1 - FAMILYWISE_ALPHA,
                "bootstrap_samples": BOOTSTRAP_SAMPLES,
                "resampling_unit": "source-document",
                "seed_aggregation": "within-document fixed-seed mean",
            }
    return {
        "schema_version": "phase-operation-ablation-statistics/v1",
        "issue": ISSUE_NUMBER,
        "condition_outcomes": outcomes,
        "contrast_definitions": {
            name: [{"condition": condition, "coefficient": coefficient} for condition, coefficient in terms]
            for name, terms in CONTRAST_DEFINITIONS.items()
        },
        "contrasts": intervals,
        "bootstrap": {
            "method": "paired percentile source-document block bootstrap; fixed seeds averaged within document; shared frozen draws",
            "samples": BOOTSTRAP_SAMPLES,
            "seed": BOOTSTRAP_SEED,
            "draws_sha256": draw_hash,
            "familywise_alpha": FAMILYWISE_ALPHA,
            "decision_family_size": DECISION_FAMILY_SIZE,
            "per_interval_two_sided_alpha": per_alpha,
        },
        "thresholds": {"material_nats_per_original_byte": MATERIAL_NLL, "equivalence_nats_per_original_byte": EQUIVALENCE_NLL},
    }


def seed_contrasts(cells: Sequence[Mapping[str, Any]], spectral_anchor_cells: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, float]]:
    by_key = {(str(cell["condition"]), int(cell["seed"])): float(cell["final_evaluation"]["byte_normalized_nll"]) for cell in cells}
    for cell in spectral_anchor_cells:
        by_key[("spectral_cartesian", int(cell["seed"]))] = float(cell["final_evaluation"]["byte_normalized_nll"])
    return {
        str(seed): {
            name: math.fsum(coefficient * by_key[(condition, seed)] for condition, coefficient in terms)
            for name, terms in CONTRAST_DEFINITIONS.items()
        }
        for seed in DOWNSTREAM_SEEDS
    }


def _reverse_interval(interval: Mapping[str, Any]) -> dict[str, float]:
    return {"point": -float(interval["point"]), "lower": -float(interval["upper"]), "upper": -float(interval["lower"])}


def classify(
    statistics: Mapping[str, Any],
    cells: Sequence[Mapping[str, Any]],
    spectral_anchor_cells: Sequence[Mapping[str, Any]],
    *,
    instrumentation_passed: bool,
) -> dict[str, Any]:
    if not instrumentation_passed:
        return {
            "disposition": "INVALID-INSTRUMENTATION",
            "advance_issue_164": False,
            "reason": "a fail-closed source/replay/causality/numerical/resource gate failed before interpretation",
            "independently_surviving_operations": [],
            "minimal_polar_block": None,
        }
    final = statistics["contrasts"]["final"]
    per_seed = seed_contrasts(cells, spectral_anchor_cells)
    families = {
        "phase_attention": ("attention_vs_coordinate", "attention_vs_manual", "attention_vs_spectral", ATTENTION_ONLY),
        "phase_residual": ("residual_vs_coordinate", "residual_vs_manual", "residual_vs_spectral", RESIDUAL_ONLY),
        "log_radius": ("log_radius_vs_coordinate", "log_radius_vs_manual", "log_radius_vs_spectral", LOG_RADIUS_ONLY),
    }
    parameter_counts = {int(cell["parameter_ledger"]["total_parameters"]) for cell in cells}
    dense_flops = {int(cell["flop_ledger"]["dense_training_flops_estimate"]) for cell in cells}
    overhead = max(float(cell["flop_ledger"]["nondense_overhead_fraction_of_dense_forward"]) for cell in cells)
    costs_matched = len(parameter_counts) == 1 and len(dense_flops) == 1 and overhead <= MAX_NONDENSE_OVERHEAD_FRACTION
    gates: dict[str, Any] = {}
    survivors: list[str] = []
    condition_by_family: dict[str, str] = {}
    for family, (vs_coordinate, vs_manual, vs_spectral, condition) in families.items():
        pooled = all(float(final[name]["upper"]) <= -MATERIAL_NLL for name in (vs_coordinate, vs_manual, vs_spectral))
        consistent = all(
            all(values[name] <= -MATERIAL_NLL for name in (vs_coordinate, vs_manual, vs_spectral))
            for values in per_seed.values()
        )
        survived = pooled and consistent and costs_matched
        gates[family] = {
            "pooled_upper_bounds_below_negative_materiality_vs_coordinate_manual_and_spectral": pooled,
            "every_seed_material_vs_coordinate_manual_and_spectral": consistent,
            "resource_matched": costs_matched,
            "survived": survived,
        }
        if survived:
            survivors.append(family)
            condition_by_family[family] = condition

    # Predeclared parsimony order: the sole operation actually present in
    # #162 first, then residual, then explicit rho.  A candidate must not be
    # materially worse than full #162 (upper <= +0.01).
    priority = ("phase_attention", "phase_residual", "log_radius")
    preservation: dict[str, Any] = {}
    selected: str | None = None
    for family in priority:
        condition = families[family][3]
        if condition == ATTENTION_ONLY:
            relative = {"point": 0.0, "lower": 0.0, "upper": 0.0, "structural_identity": True}
        elif condition == RESIDUAL_ONLY:
            relative = _reverse_interval(final["full_162_vs_residual"])
        else:
            relative = _reverse_interval(final["full_162_vs_log_radius"])
        preserves = family in survivors and float(relative["upper"]) <= MATERIAL_NLL
        preservation[family] = {"candidate_minus_full_162": relative, "preserves_substantive_162_advantage": preserves}
        if selected is None and preserves:
            selected = family
    advance = selected is not None
    minimal = None
    if selected is not None:
        condition = condition_by_family[selected]
        minimal = {
            "family": selected,
            "condition": condition,
            "config": minimal_block_wire(condition),
            "config_sha256": minimal_block_digest(condition),
        }
    manual_path = final["manual_path_vs_coordinate"]
    bundling_artifact = (
        float(manual_path["upper"]) <= -MATERIAL_NLL
        and "phase_attention" not in survivors
    )
    return {
        "disposition": "ADVANCE" if advance else "STOP",
        "advance_issue_164": advance,
        "reason": (
            "at least one isolated operation is materially seed-consistent against coordinate, manual-path, and spectral controls, and the smallest survivor preserves the #162 advantage"
            if advance else
            "no isolated matched-resource operation both survives all controls and preserves the substantive #162 advantage"
        ),
        "independently_surviving_operations": survivors,
        "minimal_polar_block": minimal,
        "operation_gates": gates,
        "minimal_candidate_preservation": preservation,
        "bundling_artifact": bundling_artifact,
        "architectural_interaction_possible_in_full_162": False,
        "architectural_interaction_reason": "the audited #162 full model changed only attention; residual/log-radius interactions were absent",
        "per_seed_contrasts": per_seed,
        "resource_gates": {
            "equal_parameter_counts": len(parameter_counts) == 1,
            "equal_dense_training_flops": len(dense_flops) == 1,
            "maximum_nondense_overhead_fraction": overhead,
            "within_one_percent": overhead <= MAX_NONDENSE_OVERHEAD_FRACTION,
        },
    }


def phase_similarity_synthetic() -> dict[str, Any]:
    model = ComposablePolarTransformer(attention_mode="hermitian", residual_mode="cartesian")
    head_width = 32
    base = torch.zeros(1, 1, 1, head_width, dtype=torch.float64)
    aligned = base.clone()
    opposed = base.clone()
    quadrature = base.clone()
    base[..., head_width // 2::2] = 1.0
    aligned[..., head_width // 2::2] = 1.0
    opposed[..., head_width // 2::2] = -1.0
    quadrature[..., head_width // 2 + 1::2] = 1.0

    def normalize(value: torch.Tensor) -> torch.Tensor:
        radial, angular = value.split((head_width // 2, head_width // 2), dim=-1)
        pairs = angular.reshape(*angular.shape[:-1], -1, 2)
        norm = torch.sqrt(pairs.square().sum(-1, keepdim=True) + model.angular_epsilon ** 2)
        return torch.cat((radial, (math.sqrt(2.0) * pairs / norm).flatten(start_dim=-2)), -1)

    q = normalize(base)
    scores = {}
    for name, key in (("aligned", aligned), ("opposed", opposed), ("quadrature", quadrature)):
        scores[name] = float((q * normalize(key)).sum().item() / math.sqrt(head_width))
    expected = math.sqrt(8.0)
    passed = (
        abs(scores["aligned"] - expected) <= 1e-9
        and abs(scores["opposed"] + expected) <= 1e-9
        and abs(scores["quadrature"]) <= 1e-12
    )
    return {"scores": scores, "expected_aligned_absolute": expected, "passed": passed}


def run_synthetic_controls(config: LogPolarConfig = DEFAULT_CONFIG) -> dict[str, Any]:
    config.validate()
    generator = torch.Generator().manual_seed(163_001)
    states = torch.randn(2, 9, 128, generator=generator)
    mask = torch.ones(2, 9, dtype=torch.bool)
    old = PhaseAwareCausalTransformer(128, 4, 1, config.angular_norm_epsilon)
    recomposed = ComposablePolarTransformer(attention_mode="hermitian", residual_mode="cartesian")
    recomposed.load_state_dict(old.state_dict(), strict=True)
    old.eval(); recomposed.eval()
    with torch.no_grad():
        old_output = old(states, mask)
        new_output = recomposed(states, mask)
    recomposition_difference = float((old_output.logits - new_output.logits).abs().max().item())

    manual = ComposablePolarTransformer(attention_mode="manual_cartesian", residual_mode="cartesian")
    log_radius = ComposablePolarTransformer(attention_mode="manual_cartesian", residual_mode="log_radius")
    log_radius.load_state_dict(manual.state_dict(), strict=True)
    manual.eval(); log_radius.eval()
    with torch.no_grad():
        manual_output = manual(states, mask).logits
        log_output = log_radius(states, mask).logits
    log_radius_identity_difference = float((manual_output - log_output).abs().max().item())

    real = torch.tensor([[1.0, 0.0, 1e-12, 0.0]], dtype=torch.float64, requires_grad=True)
    imag = torch.tensor([[0.0, 1.0, 0.0, 0.0]], dtype=torch.float64, requires_grad=True)
    radial_real = torch.tensor([[0.25, 0.0, 1e-4, 0.0]], dtype=torch.float64)
    radial_imag = torch.tensor([[0.0, 0.25, 0.0, 0.0]], dtype=torch.float64)
    rr, ri, radial_diag = phase_preserving_residual_pairs(real, imag, radial_real, radial_imag)
    base_radius = torch.sqrt(real.square() + imag.square())
    radial_radius = torch.sqrt(rr.square() + ri.square())
    radial_angle = torch.atan2(torch.sin(torch.atan2(ri, rr) - torch.atan2(imag, real)), torch.cos(torch.atan2(ri, rr) - torch.atan2(imag, real)))
    tangent_real = -0.2 * imag.detach()
    tangent_imag = 0.2 * real.detach()
    ar, ai, angular_diag = phase_preserving_residual_pairs(real, imag, tangent_real, tangent_imag)
    angular_radius = torch.sqrt(ar.square() + ai.square())
    angular_change = angular_diag["angular_delta"].abs()
    wrap_real = torch.tensor([[-1.0, -1.0]], dtype=torch.float64)
    wrap_left_imag = torch.tensor([[1e-9, -1e-9]], dtype=torch.float64)
    wrap_delta = torch.tensor([[0.0, 0.0]], dtype=torch.float64)
    wr, wi, _ = phase_preserving_residual_pairs(wrap_real, wrap_left_imag, wrap_delta, wrap_delta)
    wrap_distance = float(abs(math.atan2(math.sin(float(torch.atan2(wi[0, 0], wr[0, 0]) - torch.atan2(wi[0, 1], wr[0, 1]))), math.cos(float(torch.atan2(wi[0, 0], wr[0, 0]) - torch.atan2(wi[0, 1], wr[0, 1]))))))
    (rr.square().mean() + ri.square().mean() + ar.square().mean() + ai.square().mean()).backward()
    finite_residual_gradients = bool(torch.isfinite(real.grad).all() and torch.isfinite(imag.grad).all())

    initialization = {}
    for seed in DOWNSTREAM_SEEDS:
        models = {condition: build_ablation_predictor(condition, seed, config) for condition in TRAINED_CONDITIONS}
        initialization[str(seed)] = {
            "fingerprints": {condition: module_state_fingerprint(model) for condition, model in models.items()},
            "parameters": {condition: parameter_count(model) for condition, model in models.items()},
        }
        initialization[str(seed)]["all_equal"] = (
            len(set(initialization[str(seed)]["fingerprints"].values())) == 1
            and len(set(initialization[str(seed)]["parameters"].values())) == 1
        )

    causal = {}
    for condition in TRAINED_CONDITIONS:
        model = build_ablation_predictor(condition, 17, config)
        model.eval()
        altered = states.clone()
        altered[:, 6:] = torch.randn(2, 3, 128, generator=generator)
        with torch.no_grad():
            prefix = float((model(states, mask).logits[:, :6] - model(altered, mask).logits[:, :6]).abs().max().item())
        differentiable = states.clone().requires_grad_(True)
        early = model(differentiable, mask).logits[:, 4].sum()
        future = torch.autograd.grad(early, differentiable)[0][:, 5:]
        causal[condition] = {
            "prefix_max_absolute_difference": prefix,
            "future_gradient_max_absolute": float(future.abs().max().item()),
            "finite_logits": bool(torch.isfinite(model(states, mask).logits).all()),
        }

    similarity = phase_similarity_synthetic()
    radial_active = base_radius > RESIDUAL_EPSILON
    passed = (
        recomposition_difference <= RECOMPOSITION_TOLERANCE
        and log_radius_identity_difference == 0.0
        and float(radial_angle[radial_active].abs().max().detach()) <= 1e-12
        and bool((radial_radius[radial_active] > base_radius[radial_active]).all())
        and float((angular_radius[radial_active] - base_radius[radial_active]).abs().max().detach()) <= 1e-12
        and bool((angular_change[radial_active] > 0).all())
        and wrap_distance <= 3e-9
        and finite_residual_gradients
        and similarity["passed"]
        and all(item["all_equal"] for item in initialization.values())
        and all(item["prefix_max_absolute_difference"] <= 1e-6 and item["future_gradient_max_absolute"] <= 1e-10 and item["finite_logits"] for item in causal.values())
        and bool(torch.isfinite(radial_diag["new_radius"]).all())
    )
    return {
        "schema_version": "phase-operation-synthetic-controls/v1",
        "passed": passed,
        "full_162_recomposition_max_absolute_logit_difference": recomposition_difference,
        "explicit_log_radius_vs_manual_max_absolute_logit_difference": log_radius_identity_difference,
        "phase_similarity": similarity,
        "pure_radial_direction_change_max_absolute": float(radial_angle[radial_active].abs().max().detach()),
        "pure_radial_magnitude_increased": bool((radial_radius[radial_active] > base_radius[radial_active]).all()),
        "pure_angular_magnitude_difference_max_absolute": float((angular_radius[radial_active] - base_radius[radial_active]).abs().max().detach()),
        "pure_angular_direction_changed": bool((angular_change[radial_active] > 0).all()),
        "phase_wrap_circular_distance": wrap_distance,
        "zero_and_near_zero_finite": bool(torch.isfinite(radial_diag["new_radius"]).all()),
        "finite_residual_gradients": finite_residual_gradients,
        "matched_initialization": initialization,
        "causality": causal,
    }


__all__ = [
    "ATTENTION_ONLY", "COLLAPSE_RADIUS", "CONTRAST_DEFINITIONS", "COORDINATE_CONTROL",
    "ComposablePolarTransformer", "DECISION_FAMILY_SIZE", "EXPLOSION_RADIUS", "EXPLOSION_RATIO",
    "FULL_162_CONDITION", "LOG_RADIUS_ONLY", "MANUAL_CONTROL", "MATERIAL_NLL",
    "MAX_NONDENSE_OVERHEAD_FRACTION", "QUALIFYING_REPLAY_NLL_TOLERANCE", "RECOMPOSITION_TOLERANCE",
    "RESIDUAL_ONLY", "RESIDUAL_EPSILON", "STATISTICAL_CONDITIONS", "TRAINED_CONDITIONS",
    "aggregate_outcomes", "build_ablation_predictor", "classify", "condition_operation_config",
    "explicit_log_radius_residual", "fit_ablation_condition", "mechanism_diagnostics",
    "minimal_block_digest", "minimal_block_wire", "nondense_operations", "paired_document_bootstrap",
    "phase_preserving_residual_pairs", "phase_similarity_synthetic", "prepare_ablation_conditions",
    "residual_elementwise_operations", "run_synthetic_controls", "seed_contrasts",
]
