"""Issue #164: retained-radius versus hyperspherical recurrent depth.

This module changes only the topology surrounding the frozen issue #163
phase-aware Q/K block.  The spectral transmitter, parameter-free
``[rho, cos(theta), sin(theta), zero-pad]`` input, Hermitian attention score,
Cartesian values/residuals/normalization/FFN/head, and language objective are
inherited unchanged.

The qualifying comparison uses three effective applications of the block:

* independent copies (ordinary flat depth),
* one Cartesian block shared over depth,
* the same shared block with unit-hyperspherical state, and
* the same shared block with an explicit ``x = exp(rho) * u`` product state.

No shell/depth coordinate is used.  A one-step, same-parameter anchor is
replayed from #163 and is not retrained.
"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from copy import deepcopy
import math
import resource
import sys
import time
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F

from .log_polar_no_composition import (
    BOOTSTRAP_DRAW_SHA256,
    BUDGET_FRACTIONS,
    CHECKPOINT_STEPS,
    DEFAULT_CONFIG,
    DOWNSTREAM_SEEDS,
    LogPolarConfig,
    PreparedCondition,
    dense_forward_flops,
    digest,
    polar_elementwise_operations,
)
from .oracle_no_composition import PredictorOutput, _fixed_sinusoid, parameter_count
from .oracle_no_composition_stats import integer_draw_sha256
from .phase_operation_ablations import (
    ATTENTION_ONLY,
    ComposablePolarTransformer,
    prepare_ablation_conditions,
)
from .spectral import TextBatch, module_state_fingerprint


ISSUE_NUMBER = 164
SCHEMA_VERSION = "retained-radius-topology/v1"
EFFECTIVE_DEPTH = 3
ANCHOR = "phase_attention_depth1_anchor"
INDEPENDENT_FLAT = "independent_flat_depth3"
SHARED_GENERIC = "shared_generic_depth3"
UNIT_HYPERSPHERE = "unit_hypersphere_depth3"
RETAINED_RADIUS = "retained_radius_depth3"
TRAINED_CONDITIONS = (
    INDEPENDENT_FLAT,
    SHARED_GENERIC,
    UNIT_HYPERSPHERE,
    RETAINED_RADIUS,
)
STATISTICAL_CONDITIONS = (ANCHOR,) + TRAINED_CONDITIONS
OUTCOMES = ("final", "aulc")
MATERIAL_NLL = 0.01
EQUIVALENCE_NLL = 0.005
FAMILYWISE_ALPHA = 0.05
BOOTSTRAP_SAMPLES = 65_536
BOOTSTRAP_SEED = 12_365_536
GEOMETRY_EPSILON = 1e-6
MAX_GEOMETRIC_OVERHEAD_FRACTION = 0.01
PARAMETER_REDUCTION_FRACTION = 0.40
REPLAY_NLL_TOLERANCE = 1e-7
NORM_TOLERANCE = 2e-5
RECONSTRUCTION_TOLERANCE = 2e-5
RADIUS_COLLAPSE = 1e-6
RADIUS_EXPLOSION = 1e3
RADIUS_RATIO_EXPLOSION = 100.0


# Every interval below (both final and AULC) belongs to one simultaneous
# family.  Negative always means the first named arm has lower NLL.
CONTRAST_DEFINITIONS: Mapping[str, tuple[tuple[str, float], ...]] = {
    "retained_radius_benefit": ((RETAINED_RADIUS, 1.0), (UNIT_HYPERSPHERE, -1.0)),
    "sharing_effect": ((SHARED_GENERIC, 1.0), (INDEPENDENT_FLAT, -1.0)),
    "hyperspherical_effect": ((UNIT_HYPERSPHERE, 1.0), (SHARED_GENERIC, -1.0)),
    "independent_depth_effect": ((INDEPENDENT_FLAT, 1.0), (ANCHOR, -1.0)),
    "fixed_parameter_recurrence_effect": ((SHARED_GENERIC, 1.0), (ANCHOR, -1.0)),
    "unit_vs_independent": ((UNIT_HYPERSPHERE, 1.0), (INDEPENDENT_FLAT, -1.0)),
    "retained_vs_independent": ((RETAINED_RADIUS, 1.0), (INDEPENDENT_FLAT, -1.0)),
    "retained_vs_generic": ((RETAINED_RADIUS, 1.0), (SHARED_GENERIC, -1.0)),
}
DECISION_FAMILY_SIZE = len(CONTRAST_DEFINITIONS) * len(OUTCOMES)


def condition_topology_config(condition: str) -> dict[str, Any]:
    matrix = {
        ANCHOR: {
            "effective_depth": 1,
            "independent_blocks": 1,
            "shared_recurrence": False,
            "state_geometry": "cartesian",
            "explicit_radius": False,
            "shell_coordinate": False,
            "source": "exact issue-163 spectral_phase_attention_only replay",
        },
        INDEPENDENT_FLAT: {
            "effective_depth": EFFECTIVE_DEPTH,
            "independent_blocks": EFFECTIVE_DEPTH,
            "shared_recurrence": False,
            "state_geometry": "cartesian",
            "explicit_radius": False,
            "shell_coordinate": False,
            "source": "ordinary independently-parameterized flat stack",
        },
        SHARED_GENERIC: {
            "effective_depth": EFFECTIVE_DEPTH,
            "independent_blocks": 1,
            "shared_recurrence": True,
            "state_geometry": "cartesian",
            "explicit_radius": False,
            "shell_coordinate": False,
            "source": "Universal-Transformer-style generic shared depth control",
        },
        UNIT_HYPERSPHERE: {
            "effective_depth": EFFECTIVE_DEPTH,
            "independent_blocks": 1,
            "shared_recurrence": True,
            "state_geometry": "unit-hypersphere",
            "explicit_radius": False,
            "shell_coordinate": False,
            "source": "minimal nGPT/Hyper-SET-inspired unit-direction control",
        },
        RETAINED_RADIUS: {
            "effective_depth": EFFECTIVE_DEPTH,
            "independent_blocks": 1,
            "shared_recurrence": True,
            "state_geometry": "R-times-unit-hypersphere product state",
            "explicit_radius": True,
            "shell_coordinate": False,
            "source": "explicit x=exp(rho)*u retained-radius hypothesis",
        },
    }
    if condition not in matrix:
        raise ValueError(f"unknown #164 topology condition {condition!r}")
    return matrix[condition]


def topology_wire() -> dict[str, Any]:
    return {
        "schema_version": "retained-radius-topology-config/v1",
        "source_issue": 164,
        "inherited_minimal_block_condition": ATTENTION_ONLY,
        "inherited_minimal_block_sha256": "b0f24e5c196bda116120fd085eee60f37e0eaf6f3b146f45b253f0c79a5c21ec",
        "input": "exact #162 [rho,cos(theta),sin(theta),zero-pad] tensor",
        "width": 128,
        "heads": 4,
        "effective_depth": EFFECTIVE_DEPTH,
        "phase_attention": "radial dot plus normalized real-Hermitian angular Q/K score",
        "ordinary_paths": ["Cartesian V", "Cartesian output projection", "Cartesian residuals", "LayerNorm", "FFN", "byte head"],
        "trainable_adapter_parameters": 0,
        "spectral_composition": False,
        "shell_coordinate": False,
        "condition_matrix": {condition: condition_topology_config(condition) for condition in STATISTICAL_CONDITIONS},
    }


def topology_digest() -> str:
    return digest(topology_wire())


def decompose_radius_direction(
    states: torch.Tensor,
    time_mask: torch.Tensor | None = None,
    *,
    epsilon: float = GEOMETRY_EPSILON,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return finite ``rho``, unit direction, and active-radius mask.

    Exact and near zero use a deterministic first-axis direction.  Masked
    positions reconstruct to zero and never become attention keys.
    """

    if states.ndim < 2 or epsilon <= 0:
        raise ValueError("invalid product-state decomposition input")
    radius = torch.linalg.vector_norm(states, dim=-1, keepdim=True)
    active = radius.gt(epsilon)
    if time_mask is not None:
        if tuple(time_mask.shape) != tuple(states.shape[:-1]):
            raise ValueError("product-state mask shape drifted")
        active = active & time_mask[..., None]
    safe_radius = radius.clamp_min(epsilon)
    canonical = torch.zeros_like(states)
    canonical[..., 0] = 1.0
    direction = torch.where(active, states / safe_radius, canonical)
    rho = torch.where(active, torch.log(safe_radius), torch.full_like(radius, math.log(epsilon)))
    if not torch.isfinite(rho).all() or not torch.isfinite(direction).all():
        raise FloatingPointError("non-finite product-state decomposition")
    return rho, direction, active


def reconstruct_radius_direction(
    rho: torch.Tensor,
    direction: torch.Tensor,
    active: torch.Tensor,
) -> torch.Tensor:
    if rho.shape != active.shape or direction.shape[:-1] != rho.shape[:-1] or direction.size(-1) < 1:
        raise ValueError("product-state reconstruction shape drifted")
    result = torch.where(active, rho.exp() * direction, torch.zeros_like(direction))
    if not torch.isfinite(result).all():
        raise FloatingPointError("non-finite product-state reconstruction")
    return result


def project_unit_hypersphere(
    states: torch.Tensor,
    time_mask: torch.Tensor | None = None,
    *,
    epsilon: float = GEOMETRY_EPSILON,
) -> torch.Tensor:
    _, direction, active = decompose_radius_direction(states, time_mask, epsilon=epsilon)
    if time_mask is None:
        return direction
    return torch.where(active, direction, torch.zeros_like(direction))


def sphere_log_map(
    base: torch.Tensor,
    target: torch.Tensor,
    *,
    epsilon: float = GEOMETRY_EPSILON,
) -> torch.Tensor:
    """Shortest-path tangent taking unit ``base`` toward unit ``target``."""

    if base.shape != target.shape or epsilon <= 0:
        raise ValueError("sphere log-map input drifted")
    dot = (base * target).sum(dim=-1, keepdim=True).clamp(-1.0 + epsilon, 1.0)
    angle = torch.acos(dot)
    raw = target - dot * base
    norm = torch.linalg.vector_norm(raw, dim=-1, keepdim=True)
    tangent = torch.where(norm.gt(epsilon), angle * raw / norm.clamp_min(epsilon), torch.zeros_like(raw))
    if not torch.isfinite(tangent).all():
        raise FloatingPointError("non-finite sphere log-map")
    return tangent


def sphere_exp_map(
    base: torch.Tensor,
    tangent: torch.Tensor,
    *,
    epsilon: float = GEOMETRY_EPSILON,
) -> torch.Tensor:
    if base.shape != tangent.shape or epsilon <= 0:
        raise ValueError("sphere exp-map input drifted")
    angle = torch.linalg.vector_norm(tangent, dim=-1, keepdim=True)
    unit_tangent = tangent / angle.clamp_min(epsilon)
    moved = torch.cos(angle) * base + torch.sin(angle) * unit_tangent
    small = project_unit_hypersphere(base + tangent, epsilon=epsilon)
    moved = torch.where(angle.gt(epsilon), moved, small)
    moved = project_unit_hypersphere(moved, epsilon=epsilon)
    if not torch.isfinite(moved).all():
        raise FloatingPointError("non-finite sphere exp-map")
    return moved


def product_state_update(
    rho: torch.Tensor,
    direction: torch.Tensor,
    radial_delta: torch.Tensor,
    tangent_delta: torch.Tensor,
    active: torch.Tensor,
    *,
    epsilon: float = GEOMETRY_EPSILON,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Apply independent additive radial and geodesic angular updates."""

    if rho.shape != radial_delta.shape or direction.shape != tangent_delta.shape:
        raise ValueError("product-state update shape drifted")
    new_rho = rho + radial_delta
    new_direction = sphere_exp_map(direction, tangent_delta, epsilon=epsilon)
    result = reconstruct_radius_direction(new_rho, new_direction, active)
    return result, new_rho, new_direction


def _phase_attention_block(
    layer: nn.TransformerEncoderLayer,
    states: torch.Tensor,
    time_mask: torch.Tensor,
    *,
    heads: int = 4,
    angular_epsilon: float = GEOMETRY_EPSILON,
    collect: bool = False,
) -> tuple[torch.Tensor, dict[str, torch.Tensor] | None]:
    """Exact #163 Hermitian-Q/K block, excluding position and byte head."""

    attention = layer.self_attn
    batch, time_steps, width = states.shape
    head_width = width // heads
    qkv = F.linear(states, attention.in_proj_weight, attention.in_proj_bias)
    query, key, value = qkv.chunk(3, dim=-1)

    def shaped(tensor: torch.Tensor) -> torch.Tensor:
        return tensor.reshape(batch, time_steps, heads, head_width).transpose(1, 2)

    query, key, value = shaped(query), shaped(key), shaped(value)
    radial_width = head_width // 2

    def preserve_phase(tensor: torch.Tensor) -> torch.Tensor:
        radial, angular = tensor.split((radial_width, head_width - radial_width), dim=-1)
        pairs = angular.reshape(*angular.shape[:-1], -1, 2)
        norm = torch.sqrt(pairs.square().sum(dim=-1, keepdim=True) + angular_epsilon ** 2)
        unit = math.sqrt(2.0) * pairs / norm
        return torch.cat((radial, unit.flatten(start_dim=-2)), dim=-1)

    score_query, score_key = preserve_phase(query), preserve_phase(key)
    scores = torch.matmul(score_query, score_key.transpose(-2, -1)) / math.sqrt(head_width)
    causal = torch.ones(time_steps, time_steps, device=states.device, dtype=torch.bool).triu(1)
    scores = scores.masked_fill(causal[None, None], float("-inf"))
    scores = scores.masked_fill(~time_mask[:, None, None, :], float("-inf"))
    weights = torch.softmax(scores, dim=-1)
    context = torch.matmul(weights, value).transpose(1, 2).contiguous().reshape(batch, time_steps, width)
    attention_delta = F.linear(context, attention.out_proj.weight, attention.out_proj.bias)
    post_attention = layer.norm1(states + layer.dropout1(attention_delta))
    feed_forward = layer.linear2(layer.dropout(layer.activation(layer.linear1(post_attention))))
    hidden = layer.norm2(post_attention + layer.dropout2(feed_forward))
    hidden = hidden.masked_fill(~time_mask[..., None], 0.0)
    if not torch.isfinite(hidden).all():
        raise FloatingPointError("non-finite frozen #163 block state")
    diagnostics = None
    if collect:
        diagnostics = {
            "query": query,
            "key": key,
            "attention_weights": weights,
            "attention_scores": scores,
            "attention_delta": attention_delta,
            "post_attention": post_attention,
        }
    return hidden, diagnostics


class TopologyTransformer(nn.Module):
    """Factorial topology wrapper around the exact frozen #163 operator."""

    architecture = "frozen-phase-attention-topology"

    def __init__(
        self,
        condition: str,
        *,
        width: int = 128,
        heads: int = 4,
        effective_depth: int = EFFECTIVE_DEPTH,
        angular_epsilon: float = GEOMETRY_EPSILON,
        geometry_epsilon: float = GEOMETRY_EPSILON,
    ):
        super().__init__()
        if condition not in STATISTICAL_CONDITIONS:
            raise ValueError("unknown #164 topology")
        expected_depth = 1 if condition == ANCHOR else EFFECTIVE_DEPTH
        if (width, heads, effective_depth) != (128, 4, expected_depth):
            raise ValueError("#164 preserves width/heads and frozen effective depth")
        prototype = ComposablePolarTransformer(
            width=width,
            heads=heads,
            layers=1,
            attention_mode="hermitian",
            residual_mode="cartesian",
            angular_epsilon=angular_epsilon,
        )
        source_layer = prototype.backbone.decoder.layers[0]
        count = EFFECTIVE_DEPTH if condition == INDEPENDENT_FLAT else 1
        self.blocks = nn.ModuleList(deepcopy(source_layer) for _ in range(count))
        self.head = deepcopy(prototype.backbone.head)
        self.condition = condition
        self.width = width
        self.heads = heads
        self.effective_depth = expected_depth
        self.angular_epsilon = float(angular_epsilon)
        self.geometry_epsilon = float(geometry_epsilon)

    def _block(self, step: int) -> nn.TransformerEncoderLayer:
        return self.blocks[step] if self.condition == INDEPENDENT_FLAT else self.blocks[0]

    def _forward_topology(
        self,
        states: torch.Tensor,
        time_mask: torch.Tensor,
        *,
        collect: bool,
        retain_gradients: bool = False,
    ) -> tuple[PredictorOutput, dict[str, Any]]:
        if states.ndim != 3 or states.size(-1) != self.width or tuple(time_mask.shape) != tuple(states.shape[:2]):
            raise ValueError("#164 predictor inputs drifted")
        if not torch.isfinite(states).all():
            raise FloatingPointError("non-finite #164 predictor input")
        position = _fixed_sinusoid(states.size(1), self.width, device=states.device, dtype=states.dtype)[None]
        positioned = states.masked_fill(~time_mask[..., None], 0.0) + position
        positioned = positioned.masked_fill(~time_mask[..., None], 0.0)
        if self.condition == UNIT_HYPERSPHERE:
            current = project_unit_hypersphere(positioned, time_mask, epsilon=self.geometry_epsilon)
        elif self.condition == RETAINED_RADIUS:
            rho, direction, active = decompose_radius_direction(positioned, time_mask, epsilon=self.geometry_epsilon)
            current = reconstruct_radius_direction(rho, direction, active)
        else:
            current = positioned

        step_states: list[torch.Tensor] = [current]
        step_records: list[dict[str, Any]] = []
        if retain_gradients and current.requires_grad:
            current.retain_grad()
        for step in range(self.effective_depth):
            proposal, attention = _phase_attention_block(
                self._block(step), current, time_mask, heads=self.heads,
                angular_epsilon=self.angular_epsilon, collect=collect,
            )
            before_rho, before_direction, before_active = decompose_radius_direction(
                current, time_mask, epsilon=self.geometry_epsilon,
            )
            target_rho, target_direction, target_active = decompose_radius_direction(
                proposal, time_mask, epsilon=self.geometry_epsilon,
            )
            radial_delta = target_rho - before_rho
            tangent_delta = sphere_log_map(before_direction, target_direction, epsilon=self.geometry_epsilon)
            if self.condition == UNIT_HYPERSPHERE:
                current = sphere_exp_map(before_direction, tangent_delta, epsilon=self.geometry_epsilon)
                current = current.masked_fill(~time_mask[..., None], 0.0)
            elif self.condition == RETAINED_RADIUS:
                active = before_active | target_active
                current, _, _ = product_state_update(
                    before_rho, before_direction, radial_delta, tangent_delta, active,
                    epsilon=self.geometry_epsilon,
                )
                current = current.masked_fill(~time_mask[..., None], 0.0)
            else:
                current = proposal
            if retain_gradients and current.requires_grad:
                current.retain_grad()
            step_states.append(current)
            if collect:
                step_records.append({
                    "step": step + 1,
                    "input": step_states[-2],
                    "proposal": proposal,
                    "output": current,
                    "input_rho": before_rho,
                    "output_rho": target_rho if self.condition != UNIT_HYPERSPHERE else torch.zeros_like(target_rho),
                    "input_direction": before_direction,
                    "output_direction": target_direction if self.condition != UNIT_HYPERSPHERE else current,
                    "radial_delta": radial_delta,
                    "tangent_delta": tangent_delta,
                    "active": before_active | target_active,
                    "attention": attention,
                })
        hidden = current.masked_fill(~time_mask[..., None], 0.0)
        logits = self.head(hidden).masked_fill(~time_mask[..., None], 0.0)
        if not torch.isfinite(hidden).all() or not torch.isfinite(logits).all():
            raise FloatingPointError("non-finite #164 output")
        return PredictorOutput(logits=logits, hidden=hidden), {
            "coordinate_input": states,
            "positioned_input": positioned,
            "step_states": step_states,
            "steps": step_records,
        }

    def forward(self, states: torch.Tensor, time_mask: torch.Tensor) -> PredictorOutput:
        output, _ = self._forward_topology(states, time_mask, collect=False)
        return output


def build_topology_predictor(
    condition: str,
    seed: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> TopologyTransformer:
    config.validate()
    if condition not in STATISTICAL_CONDITIONS or seed not in config.downstream_seeds:
        raise ValueError("non-preregistered #164 condition or seed")
    depth = 1 if condition == ANCHOR else EFFECTIVE_DEPTH
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed)
        model = TopologyTransformer(
            condition,
            width=config.canonical_width,
            heads=config.heads,
            effective_depth=depth,
            angular_epsilon=config.angular_norm_epsilon,
            geometry_epsilon=GEOMETRY_EPSILON,
        )
    return model


def prepare_topology_condition(
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    *,
    spectral_frontend: nn.Module,
    byte_frontend: nn.Module,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> PreparedCondition:
    inherited = prepare_ablation_conditions(
        calibration_batch,
        evaluation_batch,
        spectral_frontend=spectral_frontend,
        byte_frontend=byte_frontend,
        config=config,
    )
    return inherited[ATTENTION_ONLY]


def dense_forward_flops_for_depth(
    batch: int,
    time_steps: int,
    effective_depth: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> int:
    if effective_depth < 1:
        raise ValueError("effective depth must be positive")
    d, vocab = config.canonical_width, 256
    layer = 8 * time_steps * d * d + 4 * time_steps * time_steps * d + 16 * time_steps * d * d
    return int(batch * (effective_depth * layer + 2 * time_steps * d * vocab))


def geometric_operations(
    condition: str,
    batch: int,
    time_steps: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
) -> dict[str, int]:
    depth = 1 if condition == ANCHOR else EFFECTIVE_DEPTH
    phase = depth * polar_elementwise_operations(batch, time_steps, config)
    elements = batch * time_steps * config.canonical_width
    # Explicit scalar ledgers, not dense FLOPs: norms/projection per state;
    # log/exp and log/exp-map work per recurrent transition.
    unit = 0
    retained = 0
    if condition == UNIT_HYPERSPHERE:
        unit = elements * (8 + depth * 22)
    elif condition == RETAINED_RADIUS:
        retained = elements * (10 + depth * 26)
    return {"phase_attention": int(phase), "unit_hypersphere": int(unit), "retained_radius": int(retained), "total": int(phase + unit + retained)}


def _rss_bytes() -> int:
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value if sys.platform == "darwin" else value * 1024


def _device_batch(batch: TextBatch, device: torch.device) -> TextBatch:
    return TextBatch(
        input_ids=batch.input_ids.to(device), targets=batch.targets.to(device),
        valid=batch.valid.to(device), byte_count=batch.byte_count,
        document_ids=batch.document_ids,
    )


def _summarize(values: Sequence[float]) -> dict[str, float]:
    if not values or any(not math.isfinite(value) for value in values):
        raise ValueError("cannot summarize empty/non-finite values")
    return {"minimum": min(values), "maximum": max(values), "mean": math.fsum(values) / len(values)}


def _quantiles(values: torch.Tensor) -> dict[str, float]:
    values = values.detach().to(torch.float64).flatten()
    if values.numel() < 1 or not torch.isfinite(values).all():
        raise ValueError("empty/non-finite diagnostic distribution")
    q = torch.tensor((0.0, 0.01, 0.25, 0.5, 0.75, 0.99, 1.0), dtype=torch.float64)
    return {str(float(k)): float(v) for k, v in zip(q, torch.quantile(values, q), strict=True)}


def _effective_rank(states: torch.Tensor) -> float:
    centered = states.to(torch.float64) - states.to(torch.float64).mean(dim=0, keepdim=True)
    singular = torch.linalg.svdvals(centered)
    power = singular.square()
    if float(power.sum()) <= 0:
        return 0.0
    probability = power / power.sum()
    return float(torch.exp(-(probability * probability.clamp_min(1e-300).log()).sum()))


def _mean_off_diagonal_cosine(states: torch.Tensor) -> float:
    if states.size(0) < 2:
        return 1.0
    unit = F.normalize(states.to(torch.float64), dim=-1, eps=GEOMETRY_EPSILON)
    gram = unit @ unit.T
    return float((gram.sum() - gram.diagonal().sum()) / (states.size(0) * (states.size(0) - 1)))


def topology_diagnostics(
    model: TopologyTransformer,
    states: torch.Tensor,
    time_mask: torch.Tensor,
) -> dict[str, Any]:
    output, stages = model._forward_topology(states, time_mask, collect=True)
    depth_rows = []
    for index, state in enumerate(stages["step_states"]):
        selected = state[time_mask]
        radius = torch.linalg.vector_norm(selected, dim=-1)
        depth_rows.append({
            "depth": index,
            "mean_pairwise_token_cosine": _mean_off_diagonal_cosine(selected),
            "effective_rank": _effective_rank(selected),
            "token_state_variance": float(selected.to(torch.float64).var(dim=0, unbiased=False).mean()),
            "radius_variance": float(radius.to(torch.float64).var(unbiased=False)),
            "radius_mean": float(radius.mean()),
            "radius_quantiles": _quantiles(radius),
            "state_rms": float(selected.square().mean().sqrt()),
            "finite": bool(torch.isfinite(selected).all()),
        })
    dynamics = []
    for record in stages["steps"]:
        active = record["active"].squeeze(-1)
        before, after = record["input"][active], record["output"][active]
        before_rho = record["input_rho"].squeeze(-1)[active]
        after_rho, after_direction, _ = decompose_radius_direction(after, epsilon=GEOMETRY_EPSILON)
        before_direction = record["input_direction"][active]
        dot = (before_direction * after_direction).sum(-1).clamp(-1.0, 1.0)
        geodesic = torch.acos(dot)
        radial = after_rho.squeeze(-1) - before_rho
        relative = torch.linalg.vector_norm(after - before, dim=-1) / torch.linalg.vector_norm(before, dim=-1).clamp_min(GEOMETRY_EPSILON)
        radius = torch.linalg.vector_norm(after, dim=-1)
        before_radius = torch.linalg.vector_norm(before, dim=-1)
        ratio = radius / before_radius.clamp_min(GEOMETRY_EPSILON)
        dynamics.append({
            "step": int(record["step"]),
            "state_change_relative_quantiles": _quantiles(relative),
            "radial_log_displacement_signed_quantiles": _quantiles(radial),
            "radial_log_displacement_absolute_quantiles": _quantiles(radial.abs()),
            "angular_geodesic_displacement_quantiles": _quantiles(geodesic),
            "radius_collapse_fraction": float(radius.le(RADIUS_COLLAPSE).to(torch.float64).mean()),
            "radius_explosion_absolute_fraction": float(radius.ge(RADIUS_EXPLOSION).to(torch.float64).mean()),
            "radius_explosion_ratio_fraction": float(ratio.ge(RADIUS_RATIO_EXPLOSION).to(torch.float64).mean()),
            "unit_norm_max_absolute_error": (
                float((radius - 1).abs().max()) if model.condition == UNIT_HYPERSPHERE else None
            ),
        })
    return {
        "oversmoothing_by_recurrent_depth": depth_rows,
        "radial_angular_dynamics_by_step": dynamics,
        "all_finite": bool(torch.isfinite(output.logits).all() and all(row["finite"] for row in depth_rows)),
        "stability_interventions": {
            "geometry_epsilon": GEOMETRY_EPSILON,
            "zero_direction": "first coordinate axis",
            "normalization": "epsilon-guarded L2 projection only in preregistered geometry arms",
            "clipping_or_retuning_after_freeze": False,
        },
    }


def _document_rows(
    output: PredictorOutput,
    batch: TextBatch,
    *,
    condition: str,
    seed: int,
    step: int,
    cumulative_bytes: int,
    cumulative_dense_flops: int,
    cumulative_geometric_operations: int,
) -> list[dict[str, Any]]:
    nll = F.cross_entropy(output.logits.transpose(1, 2), batch.targets, reduction="none")
    rows = []
    for index, document_id in enumerate(batch.document_ids):
        count = int(batch.valid[index].sum().item())
        total = float((nll[index] * batch.valid[index]).sum(dtype=torch.float64).item())
        rows.append({
            "condition": condition,
            "architecture": "frozen-phase-attention-topology",
            "seed": seed,
            "document_id": document_id,
            "stable_source_id": document_id,
            "checkpoint_step": step,
            "total_nll": total,
            "original_byte_count": count,
            "byte_normalized_nll": total / count,
            "cumulative_training_original_bytes": cumulative_bytes,
            "cumulative_training_dense_flops_estimate": cumulative_dense_flops,
            "cumulative_training_geometric_operations_estimate": cumulative_geometric_operations,
        })
    return rows


def _first_block_and_head_fingerprint(model: TopologyTransformer) -> str:
    holder = nn.ModuleDict({"block": deepcopy(model.blocks[0]), "head": deepcopy(model.head)})
    return module_state_fingerprint(holder)


def fit_topology_condition(
    prepared: PreparedCondition,
    calibration_batch: TextBatch,
    evaluation_batch: TextBatch,
    *,
    condition: str,
    seed: int,
    config: LogPolarConfig = DEFAULT_CONFIG,
    device: str | torch.device = "cpu",
) -> dict[str, Any]:
    """Fit one frozen-budget #164 topology cell."""

    if condition not in TRAINED_CONDITIONS:
        raise ValueError("only primary #164 arms are trained")
    config.validate()
    requested = torch.device(device)
    if requested.type != "cpu" and not torch.cuda.is_available():
        raise ValueError("requested accelerator is unavailable")
    model = build_topology_predictor(condition, seed, config).to(requested)
    initial_sha = module_state_fingerprint(model)
    shared_component_sha = _first_block_and_head_fingerprint(model)
    train_states = prepared.train_states.to(requested).detach().requires_grad_(True)
    evaluation_states = prepared.evaluation_states.to(requested)
    train_mask = prepared.train_mask.to(requested)
    evaluation_mask = prepared.evaluation_mask.to(requested)
    train_batch = _device_batch(calibration_batch, requested)
    evaluation_device = _device_batch(evaluation_batch, requested)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    train_forward = dense_forward_flops_for_depth(train_states.size(0), train_states.size(1), EFFECTIVE_DEPTH, config)
    eval_forward = dense_forward_flops_for_depth(evaluation_states.size(0), evaluation_states.size(1), EFFECTIVE_DEPTH, config)
    train_geometry = geometric_operations(condition, train_states.size(0), train_states.size(1), config)
    eval_geometry = geometric_operations(condition, evaluation_states.size(0), evaluation_states.size(1), config)
    trace: list[dict[str, Any]] = []
    train_curve: list[dict[str, Any]] = []
    checkpoint_ledger: list[dict[str, Any]] = []
    parameter_gradients: list[float] = []
    parameter_updates: list[float] = []
    step_gradient_norms: list[list[float]] = [[] for _ in range(EFFECTIVE_DEPTH + 1)]
    step_radial_gradient_norms: list[list[float]] = [[] for _ in range(EFFECTIVE_DEPTH + 1)]
    step_tangential_gradient_norms: list[list[float]] = [[] for _ in range(EFFECTIVE_DEPTH + 1)]
    initial_rss = _rss_bytes()
    training_elapsed = 0.0
    total_started = time.perf_counter()

    def evaluate(step: int) -> None:
        model.eval()
        started = time.perf_counter()
        with torch.no_grad():
            output = model(evaluation_states, evaluation_mask)
            rows = _document_rows(
                output, evaluation_device, condition=condition, seed=seed, step=step,
                cumulative_bytes=calibration_batch.byte_count * step,
                cumulative_dense_flops=3 * train_forward * step,
                cumulative_geometric_operations=3 * train_geometry["total"] * step,
            )
        elapsed = max(time.perf_counter() - started, 1e-12)
        trace.extend(rows)
        total = math.fsum(row["total_nll"] for row in rows)
        count = sum(row["original_byte_count"] for row in rows)
        checkpoint_ledger.append({
            "checkpoint_step": step,
            "total_nll": total,
            "original_byte_count": count,
            "byte_normalized_nll": total / count,
            "elapsed_seconds": elapsed,
            "original_bytes_per_second": count / elapsed,
            "model_state_sha256": module_state_fingerprint(model),
        })

    evaluate(0)
    for step in range(1, config.updates + 1):
        started = time.perf_counter()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        train_states.grad = None
        output, stages = model._forward_topology(
            train_states, train_mask, collect=True, retain_gradients=True,
        )
        nll = F.cross_entropy(output.logits.transpose(1, 2), train_batch.targets, reduction="none")
        total_nll = (nll * train_batch.valid).sum()
        loss = total_nll / train_batch.byte_count
        if not torch.isfinite(loss):
            raise RuntimeError("non-finite #164 training loss")
        loss.backward()
        for index, state in enumerate(stages["step_states"]):
            gradient = state.grad
            if gradient is None or not torch.isfinite(gradient).all():
                raise RuntimeError("missing/non-finite recurrent-step gradient")
            selected_state = state.detach()[train_mask]
            selected_gradient = gradient.detach()[train_mask]
            direction = F.normalize(selected_state, dim=-1, eps=GEOMETRY_EPSILON)
            radial = (selected_gradient * direction).sum(-1, keepdim=True) * direction
            tangent = selected_gradient - radial
            step_gradient_norms[index].append(float(selected_gradient.square().mean().sqrt()))
            step_radial_gradient_norms[index].append(float(radial.square().mean().sqrt()))
            step_tangential_gradient_norms[index].append(float(tangent.square().mean().sqrt()))
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip_norm)
        norm_value = float(norm.detach().cpu())
        if not math.isfinite(norm_value) or train_states.grad is None or not torch.isfinite(train_states.grad).all():
            raise RuntimeError("non-finite #164 gradient")
        parameter_gradients.append(norm_value)
        before = [parameter.detach().clone() for parameter in model.parameters()]
        optimizer.step()
        update = math.sqrt(math.fsum(
            float((parameter.detach() - old).square().sum(dtype=torch.float64))
            for old, parameter in zip(before, model.parameters(), strict=True)
        ))
        if not math.isfinite(update) or any(not torch.isfinite(parameter).all() for parameter in model.parameters()):
            raise RuntimeError("non-finite #164 parameter update")
        parameter_updates.append(update)
        training_elapsed += time.perf_counter() - started
        train_curve.append({
            "step": step,
            "total_nll": float(total_nll.detach().cpu()),
            "original_byte_count": train_batch.byte_count,
            "byte_normalized_nll": float(loss.detach().cpu()),
            "preclip_gradient_l2_norm": norm_value,
            "parameter_update_l2_norm": update,
            "parameters_finite": True,
            "cumulative_training_original_bytes": train_batch.byte_count * step,
            "cumulative_training_dense_flops_estimate": 3 * train_forward * step,
            "cumulative_training_geometric_operations_estimate": 3 * train_geometry["total"] * step,
        })
        if step in config.checkpoint_steps:
            evaluate(step)

    model.eval()
    with torch.no_grad():
        diagnostics = topology_diagnostics(model, evaluation_states, evaluation_mask)
    total_elapsed = max(time.perf_counter() - total_started, 1e-12)
    training_elapsed = max(training_elapsed, 1e-12)
    final_rows = [row for row in trace if row["checkpoint_step"] == config.updates]
    final_total = math.fsum(row["total_nll"] for row in final_rows)
    final_count = sum(row["original_byte_count"] for row in final_rows)
    parameters = parameter_count(model)
    parameter_bytes = sum(parameter.numel() * parameter.element_size() for parameter in model.parameters())
    activation_bytes = (EFFECTIVE_DEPTH + 1) * train_states.numel() * train_states.element_size()
    overhead_fraction = train_geometry["total"] / train_forward
    return {
        "schema_version": "retained-radius-topology-cell/v1",
        "issue": ISSUE_NUMBER,
        "condition": condition,
        "topology_config": condition_topology_config(condition),
        "seed": seed,
        "initial_model_state_sha256": initial_sha,
        "initial_shared_block_and_head_sha256": shared_component_sha,
        "final_model_state_sha256": module_state_fingerprint(model),
        "representation_provenance": {
            "raw_train_fingerprint": prepared.raw_train_fingerprint,
            "raw_evaluation_fingerprint": prepared.raw_evaluation_fingerprint,
            "canonical_train_fingerprint": prepared.canonical_train_fingerprint,
            "canonical_evaluation_fingerprint": prepared.canonical_evaluation_fingerprint,
            "coordinate_map_parameter_count": 0,
            "composition": "none",
        },
        "train_curve": train_curve,
        "validation_learning_curve": trace,
        "final_evaluation": {
            "total_nll": final_total,
            "original_byte_count": final_count,
            "byte_normalized_nll": final_total / final_count,
            "documents": final_rows,
        },
        "parameter_ledger": {
            "total_parameters": parameters,
            "trainable_parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
            "parameter_bytes": parameter_bytes,
            "unique_operator_copies": len(model.blocks),
            "effective_operator_applications": EFFECTIVE_DEPTH,
            "parameter_reuse_factor": EFFECTIVE_DEPTH if condition != INDEPENDENT_FLAT else 1,
        },
        "flop_ledger": {
            "estimation": "#162/#163 dense multiply-add ledger at effective depth three plus explicit scalar geometry operations",
            "dense_forward_flops_per_calibration_batch": train_forward,
            "dense_training_flops_estimate": 3 * train_forward * config.updates,
            "dense_checkpoint_evaluation_flops_estimate": eval_forward * len(config.checkpoint_steps),
            "dense_total_flops_estimate": 3 * train_forward * config.updates + eval_forward * len(config.checkpoint_steps),
            "geometric_operations_per_calibration_batch": train_geometry,
            "geometric_training_operations_estimate": {key: 3 * value * config.updates for key, value in train_geometry.items()},
            "geometric_checkpoint_evaluation_operations_estimate": {key: value * len(config.checkpoint_steps) for key, value in eval_geometry.items()},
            "geometric_overhead_fraction_of_dense_forward": overhead_fraction,
        },
        "performance_ledger": {
            "training_elapsed_seconds": training_elapsed,
            "cell_total_wall_elapsed_seconds": total_elapsed,
            "training_original_bytes_processed": train_batch.byte_count * config.updates,
            "training_original_bytes_per_second": train_batch.byte_count * config.updates / training_elapsed,
            "checkpoint_ledger": checkpoint_ledger,
            "peak_process_rss_bytes": _rss_bytes(),
            "initial_process_peak_rss_bytes": initial_rss,
            "recurrent_materialization_bytes_estimate": activation_bytes,
        },
        "gradient_ledger": {
            "parameter_preclip_l2": _summarize(parameter_gradients),
            "parameter_update_l2": _summarize(parameter_updates),
            "state_gradient_rms_by_recurrent_depth": [_summarize(values) for values in step_gradient_norms],
            "radial_gradient_rms_by_recurrent_depth": [_summarize(values) for values in step_radial_gradient_norms],
            "tangential_gradient_rms_by_recurrent_depth": [_summarize(values) for values in step_tangential_gradient_norms],
            "all_finite": True,
        },
        "mechanism_diagnostics": diagnostics,
        "test_split": {"status": "sealed-not-read", "accessed": False},
    }


def aggregate_outcomes(rows: Sequence[Mapping[str, Any]]) -> tuple[dict[str, dict[str, float]], list[dict[str, Any]]]:
    cells: dict[tuple[str, int, str, int], tuple[float, int]] = {}
    documents: set[str] = set()
    for row in rows:
        condition, seed = str(row["condition"]), int(row["seed"])
        document, step = str(row["document_id"]), int(row["checkpoint_step"])
        if condition not in STATISTICAL_CONDITIONS or seed not in DOWNSTREAM_SEEDS or step not in CHECKPOINT_STEPS:
            raise ValueError("#164 trace contains a non-preregistered cell")
        key = condition, seed, document, step
        if key in cells:
            raise ValueError("duplicate #164 trace row")
        total, count = float(row["total_nll"]), int(row["original_byte_count"])
        if count < 1 or not math.isfinite(total) or not math.isclose(float(row["byte_normalized_nll"]), total / count, rel_tol=1e-9, abs_tol=1e-11):
            raise ValueError("invalid #164 byte-normalized trace row")
        cells[key] = total, count
        documents.add(document)
    document_ids = sorted(documents)
    expected = {
        (condition, seed, document, step)
        for condition in STATISTICAL_CONDITIONS for seed in DOWNSTREAM_SEEDS
        for document in document_ids for step in CHECKPOINT_STEPS
    }
    if len(document_ids) != 8 or set(cells) != expected:
        raise ValueError("trace does not cover frozen five-by-three-by-eight-by-seven grid")
    aggregated = []
    for condition in STATISTICAL_CONDITIONS:
        for document in document_ids:
            for step in CHECKPOINT_STEPS:
                values = [cells[(condition, seed, document, step)] for seed in DOWNSTREAM_SEEDS]
                if len({count for _, count in values}) != 1:
                    raise ValueError("paired document byte counts drifted")
                aggregated.append({
                    "condition": condition,
                    "document_id": document,
                    "checkpoint_step": step,
                    "mean_total_nll": math.fsum(total for total, _ in values) / len(values),
                    "original_byte_count": values[0][1],
                })
    index: dict[tuple[str, int], list[Mapping[str, Any]]] = defaultdict(list)
    for row in aggregated:
        index[(str(row["condition"]), int(row["checkpoint_step"]))].append(row)
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    outcomes = {}
    for condition in STATISTICAL_CONDITIONS:
        curve = []
        for step in CHECKPOINT_STEPS:
            group = index[(condition, step)]
            curve.append(math.fsum(float(row["mean_total_nll"]) for row in group) / sum(int(row["original_byte_count"]) for row in group))
        values = torch.tensor(curve, dtype=torch.float64)
        outcomes[condition] = {"final": float(values[-1]), "aulc": float(torch.trapezoid(values, fractions))}
    return outcomes, aggregated


def paired_document_bootstrap(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    outcomes, aggregated = aggregate_outcomes(rows)
    documents = sorted({str(row["document_id"]) for row in aggregated})
    lookup = {(row["condition"], row["checkpoint_step"], row["document_id"]): row for row in aggregated}
    generator = torch.Generator(device="cpu").manual_seed(BOOTSTRAP_SEED)
    draws = torch.randint(len(documents), (BOOTSTRAP_SAMPLES, len(documents)), generator=generator, dtype=torch.int64)
    draw_hash = integer_draw_sha256(draws)
    if draw_hash != BOOTSTRAP_DRAW_SHA256:
        raise RuntimeError("#123/#162/#163 paired bootstrap schedule drifted")
    fractions = torch.tensor(BUDGET_FRACTIONS, dtype=torch.float64)
    replicates: dict[str, dict[str, torch.Tensor]] = {condition: {} for condition in STATISTICAL_CONDITIONS}
    for condition in STATISTICAL_CONDITIONS:
        curve = []
        for step in CHECKPOINT_STEPS:
            totals = torch.tensor([float(lookup[(condition, step, doc)]["mean_total_nll"]) for doc in documents], dtype=torch.float64)
            counts = torch.tensor([int(lookup[(condition, step, doc)]["original_byte_count"]) for doc in documents], dtype=torch.float64)
            curve.append(totals[draws].sum(1) / counts[draws].sum(1))
        values = torch.stack(curve, dim=1)
        replicates[condition] = {"final": values[:, -1], "aulc": torch.trapezoid(values, fractions, dim=1)}
    per_alpha = FAMILYWISE_ALPHA / DECISION_FAMILY_SIZE
    quantiles = torch.tensor((per_alpha / 2, 1 - per_alpha / 2), dtype=torch.float64)
    intervals: dict[str, dict[str, Any]] = {outcome: {} for outcome in OUTCOMES}
    for outcome in OUTCOMES:
        for name, terms in CONTRAST_DEFINITIONS.items():
            point = math.fsum(coefficient * outcomes[condition][outcome] for condition, coefficient in terms)
            values = sum(coefficient * replicates[condition][outcome] for condition, coefficient in terms)
            lower, upper = torch.quantile(values, quantiles)
            intervals[outcome][name] = {
                "point": point,
                "lower": float(lower),
                "upper": float(upper),
                "confidence": 1 - per_alpha,
                "familywise_confidence": 1 - FAMILYWISE_ALPHA,
                "bootstrap_samples": BOOTSTRAP_SAMPLES,
                "resampling_unit": "source-document",
                "seed_aggregation": "within-document fixed-seed mean",
            }
    return {
        "schema_version": "retained-radius-topology-statistics/v1",
        "issue": ISSUE_NUMBER,
        "condition_outcomes": outcomes,
        "contrast_definitions": {
            name: [{"condition": condition, "coefficient": coefficient} for condition, coefficient in terms]
            for name, terms in CONTRAST_DEFINITIONS.items()
        },
        "contrasts": intervals,
        "bootstrap": {
            "method": "paired percentile source-document block bootstrap; fixed seeds averaged within document; shared frozen draws",
            "samples": BOOTSTRAP_SAMPLES,
            "seed": BOOTSTRAP_SEED,
            "draws_sha256": draw_hash,
            "familywise_alpha": FAMILYWISE_ALPHA,
            "decision_family_size": DECISION_FAMILY_SIZE,
            "per_interval_two_sided_alpha": per_alpha,
        },
        "thresholds": {
            "material_nats_per_original_byte": MATERIAL_NLL,
            "equivalence_nats_per_original_byte": EQUIVALENCE_NLL,
            "parameter_reduction_fraction": PARAMETER_REDUCTION_FRACTION,
        },
    }


def seed_contrasts(cells: Sequence[Mapping[str, Any]], anchor_cells: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, float]]:
    by_key = {(str(cell["condition"]), int(cell["seed"])): float(cell["final_evaluation"]["byte_normalized_nll"]) for cell in cells}
    by_key.update({(ANCHOR, int(cell["seed"])): float(cell["final_evaluation"]["byte_normalized_nll"]) for cell in anchor_cells})
    return {
        str(seed): {
            name: math.fsum(coefficient * by_key[(condition, seed)] for condition, coefficient in terms)
            for name, terms in CONTRAST_DEFINITIONS.items()
        }
        for seed in DOWNSTREAM_SEEDS
    }


def classify(
    statistics: Mapping[str, Any],
    cells: Sequence[Mapping[str, Any]],
    anchor_cells: Sequence[Mapping[str, Any]],
    *,
    instrumentation_passed: bool,
) -> dict[str, Any]:
    if not instrumentation_passed:
        return {
            "classification": "INVALID INSTRUMENTATION",
            "advance_issue_165": False,
            "reason": "a fail-closed source/replay/causality/numerical/resource gate failed before interpretation",
        }
    final = statistics["contrasts"]["final"]
    per_seed = seed_contrasts(cells, anchor_cells)
    by_condition = {str(cell["condition"]): cell for cell in cells if int(cell["seed"]) == DOWNSTREAM_SEEDS[0]}
    shared_parameters = int(by_condition[SHARED_GENERIC]["parameter_ledger"]["total_parameters"])
    flat_parameters = int(by_condition[INDEPENDENT_FLAT]["parameter_ledger"]["total_parameters"])
    reduction = 1 - shared_parameters / flat_parameters
    geometry_costs_matched = (
        len({int(by_condition[name]["parameter_ledger"]["total_parameters"]) for name in (SHARED_GENERIC, UNIT_HYPERSPHERE, RETAINED_RADIUS)}) == 1
        and len({int(by_condition[name]["flop_ledger"]["dense_training_flops_estimate"]) for name in (SHARED_GENERIC, UNIT_HYPERSPHERE, RETAINED_RADIUS)}) == 1
        and max(float(by_condition[name]["flop_ledger"]["geometric_overhead_fraction_of_dense_forward"]) for name in (UNIT_HYPERSPHERE, RETAINED_RADIUS)) <= MAX_GEOMETRIC_OVERHEAD_FRACTION
    )

    def material(name: str) -> bool:
        return float(final[name]["upper"]) <= -MATERIAL_NLL and all(per_seed[str(seed)][name] <= -MATERIAL_NLL for seed in DOWNSTREAM_SEEDS)

    def noninferior(name: str) -> bool:
        return float(final[name]["upper"]) <= MATERIAL_NLL

    retained = material("retained_radius_benefit") and noninferior("retained_vs_independent") and geometry_costs_matched
    hypersphere = material("hyperspherical_effect") and noninferior("unit_vs_independent") and geometry_costs_matched
    shared_material = material("sharing_effect")
    shared_efficiency = noninferior("sharing_effect") and reduction >= PARAMETER_REDUCTION_FRACTION
    independent_superior = float(final["sharing_effect"]["lower"]) >= MATERIAL_NLL
    if retained:
        classification = "RETAINED-RADIUS EFFECT"
        reason = "explicit rho materially and seed-consistently improves over the matched unit-hypersphere recurrence"
    elif hypersphere:
        classification = "HYPERSPHERICAL EFFECT"
        reason = "unit-direction recurrence materially improves over generic shared recurrence, but explicit rho adds no qualifying benefit"
    elif shared_material or shared_efficiency:
        classification = "SHARED-DEPTH EFFECT ONLY"
        reason = "generic recurrent sharing explains the qualified result; neither geometry contrast independently survives"
    else:
        classification = "NO TOPOLOGY BENEFIT"
        reason = "independent flat depth remains preferred or no recurrent topology meets the frozen efficacy/efficiency criterion"
    advance = classification in {"HYPERSPHERICAL EFFECT", "RETAINED-RADIUS EFFECT"}
    return {
        "classification": classification,
        "advance_issue_165": advance,
        "reason": reason,
        "geometry_specific_continuation": advance,
        "explicit_radius_supported": classification == "RETAINED-RADIUS EFFECT",
        "gates": {
            "retained_radius_material_seed_consistent": material("retained_radius_benefit"),
            "retained_radius_noninferior_to_independent": noninferior("retained_vs_independent"),
            "hypersphere_material_seed_consistent": material("hyperspherical_effect"),
            "unit_noninferior_to_independent": noninferior("unit_vs_independent"),
            "shared_material_seed_consistent": shared_material,
            "shared_noninferior_with_parameter_reduction": shared_efficiency,
            "independent_materially_superior_to_shared": independent_superior,
            "geometry_resources_matched": geometry_costs_matched,
            "shared_parameter_reduction_fraction_vs_independent": reduction,
        },
        "per_seed_contrasts": per_seed,
    }


def run_synthetic_controls(config: LogPolarConfig = DEFAULT_CONFIG) -> dict[str, Any]:
    config.validate()
    generator = torch.Generator().manual_seed(164_001)
    mask = torch.ones(2, 8, dtype=torch.bool)
    states = torch.randn(2, 8, 128, generator=generator, requires_grad=True)
    rho, direction, active = decompose_radius_direction(states, mask)
    reconstructed = reconstruct_radius_direction(rho, direction, active)
    reconstruction_difference = float((reconstructed - states).abs().max().detach())
    unit = project_unit_hypersphere(states, mask)
    unit_error = float((torch.linalg.vector_norm(unit[mask], dim=-1) - 1).abs().max().detach())

    base = torch.zeros(2, 128, dtype=torch.float64)
    base[:, 0] = 1
    base_rho = torch.tensor([[0.0], [math.log(2.0)]], dtype=torch.float64)
    base_active = torch.ones(2, 1, dtype=torch.bool)
    radial_delta = torch.tensor([[0.2], [-0.1]], dtype=torch.float64)
    zero_tangent = torch.zeros_like(base)
    radial_state, radial_rho, radial_direction = product_state_update(
        base_rho, base, radial_delta, zero_tangent, base_active,
    )
    tangent = torch.zeros_like(base)
    tangent[:, 1] = torch.tensor([0.25, -0.4], dtype=torch.float64)
    angular_state, angular_rho, angular_direction = product_state_update(
        base_rho, base, torch.zeros_like(base_rho), tangent, base_active,
    )
    radial_direction_error = float((radial_direction - base).abs().max())
    angular_radius_error = float((torch.linalg.vector_norm(angular_state, dim=-1) - base_rho.exp().squeeze(-1)).abs().max())
    angular_displacement = torch.acos((base * angular_direction).sum(-1).clamp(-1.0, 1.0))

    zero = torch.zeros(2, 4, 128, requires_grad=True)
    near_zero = torch.full((2, 4, 128), 1e-12, requires_grad=True)
    zero_rho, zero_direction, zero_active = decompose_radius_direction(zero)
    near_rho, near_direction, near_active = decompose_radius_direction(near_zero)
    finite_zero = all(torch.isfinite(value).all() for value in (zero_rho, zero_direction, near_rho, near_direction))
    (zero_rho.sum() + zero_direction.sum() + near_rho.sum() + near_direction.sum()).backward()
    finite_zero_gradients = bool(torch.isfinite(zero.grad).all() and torch.isfinite(near_zero.grad).all())

    exact_163 = ComposablePolarTransformer(attention_mode="hermitian", residual_mode="cartesian")
    anchor = build_topology_predictor(ANCHOR, 17, config)
    anchor.load_state_dict({
        **{f"blocks.0.{name}": value for name, value in exact_163.backbone.decoder.layers[0].state_dict().items()},
        **{f"head.{name}": value for name, value in exact_163.backbone.head.state_dict().items()},
    }, strict=True)
    exact_163.eval(); anchor.eval()
    raw = states.detach()
    with torch.no_grad():
        exact_difference = float((exact_163(raw, mask).logits - anchor(raw, mask).logits).abs().max())

    recurrence_determinism = {}
    causal = {}
    finite_gradients = {}
    for condition in TRAINED_CONDITIONS:
        model = build_topology_predictor(condition, 17, config)
        model.eval()
        altered = raw.clone()
        altered[:, 6:] = torch.randn(2, 2, 128, generator=generator)
        with torch.no_grad():
            first = model(raw, mask).logits
            second = model(raw, mask).logits
            changed = model(altered, mask).logits
        recurrence_determinism[condition] = float((first - second).abs().max())
        differentiable = raw.clone().requires_grad_(True)
        early = model(differentiable, mask).logits[:, 4].sum()
        gradient = torch.autograd.grad(early, differentiable)[0]
        causal[condition] = {
            "prefix_max_absolute_difference": float((first[:, :6] - changed[:, :6]).abs().max()),
            "future_gradient_max_absolute": float(gradient[:, 5:].abs().max()),
        }
        finite_gradients[condition] = bool(torch.isfinite(gradient).all() and torch.isfinite(first).all())

    shared = build_topology_predictor(SHARED_GENERIC, 17, config)
    retained = build_topology_predictor(RETAINED_RADIUS, 17, config)
    retained.load_state_dict(shared.state_dict(), strict=True)
    with torch.no_grad():
        shared_retained_difference = float((shared(raw, mask).logits - retained(raw, mask).logits).abs().max())
    initialization = {}
    for seed in DOWNSTREAM_SEEDS:
        models = {condition: build_topology_predictor(condition, seed, config) for condition in STATISTICAL_CONDITIONS}
        components = {condition: _first_block_and_head_fingerprint(model) for condition, model in models.items()}
        initialization[str(seed)] = {
            "first_block_and_head_sha256": components,
            "all_applicable_components_equal": len(set(components.values())) == 1,
            "parameter_counts": {condition: parameter_count(model) for condition, model in models.items()},
        }
    passed = (
        reconstruction_difference <= RECONSTRUCTION_TOLERANCE
        and unit_error <= NORM_TOLERANCE
        and radial_direction_error <= 1e-12
        and angular_radius_error <= 1e-12
        and bool((angular_displacement > 0).all())
        and finite_zero and finite_zero_gradients
        and exact_difference == 0.0
        and shared_retained_difference <= RECONSTRUCTION_TOLERANCE
        and all(value == 0.0 for value in recurrence_determinism.values())
        and all(item["prefix_max_absolute_difference"] == 0.0 and item["future_gradient_max_absolute"] == 0.0 for item in causal.values())
        and all(finite_gradients.values())
        and all(item["all_applicable_components_equal"] for item in initialization.values())
    )
    return {
        "schema_version": "retained-radius-topology-synthetic-controls/v1",
        "passed": passed,
        "decomposition_reconstruction_max_absolute_difference": reconstruction_difference,
        "unit_projection_max_norm_error": unit_error,
        "pure_radial_direction_max_error": radial_direction_error,
        "pure_radial_log_radius_change": (radial_rho - base_rho).squeeze(-1).tolist(),
        "pure_angular_radius_max_error": angular_radius_error,
        "pure_angular_geodesic_displacement": angular_displacement.tolist(),
        "zero_and_near_zero_finite": finite_zero,
        "zero_and_near_zero_gradients_finite": finite_zero_gradients,
        "full_163_anchor_max_absolute_logit_difference": exact_difference,
        "generic_vs_retained_reconstruction_max_absolute_logit_difference": shared_retained_difference,
        "recurrence_determinism_max_absolute_difference": recurrence_determinism,
        "causality": causal,
        "finite_gradients_and_logits": finite_gradients,
        "matched_initialization": initialization,
    }


__all__ = [
    "ANCHOR", "INDEPENDENT_FLAT", "SHARED_GENERIC", "UNIT_HYPERSPHERE", "RETAINED_RADIUS",
    "TRAINED_CONDITIONS", "STATISTICAL_CONDITIONS", "EFFECTIVE_DEPTH", "CONTRAST_DEFINITIONS",
    "MATERIAL_NLL", "EQUIVALENCE_NLL", "DECISION_FAMILY_SIZE", "TopologyTransformer",
    "build_topology_predictor", "prepare_topology_condition", "fit_topology_condition",
    "condition_topology_config", "topology_wire", "topology_digest", "decompose_radius_direction",
    "reconstruct_radius_direction", "project_unit_hypersphere", "sphere_log_map", "sphere_exp_map",
    "product_state_update", "dense_forward_flops_for_depth", "geometric_operations",
    "topology_diagnostics", "paired_document_bootstrap", "seed_contrasts", "classify",
    "run_synthetic_controls",
]
