from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
import math
from pathlib import Path

import pytest
import torch

from domain_scaling_lab.log_polar_no_composition import PreparedCondition, fixture_config
from domain_scaling_lab.phase_operation_ablations import ComposablePolarTransformer
from domain_scaling_lab.retained_radius_topology import (
    ANCHOR,
    EFFECTIVE_DEPTH,
    INDEPENDENT_FLAT,
    RETAINED_RADIUS,
    SHARED_GENERIC,
    STATISTICAL_CONDITIONS,
    TRAINED_CONDITIONS,
    UNIT_HYPERSPHERE,
    build_topology_predictor,
    decompose_radius_direction,
    fit_topology_condition,
    parameter_count,
    product_state_update,
    project_unit_hypersphere,
    reconstruct_radius_direction,
    run_synthetic_controls,
    sphere_exp_map,
    sphere_log_map,
)
from domain_scaling_lab.spectral import TextBatch, module_state_fingerprint


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


def _runner_module():
    path = REPOSITORY_ROOT / "scripts/run_retained_radius_topology.py"
    specification = importlib.util.spec_from_file_location("issue_164_runner", path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def _batch(target_offset: int = 0) -> TextBatch:
    input_ids = torch.tensor(((0, 98, 99, 100, 101), (0, 102, 103, 104, 105)))
    targets = (torch.tensor(((97, 98, 99, 100, 101), (101, 102, 103, 104, 105))) + target_offset) % 256
    valid = torch.ones(2, 5, dtype=torch.bool)
    return TextBatch(input_ids, targets, valid, 10, ("doc-a", "doc-b"))


def test_radius_direction_round_trip_unit_projection_zero_and_near_zero() -> None:
    states = torch.randn(3, 4, 128, generator=torch.Generator().manual_seed(164), dtype=torch.float64, requires_grad=True)
    mask = torch.ones(3, 4, dtype=torch.bool)
    rho, direction, active = decompose_radius_direction(states, mask)
    reconstructed = reconstruct_radius_direction(rho, direction, active)
    assert torch.allclose(reconstructed, states, atol=1e-12, rtol=1e-12)
    assert torch.allclose(torch.linalg.vector_norm(direction[active.squeeze(-1)], dim=-1), torch.ones(12, dtype=torch.float64), atol=1e-12, rtol=0)
    unit = project_unit_hypersphere(states, mask)
    assert torch.allclose(torch.linalg.vector_norm(unit[mask], dim=-1), torch.ones(12, dtype=torch.float64), atol=1e-12, rtol=0)

    zero = torch.zeros(2, 3, 128, dtype=torch.float64, requires_grad=True)
    near = torch.full((2, 3, 128), 1e-12, dtype=torch.float64, requires_grad=True)
    values = (*decompose_radius_direction(zero), *decompose_radius_direction(near))
    assert all(torch.isfinite(value).all() for value in values)
    sum(value.to(torch.float64).sum() for value in values if value.dtype != torch.bool).backward()
    assert zero.grad is not None and near.grad is not None
    assert torch.isfinite(zero.grad).all() and torch.isfinite(near.grad).all()


def test_radial_and_tangential_updates_are_independent_and_geodesic() -> None:
    direction = torch.zeros(2, 128, dtype=torch.float64)
    direction[:, 0] = 1
    rho = torch.tensor([[0.0], [math.log(3)]], dtype=torch.float64)
    active = torch.ones(2, 1, dtype=torch.bool)
    radial = torch.tensor([[0.2], [-0.3]], dtype=torch.float64)
    state, new_rho, new_direction = product_state_update(rho, direction, radial, torch.zeros_like(direction), active)
    assert torch.equal(new_direction, direction)
    assert torch.allclose(new_rho, rho + radial)
    assert torch.allclose(torch.linalg.vector_norm(state, dim=-1), (rho + radial).exp().squeeze(-1), atol=1e-12, rtol=1e-12)

    tangent = torch.zeros_like(direction)
    tangent[:, 1] = torch.tensor([0.25, -0.5], dtype=torch.float64)
    angular, angular_rho, angular_direction = product_state_update(rho, direction, torch.zeros_like(rho), tangent, active)
    assert torch.equal(angular_rho, rho)
    assert torch.allclose(torch.linalg.vector_norm(angular, dim=-1), rho.exp().squeeze(-1), atol=1e-12, rtol=1e-12)
    displacement = torch.acos((direction * angular_direction).sum(-1).clamp(-1, 1))
    assert torch.allclose(displacement, tangent.norm(dim=-1), atol=1e-12, rtol=1e-12)


def test_sphere_log_exp_round_trip_and_tangent_orthogonality() -> None:
    generator = torch.Generator().manual_seed(9)
    base = project_unit_hypersphere(torch.randn(12, 128, generator=generator, dtype=torch.float64))
    target = project_unit_hypersphere(base + 0.15 * torch.randn(12, 128, generator=generator, dtype=torch.float64))
    tangent = sphere_log_map(base, target)
    replay = sphere_exp_map(base, tangent)
    assert torch.allclose((base * tangent).sum(-1), torch.zeros(12, dtype=torch.float64), atol=2e-12, rtol=0)
    assert torch.allclose(replay, target, atol=2e-12, rtol=2e-12)
    assert torch.allclose(torch.linalg.vector_norm(replay, dim=-1), torch.ones(12, dtype=torch.float64), atol=1e-12, rtol=0)


def test_depth_one_anchor_is_exact_163_and_matched_initialization_holds() -> None:
    states = torch.randn(2, 7, 128, generator=torch.Generator().manual_seed(3))
    mask = torch.ones(2, 7, dtype=torch.bool)
    old = ComposablePolarTransformer(attention_mode="hermitian", residual_mode="cartesian")
    anchor = build_topology_predictor(ANCHOR, 17)
    anchor.load_state_dict({
        **{f"blocks.0.{name}": value for name, value in old.backbone.decoder.layers[0].state_dict().items()},
        **{f"head.{name}": value for name, value in old.backbone.head.state_dict().items()},
    }, strict=True)
    old.eval(); anchor.eval()
    with torch.no_grad():
        assert torch.equal(old(states, mask).logits, anchor(states, mask).logits)

    for seed in (17, 31, 47):
        models = {condition: build_topology_predictor(condition, seed) for condition in STATISTICAL_CONDITIONS}
        first_layers = {condition: module_state_fingerprint(model.blocks[0]) for condition, model in models.items()}
        heads = {condition: module_state_fingerprint(model.head) for condition, model in models.items()}
        assert len(set(first_layers.values())) == 1
        assert len(set(heads.values())) == 1
        assert parameter_count(models[ANCHOR]) == parameter_count(models[SHARED_GENERIC])
        assert parameter_count(models[INDEPENDENT_FLAT]) > parameter_count(models[SHARED_GENERIC])
        for left, right in zip(models[INDEPENDENT_FLAT].blocks[1:], models[INDEPENDENT_FLAT].blocks[:-1], strict=True):
            assert module_state_fingerprint(left) == module_state_fingerprint(right)


def test_every_topology_is_causal_excludes_future_gradients_and_is_deterministic() -> None:
    generator = torch.Generator().manual_seed(164)
    states = torch.randn(2, 8, 128, generator=generator)
    altered = states.clone()
    altered[:, 6:] = torch.randn(2, 2, 128, generator=generator)
    mask = torch.ones(2, 8, dtype=torch.bool)
    for condition in TRAINED_CONDITIONS:
        model = build_topology_predictor(condition, 17)
        model.eval()
        with torch.no_grad():
            first = model(states, mask).logits
            second = model(states, mask).logits
            changed = model(altered, mask).logits
            assert torch.equal(first, second)
            assert torch.equal(first[:, :6], changed[:, :6])
        differentiable = states.clone().requires_grad_(True)
        model(differentiable, mask).logits[:, 4].sum().backward()
        assert differentiable.grad is not None
        assert torch.count_nonzero(differentiable.grad[:, 5:]) == 0
        assert torch.isfinite(differentiable.grad).all()


def test_shared_retained_reconstruction_control_is_numerically_close() -> None:
    states = torch.randn(2, 7, 128, generator=torch.Generator().manual_seed(19))
    mask = torch.ones(2, 7, dtype=torch.bool)
    shared = build_topology_predictor(SHARED_GENERIC, 17)
    retained = build_topology_predictor(RETAINED_RADIUS, 17)
    retained.load_state_dict(shared.state_dict(), strict=True)
    shared.eval(); retained.eval()
    with torch.no_grad():
        assert torch.allclose(shared(states, mask).logits, retained(states, mask).logits, atol=2e-5, rtol=0)


def test_fixture_fit_is_finite_reproducible_and_records_depth_diagnostics() -> None:
    config = fixture_config()
    generator = torch.Generator().manual_seed(21)
    train = torch.randn(2, 5, 128, generator=generator)
    evaluation = torch.randn(2, 5, 128, generator=generator)
    mask = torch.ones(2, 5, dtype=torch.bool)
    prepared = PreparedCondition(
        "spectral_phase_attention_only", train, evaluation, mask, mask, 1.0,
        "a" * 64, "b" * 64, "c" * 64, "d" * 64, None, None,
    )
    first = fit_topology_condition(prepared, _batch(), _batch(), condition=RETAINED_RADIUS, seed=17, config=config)
    second = fit_topology_condition(prepared, _batch(), _batch(), condition=RETAINED_RADIUS, seed=17, config=config)
    assert first["final_evaluation"] == second["final_evaluation"]
    assert first["final_model_state_sha256"] == second["final_model_state_sha256"]
    assert first["gradient_ledger"]["all_finite"] is True
    assert len(first["gradient_ledger"]["state_gradient_rms_by_recurrent_depth"]) == EFFECTIVE_DEPTH + 1
    assert len(first["mechanism_diagnostics"]["oversmoothing_by_recurrent_depth"]) == EFFECTIVE_DEPTH + 1
    assert len(first["mechanism_diagnostics"]["radial_angular_dynamics_by_step"]) == EFFECTIVE_DEPTH


def test_all_synthetic_controls_pass() -> None:
    evidence = run_synthetic_controls()
    assert evidence["passed"] is True
    assert evidence["full_163_anchor_max_absolute_logit_difference"] == 0
    assert evidence["unit_projection_max_norm_error"] <= 2e-5
    for condition in TRAINED_CONDITIONS:
        assert evidence["causality"][condition]["prefix_max_absolute_difference"] == 0
        assert evidence["causality"][condition]["future_gradient_max_absolute"] == 0


def test_frozen_preregistration_is_accepted_and_scientific_drift_fails_closed() -> None:
    runner = _runner_module()
    path = REPOSITORY_ROOT / "artifacts/retained_radius_topology/preregistration.json"
    preregistration = json.loads(path.read_text(encoding="utf-8"))
    runner._validate_preregistration(preregistration)

    drifted = deepcopy(preregistration)
    drifted["effective_depth"] = 4
    with pytest.raises(ValueError, match="preregistration drifted"):
        runner._validate_preregistration(drifted)

    drifted = deepcopy(preregistration)
    drifted["statistics"]["materiality_nats_per_original_byte"] = 0.0
    with pytest.raises(ValueError, match="statistical policy"):
        runner._validate_preregistration(drifted)
